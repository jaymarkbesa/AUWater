﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Configuration

Public Class SalaryAndIncome
    Dim connectionString As String = ConfigurationManager.ConnectionStrings("MyDB").ConnectionString
    Dim conn As New SqlConnection(connectionString)
    Dim cmd As SqlCommand
    Dim adapter As SqlDataAdapter
    Dim dt As DataTable
    Private Sub SalaryAndIncome_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LoadEmployeePercent()

        PopulateEmployeeComboBoxes()
        'Tab 1
        LoadMonths()
        LoadYears()

        'Tab 2
        LoadMonths2()
        LoadYears2()

        'Tab 3
        LoadMonths1()
        LoadYears1()

        'Tab 4
        LoadMonths3()
        LoadYears3()

        ' Other initialization tasks
        RefreshDataGridView1Sold()
        RefreshDataGridView2()
        RefreshDataGridView3EmployeeSalary()
        RefreshDataGridView4()

        DataGridView1.ClearSelection()
        DataGridView3.ClearSelection()

        ClearTextBoxes()
        ClearTextBoxes1()
    End Sub
    'Tab 1
    Private Sub ClearTextBoxes()
        ' Clear regular textboxes
        Txt_ContainerWater.Clear()
        Txt_WaterRefill.Clear()
        Txt_Container.Clear()

        ' Clear small textboxes
        Txt_SmallWaterRefill.Clear()
        Txt_SmallContainerWater.Clear()
        Txt_SmallContainer.Clear()

        ' Reset DateTimePickers
        DateTimePicker1.Value = DateTime.Now

        ' Clear additional search textboxes

    End Sub
    Private Sub Btn_Refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh.Click

        Cb_Month.SelectedIndex = 0
        Cb_Year.SelectedIndex = 0
        Txt_Search.Clear()
        RefreshDataGridView1Sold()
        DataGridView1.ClearSelection()

        ClearTextBoxes()
    End Sub

    Private Sub Txt_Search_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Search.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        ' Limit the length of the text to 11 characters
        If Txt_Search.TextLength >= 11 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    Private Sub Btn_Home_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Home.Click
        Me.Hide()
        Home.Show()
        ClearTextBoxes()
        Txt_Search.Clear()
        Txt_Search1.Clear()
        Txt_Search2.Clear()
        Cb_Month.SelectedIndex = 0
        Cb_Year.SelectedIndex = 0
        RefreshDataGridView1Sold()
        DataGridView1.ClearSelection()
    End Sub

    Private Sub Btn_Bills_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Bills.Click
        Me.Hide()
        WaterElectricBills.Show()
        ClearTextBoxes()
        Txt_Search.Clear()
        Txt_Search1.Clear()
        Txt_Search2.Clear()
        Cb_Month.SelectedIndex = 0
        Cb_Year.SelectedIndex = 0
        RefreshDataGridView1Sold()
        DataGridView1.ClearSelection()
    End Sub

    Private Sub Btn_EmployeeInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_EmployeeInfo.Click
        Me.Hide()
        EmployeeInfo.Show()
        ClearTextBoxes()
        Txt_Search.Clear()
        Txt_Search1.Clear()
        Txt_Search2.Clear()
        Cb_Month.SelectedIndex = 0
        Cb_Year.SelectedIndex = 0
        RefreshDataGridView1Sold()
        DataGridView1.ClearSelection()
    End Sub

    Private Sub Btn_Reports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Reports.Click
        Me.Hide()
        Reports.Show()
        Reports.TabControl1.SelectedIndex = 0
        ClearTextBoxes()
        Txt_Search.Clear()
        Txt_Search1.Clear()
        Txt_Search2.Clear()
        Cb_Month.SelectedIndex = 0
        Cb_Year.SelectedIndex = 0
        RefreshDataGridView1Sold()
        DataGridView1.ClearSelection()
    End Sub

    Private Sub Btn_Recycle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Recycle.Click
        Me.Hide()
        RecycleBin.Show()
        RecycleBin.TabControl1.SelectedIndex = 0
        ClearTextBoxes()
        Txt_Search.Clear()
        Txt_Search1.Clear()
        Txt_Search2.Clear()
        Cb_Month.SelectedIndex = 0
        Cb_Year.SelectedIndex = 0
        RefreshDataGridView1Sold()
        DataGridView1.ClearSelection()
    End Sub
    Private Sub Cb_Month_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Month.SelectedIndexChanged
        RefreshDataGridView1Sold()
    End Sub

    Private Sub Cb_Year_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Year.SelectedIndexChanged
        RefreshDataGridView1Sold()
    End Sub
    Private Sub Txt_Search_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Search.TextChanged
        RefreshDataGridView1Sold()
    End Sub
    ' ✅ Function para i-load ang listahan ng Months (January - December)
    Private Sub LoadMonths()
        Cb_Month.Items.Clear()
        Cb_Month.Items.Add("All") ' Default option

        Dim monthNames() As String = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        }

        ' Add month names
        For Each month As String In monthNames
            Cb_Month.Items.Add(month)
        Next

        Cb_Month.SelectedIndex = 0 ' Default select "All"
    End Sub
    ' ✅ Function para i-load ang listahan ng Years (Fixed from 2024 - 2050)
    Private Sub LoadYears()
        Dim startYear As Integer = 2024 ' ✅ Fixed start year
        Dim endYear As Integer = 2050   ' ✅ Fixed end year

        Try
            Cb_Year.Items.Clear()
            Cb_Year.Items.Add("All") ' Default option

            ' ✅ Siguraduhin na lahat ng taon mula 2024 hanggang 2050 ay nandito
            For year As Integer = startYear To endYear
                Cb_Year.Items.Add(year.ToString())
            Next

            Cb_Year.SelectedIndex = 0 ' Default select "All"

        Catch ex As Exception
            MessageBox.Show("Error loading years: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub RefreshDataGridView1Sold()
        Try
            ' Base query na may WHERE clause para sa madaling pagdagdag ng filters
            Dim query As String = "SELECT ID, RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                  "SmallWaterGallon, SmallContainerwithWater, SmallContainer, Date " & _
                                  "FROM Sold WHERE 1=1"

            ' ✅ Search Filter gamit ang mga numeric columns (gamit ang CAST para makapag-search ng string)
            Dim searchKeyword As String = Txt_Search.Text.Trim()
            If Not String.IsNullOrEmpty(searchKeyword) Then
                query &= " AND (CAST(ID AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegWaterGallon AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegContainerwithWater AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegContainer AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallWaterGallon AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallContainerwithWater AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallContainer AS VARCHAR(50)) LIKE @Search)"
            End If

            ' ✅ Month Filtering gamit ang Date column
            Dim selectedMonth As String = "All"
            Dim monthNumber As Integer = 0
            If Cb_Month.SelectedItem IsNot Nothing Then
                selectedMonth = Cb_Month.SelectedItem.ToString()
            End If
            If selectedMonth <> "All" Then
                monthNumber = Array.IndexOf( _
                    New String() {"January", "February", "March", "April", "May", "June", _
                                  "July", "August", "September", "October", "November", "December"}, selectedMonth) + 1
                query &= " AND MONTH(Date) = @Month"
            End If

            ' ✅ Year Filtering gamit ang Date column
            Dim selectedYear As String = "All"
            If Cb_Year.SelectedItem IsNot Nothing Then
                selectedYear = Cb_Year.SelectedItem.ToString()
            End If
            If selectedYear <> "All" Then
                query &= " AND YEAR(Date) = @Year"
            End If

            ' ✅ Sorting by Date (Oldest First para ang latest na insert ay nasa baba)
            query &= " ORDER BY Date ASC"

            Dim dt As New DataTable()

            ' Using block para sa tamang pamamahala ng connection
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    If Not String.IsNullOrEmpty(searchKeyword) Then
                        cmd.Parameters.AddWithValue("@Search", "%" & searchKeyword & "%")
                    End If

                    If selectedMonth <> "All" Then
                        cmd.Parameters.AddWithValue("@Month", monthNumber)
                    End If

                    If selectedYear <> "All" Then
                        cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(selectedYear))
                    End If

                    conn.Open()
                    Dim adapter As New SqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using

            ' I-bind ang DataTable sa DataGridView
            DataGridView1.DataSource = dt

            ' I-update ang header texts ng mga columns
            DataGridView1.Columns("RegWaterGallon").HeaderText = "Reg Water Gallon"
            DataGridView1.Columns("RegContainerwithWater").HeaderText = "Reg Container with Water"
            DataGridView1.Columns("RegContainer").HeaderText = "Reg Container"
            DataGridView1.Columns("SmallWaterGallon").HeaderText = "Small Water Gallon"
            DataGridView1.Columns("SmallContainerwithWater").HeaderText = "Small Container with Water"
            DataGridView1.Columns("SmallContainer").HeaderText = "Small Container"

            ' I-set ang alignment para sa bawat column at i-format ang Date column
            For Each col As DataGridViewColumn In DataGridView1.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                If col.Name = "Date" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next

            ' I-set ang alignment ng row headers
            DataGridView1.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_SelectionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataGridView1.SelectionChanged
        ' Disable the update/submit buttons if more than one row is selected
        If DataGridView1.SelectedRows.Count > 1 Then
            Btn_Update.Enabled = False
            Btn_Submit.Enabled = False
        Else
            Btn_Update.Enabled = True
            Btn_Submit.Enabled = True
        End If

        ' If a row is selected, populate the text boxes and date picker with its data
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)

            ' Regular fields
            Txt_WaterRefill.Text = selectedRow.Cells("RegWaterGallon").Value.ToString()
            Txt_ContainerWater.Text = selectedRow.Cells("RegContainerwithWater").Value.ToString()
            Txt_Container.Text = selectedRow.Cells("RegContainer").Value.ToString()

            ' Small fields (ensure these controls exist; otherwise, remove these lines)
            Txt_SmallWaterRefill.Text = selectedRow.Cells("SmallWaterGallon").Value.ToString()
            Txt_SmallContainerWater.Text = selectedRow.Cells("SmallContainerwithWater").Value.ToString()
            Txt_SmallContainer.Text = selectedRow.Cells("SmallContainer").Value.ToString()

            ' Set the DateTimePicker with the selected date
            Dim selectedDate As Date = Convert.ToDateTime(selectedRow.Cells("Date").Value)
            DateTimePicker1.Value = selectedDate
        Else
            ' If no row is selected, clear all text boxes and reset the DateTimePicker to the current date/time
            ClearTextBoxes()

            DateTimePicker1.Value = DateTime.Now
        End If
    End Sub

    Private Sub Txt_WaterRefill_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_WaterRefill.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Txt_Container_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Container.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Txt_ContainerWater_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_ContainerWater.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Btn_IncomeReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_IncomeReport.Click
        Try
            ' Ensure at least two rows are selected to determine a date range
            If DataGridView1.SelectedRows.Count < 2 Then
                MessageBox.Show("Please select at least two rows to generate the report.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Determine the start and end dates from the selected rows
            Dim startDate As Date = Date.MaxValue
            Dim endDate As Date = Date.MinValue

            For Each selectedRow As DataGridViewRow In DataGridView1.SelectedRows
                Dim rowDate As Date = Convert.ToDateTime(selectedRow.Cells("Date").Value)
                If rowDate < startDate Then
                    startDate = rowDate
                End If
                If rowDate > endDate Then
                    endDate = rowDate
                End If
            Next

            ' Ask for confirmation before generating the report
            Dim confirmationResult As DialogResult = MessageBox.Show( _
                "Are you sure you want to generate the report for the period: " & startDate.ToShortDateString() & " to " & endDate.ToShortDateString() & "?", _
                "Confirm Report Generation", _
                MessageBoxButtons.YesNo, _
                MessageBoxIcon.Question)

            If confirmationResult = DialogResult.No Then
                Return ' Exit if the user chooses No
            End If

            Using conn As New SqlConnection(connectionString)
                conn.Open()

                ' 1. Check if an exact report exists with the same StartDate and EndDate
                Dim exactCheckQuery As String = "SELECT COUNT(*) FROM IncomeReport WHERE StartDate = @StartDate AND EndDate = @EndDate"
                Using exactCmd As New SqlCommand(exactCheckQuery, conn)
                    exactCmd.Parameters.AddWithValue("@StartDate", startDate)
                    exactCmd.Parameters.AddWithValue("@EndDate", endDate)
                    Dim exactCount As Integer = Convert.ToInt32(exactCmd.ExecuteScalar())
                    If exactCount > 0 Then
                        MessageBox.Show("A report for the period " & startDate.ToShortDateString() & " to " & endDate.ToShortDateString() & " already exists.", _
                                        "Report Exists", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        Return
                    End If
                End Using

                ' 2. Check if any report exists that overlaps with the selected date range.
                Dim overlapCheckQuery As String = "SELECT COUNT(*) FROM IncomeReport WHERE @StartDate <= EndDate AND @EndDate >= StartDate"
                Using overlapCmd As New SqlCommand(overlapCheckQuery, conn)
                    overlapCmd.Parameters.AddWithValue("@StartDate", startDate)
                    overlapCmd.Parameters.AddWithValue("@EndDate", endDate)
                    Dim overlapCount As Integer = Convert.ToInt32(overlapCmd.ExecuteScalar())
                    If overlapCount > 0 Then
                        MessageBox.Show("A report overlapping with the period " & startDate.ToShortDateString() & " to " & endDate.ToShortDateString() & " already exists.", _
                                        "Report Overlap", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        Return
                    End If
                End Using

                ' Calculate totals from the GrossRevenue table within the selected date range, including small container fields
                Dim waterRefillGallonTotal As Decimal = 0
                Dim containerWithWaterTotal As Decimal = 0
                Dim containerTotal As Decimal = 0
                Dim smallWaterGallonTotal As Decimal = 0
                Dim smallContainerWithWaterTotal As Decimal = 0
                Dim smallContainerTotal As Decimal = 0
                Dim overallTotal As Decimal = 0
                Dim selectedRowsCount As Integer = DataGridView1.SelectedRows.Count

                ' Query to calculate totals from GrossRevenue, including small container fields
                Dim query As String = "SELECT SUM(RegWaterGallon), SUM(RegContainerwithWater), SUM(RegContainer), " & _
                                      "SUM(SmallWaterGallon), SUM(SmallContainerwithWater), SUM(SmallContainer), SUM(GrossRevenue) " & _
                                      "FROM GrossRevenue WHERE [Date] BETWEEN @StartDate AND @EndDate"
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@StartDate", startDate)
                    cmd.Parameters.AddWithValue("@EndDate", endDate)
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        If reader.Read() Then
                            If Not reader.IsDBNull(0) Then waterRefillGallonTotal = Convert.ToDecimal(reader(0))
                            If Not reader.IsDBNull(1) Then containerWithWaterTotal = Convert.ToDecimal(reader(1))
                            If Not reader.IsDBNull(2) Then containerTotal = Convert.ToDecimal(reader(2))
                            If Not reader.IsDBNull(3) Then smallWaterGallonTotal = Convert.ToDecimal(reader(3))
                            If Not reader.IsDBNull(4) Then smallContainerWithWaterTotal = Convert.ToDecimal(reader(4))
                            If Not reader.IsDBNull(5) Then smallContainerTotal = Convert.ToDecimal(reader(5))
                            If Not reader.IsDBNull(6) Then overallTotal = Convert.ToDecimal(reader(6))
                        End If
                    End Using
                End Using

                ' Insert the generated report into the IncomeReport table, including the small container fields
                Dim insertQuery As String = "INSERT INTO IncomeReport (StartDate, EndDate, RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                            "SmallWaterGallon, SmallContainerwithWater, SmallContainer, Total, Rows) " & _
                                            "VALUES (@StartDate, @EndDate, @WaterRefillGallon, @ContainerWithWater, @Container, " & _
                                            "@SmallWaterGallon, @SmallContainerWithWater, @SmallContainer, @Total, @Rows)"
                Using cmd As New SqlCommand(insertQuery, conn)
                    cmd.Parameters.AddWithValue("@StartDate", startDate)
                    cmd.Parameters.AddWithValue("@EndDate", endDate)
                    cmd.Parameters.AddWithValue("@WaterRefillGallon", waterRefillGallonTotal)
                    cmd.Parameters.AddWithValue("@ContainerWithWater", containerWithWaterTotal)
                    cmd.Parameters.AddWithValue("@Container", containerTotal)
                    cmd.Parameters.AddWithValue("@SmallWaterGallon", smallWaterGallonTotal)
                    cmd.Parameters.AddWithValue("@SmallContainerWithWater", smallContainerWithWaterTotal)
                    cmd.Parameters.AddWithValue("@SmallContainer", smallContainerTotal)
                    cmd.Parameters.AddWithValue("@Total", overallTotal)
                    cmd.Parameters.AddWithValue("@Rows", selectedRowsCount)
                    cmd.ExecuteNonQuery()
                End Using

                MessageBox.Show("Report generated successfully for the period: " & startDate.ToShortDateString() & " to " & endDate.ToShortDateString() & ".", _
                                "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                ' Refresh all DataGridViews and clear selections/text boxes
                RefreshDataGridView1Sold()
                RefreshDataGridView2()
                ClearTextBoxes()
                RefreshDataGridView1Report()

                DataGridView1.ClearSelection()
                DataGridView2.ClearSelection()
                Reports.DataGridView1.ClearSelection()
            End Using

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub RefreshDataGridView1Report()
        Try
            conn.Open()

            Dim query As String = "SELECT ID, RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                  "SmallWaterGallon, SmallContainerwithWater, SmallContainer, Total, Rows, StartDate, EndDate FROM IncomeReport"

            Using cmd As New SqlCommand(query, conn)
                Using adapter As New SqlDataAdapter(cmd)
                    Dim dt As New DataTable()
                    adapter.Fill(dt)

                    ' Assuming that the Income Report is displayed in Reports.DataGridView1
                    Reports.DataGridView1.DataSource = dt

                    ' Set content alignment and date formatting for each column
                    For Each col As DataGridViewColumn In Reports.DataGridView1.Columns
                        col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                        If col.Name = "StartDate" OrElse col.Name = "EndDate" Then
                            col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                        End If
                    Next

                    ' Set row header alignment for the Income Report DataGridView
                    Reports.DataGridView1.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub Btn_Submit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Submit.Click
        Try
            ' Kung ang isang TextBox ay hindi visible, i-assign ang default value na "0"
            If Not Txt_WaterRefill.Visible Then Txt_WaterRefill.Text = "0"
            If Not Txt_ContainerWater.Visible Then Txt_ContainerWater.Text = "0"
            If Not Txt_Container.Visible Then Txt_Container.Text = "0"
            If Not Txt_SmallWaterRefill.Visible Then Txt_SmallWaterRefill.Text = "0"
            If Not Txt_SmallContainerWater.Visible Then Txt_SmallContainerWater.Text = "0"
            If Not Txt_SmallContainer.Visible Then Txt_SmallContainer.Text = "0"

            ' Validation: para sa mga visible TextBoxes, siguraduhing may laman
            If (Txt_WaterRefill.Visible AndAlso String.IsNullOrWhiteSpace(Txt_WaterRefill.Text)) OrElse _
               (Txt_ContainerWater.Visible AndAlso String.IsNullOrWhiteSpace(Txt_ContainerWater.Text)) OrElse _
               (Txt_Container.Visible AndAlso String.IsNullOrWhiteSpace(Txt_Container.Text)) OrElse _
               (Txt_SmallWaterRefill.Visible AndAlso String.IsNullOrWhiteSpace(Txt_SmallWaterRefill.Text)) OrElse _
               (Txt_SmallContainerWater.Visible AndAlso String.IsNullOrWhiteSpace(Txt_SmallContainerWater.Text)) OrElse _
               (Txt_SmallContainer.Visible AndAlso String.IsNullOrWhiteSpace(Txt_SmallContainer.Text)) Then

                MessageBox.Show("Please fill in all required fields.", "Incomplete Field", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Parse input values for regular and small fields
            Dim waterRefillGallon, containerWithWater, container As Integer
            Dim smallWaterRefill, smallContainerWater, smallContainer As Integer

            If Not Integer.TryParse(Txt_WaterRefill.Text, waterRefillGallon) OrElse _
               Not Integer.TryParse(Txt_ContainerWater.Text, containerWithWater) OrElse _
               Not Integer.TryParse(Txt_Container.Text, container) OrElse _
               Not Integer.TryParse(Txt_SmallWaterRefill.Text, smallWaterRefill) OrElse _
               Not Integer.TryParse(Txt_SmallContainerWater.Text, smallContainerWater) OrElse _
               Not Integer.TryParse(Txt_SmallContainer.Text, smallContainer) Then

                MessageBox.Show("Please enter valid numeric values for all fields.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Retrieve prices for both regular and small items
            Dim waterRefillGallonPrice, containerWithWaterPrice, containerPrice As Integer
            Dim smallWaterRefillPrice, smallContainerWaterPrice, smallContainerPrice As Integer

            Using conn As New SqlConnection(connectionString)
                conn.Open()
                Dim priceQuery As String = "SELECT RegWaterGallon, RegContainerwithWater, RegContainer, SmallWaterGallon, SmallContainerwithWater, SmallContainer FROM Price"
                Using cmd As New SqlCommand(priceQuery, conn)
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        If reader.Read() Then
                            waterRefillGallonPrice = reader.GetInt32(0)
                            containerWithWaterPrice = reader.GetInt32(1)
                            containerPrice = reader.GetInt32(2)
                            smallWaterRefillPrice = reader.GetInt32(3)
                            smallContainerWaterPrice = reader.GetInt32(4)
                            smallContainerPrice = reader.GetInt32(5)
                        Else
                            MessageBox.Show("Prices not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Return
                        End If
                    End Using
                End Using

                ' Calculate totals for regular items
                Dim waterRefillGallonTotal = waterRefillGallon * waterRefillGallonPrice
                Dim containerWithWaterTotal = containerWithWater * containerWithWaterPrice
                Dim containerTotal = container * containerPrice

                ' Calculate totals for small items
                Dim smallWaterRefillTotal = smallWaterRefill * smallWaterRefillPrice
                Dim smallContainerWaterTotal = smallContainerWater * smallContainerWaterPrice
                Dim smallContainerTotal = smallContainer * smallContainerPrice

                ' Calculate overall total (sum of both regular and small totals)
                Dim total = waterRefillGallonTotal + containerWithWaterTotal + containerTotal + _
                            smallWaterRefillTotal + smallContainerWaterTotal + smallContainerTotal

                ' Use the selected date from the DateTimePicker
                Dim [date] As Date = DateTimePicker1.Value.Date

                ' Check for duplicate date in the Sold table
                Dim checkDateQuery As String = "SELECT COUNT(*) FROM Sold WHERE [Date] = @Date"
                Using checkCmd As New SqlCommand(checkDateQuery, conn)
                    checkCmd.Parameters.Add("@Date", SqlDbType.Date).Value = [date]
                    If Convert.ToInt32(checkCmd.ExecuteScalar()) > 0 Then
                        MessageBox.Show("The date for this data already exists.", "Duplicate Date", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        RefreshDataGridView1Sold()
                        RefreshDataGridView2()
                        DataGridView1.ClearSelection()
                        ClearTextBoxes()
                        Return
                    End If
                End Using

                ' Insert data into the Sold table (including both regular and small fields)
                Dim soldQuery As String = "INSERT INTO Sold (RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                          "SmallWaterGallon, SmallContainerwithWater, SmallContainer, [Date]) " & _
                                          "OUTPUT INSERTED.ID " & _
                                          "VALUES (@RegWaterGallon, @RegContainerwithWater, @RegContainer, " & _
                                          "@SmallWaterGallon, @SmallContainerwithWater, @SmallContainer, @Date)"
                Using soldCmd As New SqlCommand(soldQuery, conn)
                    soldCmd.Parameters.Add("@RegWaterGallon", SqlDbType.Int).Value = waterRefillGallon
                    soldCmd.Parameters.Add("@RegContainerwithWater", SqlDbType.Int).Value = containerWithWater
                    soldCmd.Parameters.Add("@RegContainer", SqlDbType.Int).Value = container
                    soldCmd.Parameters.Add("@SmallWaterGallon", SqlDbType.Int).Value = smallWaterRefill
                    soldCmd.Parameters.Add("@SmallContainerwithWater", SqlDbType.Int).Value = smallContainerWater
                    soldCmd.Parameters.Add("@SmallContainer", SqlDbType.Int).Value = smallContainer
                    soldCmd.Parameters.Add("@Date", SqlDbType.Date).Value = [date]
                    Dim soldID As Integer = Convert.ToInt32(soldCmd.ExecuteScalar())

                    ' Insert data into the GrossRevenue table (using totals for both regular and small items)
                    Dim incomeQuery As String = "INSERT INTO GrossRevenue (RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                                "SmallWaterGallon, SmallContainerwithWater, SmallContainer, GrossRevenue, [Date]) " & _
                                                "VALUES (@RegWaterGallon, @RegContainerwithWater, @RegContainer, " & _
                                                "@SmallWaterGallon, @SmallContainerwithWater, @SmallContainer, @GrossRevenue, @Date)"
                    Using incomeCmd As New SqlCommand(incomeQuery, conn)
                        incomeCmd.Parameters.Add("@RegWaterGallon", SqlDbType.Int).Value = waterRefillGallonTotal
                        incomeCmd.Parameters.Add("@RegContainerwithWater", SqlDbType.Int).Value = containerWithWaterTotal
                        incomeCmd.Parameters.Add("@RegContainer", SqlDbType.Int).Value = containerTotal
                        incomeCmd.Parameters.Add("@SmallWaterGallon", SqlDbType.Int).Value = smallWaterRefillTotal
                        incomeCmd.Parameters.Add("@SmallContainerwithWater", SqlDbType.Int).Value = smallContainerWaterTotal
                        incomeCmd.Parameters.Add("@SmallContainer", SqlDbType.Int).Value = smallContainerTotal
                        incomeCmd.Parameters.Add("@GrossRevenue", SqlDbType.Int).Value = total
                        incomeCmd.Parameters.Add("@Date", SqlDbType.Date).Value = [date]
                        incomeCmd.ExecuteNonQuery()
                    End Using
                End Using
            End Using

            ' Success message and refresh operations
            MessageBox.Show("Data submitted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            RefreshDataGridView1Sold()
            DataGridView1.ClearSelection()
            RefreshDataGridView2()
            ClearTextBoxes()
            Home.LoadAllData()
            Home.LoadMonthlyNetIncomeChart()
            Home.LoadMonthlyNetIncomeChartSmall()

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            If DataGridView1.SelectedRows.Count > 0 Then
                Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete the selected row(s)?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                If result = DialogResult.Yes Then
                    Using conn As New SqlConnection(connectionString)
                        conn.Open()

                        Dim transaction As SqlTransaction = conn.BeginTransaction()

                        Try
                            ' Fetch prices from the Price table including small fields
                            Dim waterRefillGallonPrice, containerWithWaterPrice, containerPrice As Integer
                            Dim smallWaterRefillPrice, smallContainerWaterPrice, smallContainerPrice As Integer
                            Dim priceQuery As String = "SELECT RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                                       "SmallWaterGallon, SmallContainerwithWater, SmallContainer FROM Price"
                            Using cmdPrice As New SqlCommand(priceQuery, conn, transaction)
                                Using reader As SqlDataReader = cmdPrice.ExecuteReader()
                                    If reader.Read() Then
                                        waterRefillGallonPrice = reader.GetInt32(0)
                                        containerWithWaterPrice = reader.GetInt32(1)
                                        containerPrice = reader.GetInt32(2)
                                        smallWaterRefillPrice = reader.GetInt32(3)
                                        smallContainerWaterPrice = reader.GetInt32(4)
                                        smallContainerPrice = reader.GetInt32(5)
                                    Else
                                        MessageBox.Show("Prices not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                        transaction.Rollback()
                                        Return
                                    End If
                                End Using
                            End Using

                            ' Process each selected row for deletion
                            For Each selectedRow As DataGridViewRow In DataGridView1.SelectedRows
                                Dim selectedID As Integer = Convert.ToInt32(selectedRow.Cells("ID").Value)

                                ' Retrieve regular fields
                                Dim waterRefillGallon As Integer = Convert.ToInt32(selectedRow.Cells("RegWaterGallon").Value)
                                Dim containerWithWater As Integer = Convert.ToInt32(selectedRow.Cells("RegContainerwithWater").Value)
                                Dim container As Integer = Convert.ToInt32(selectedRow.Cells("RegContainer").Value)

                                ' Retrieve small fields
                                Dim smallWaterRefill As Integer = Convert.ToInt32(selectedRow.Cells("SmallWaterGallon").Value)
                                Dim smallContainerWater As Integer = Convert.ToInt32(selectedRow.Cells("SmallContainerwithWater").Value)
                                Dim smallContainer As Integer = Convert.ToInt32(selectedRow.Cells("SmallContainer").Value)

                                Dim [date] As Date = Convert.ToDateTime(selectedRow.Cells("Date").Value)

                                ' Recalculate totals for regular items
                                Dim waterRefillGallonTotal As Integer = waterRefillGallon * waterRefillGallonPrice
                                Dim containerWithWaterTotal As Integer = containerWithWater * containerWithWaterPrice
                                Dim containerTotal As Integer = container * containerPrice

                                ' Recalculate totals for small items
                                Dim smallWaterRefillTotal As Integer = smallWaterRefill * smallWaterRefillPrice
                                Dim smallContainerWaterTotal As Integer = smallContainerWater * smallContainerWaterPrice
                                Dim smallContainerTotal As Integer = smallContainer * smallContainerPrice

                                ' Overall total (regular + small)
                                Dim total As Integer = waterRefillGallonTotal + containerWithWaterTotal + containerTotal + _
                                                       smallWaterRefillTotal + smallContainerWaterTotal + smallContainerTotal

                                ' Back up the record in SoldBackup (including small fields)
                                Dim soldBackupQuery As String = "INSERT INTO SoldBackup (RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                                                "SmallWaterGallon, SmallContainerwithWater, SmallContainer, [Date]) " & _
                                                                "VALUES (@RegWaterGallon, @RegContainerwithWater, @RegContainer, " & _
                                                                "@SmallWaterGallon, @SmallContainerwithWater, @SmallContainer, @Date)"
                                Using cmdSoldBackup As New SqlCommand(soldBackupQuery, conn, transaction)
                                    cmdSoldBackup.Parameters.AddWithValue("@RegWaterGallon", waterRefillGallon)
                                    cmdSoldBackup.Parameters.AddWithValue("@RegContainerwithWater", containerWithWater)
                                    cmdSoldBackup.Parameters.AddWithValue("@RegContainer", container)
                                    cmdSoldBackup.Parameters.AddWithValue("@SmallWaterGallon", smallWaterRefill)
                                    cmdSoldBackup.Parameters.AddWithValue("@SmallContainerwithWater", smallContainerWater)
                                    cmdSoldBackup.Parameters.AddWithValue("@SmallContainer", smallContainer)
                                    cmdSoldBackup.Parameters.AddWithValue("@Date", [date])
                                    cmdSoldBackup.ExecuteNonQuery()
                                End Using

                                ' Back up the record in GrossRevenueBackup (including small fields and overall total)
                                Dim incomeBackupQuery As String = "INSERT INTO GrossRevenueBackup (RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                                                  "SmallWaterGallon, SmallContainerwithWater, SmallContainer, GrossRevenue, [Date]) " & _
                                                                  "VALUES (@RegWaterGallon, @RegContainerwithWater, @RegContainer, " & _
                                                                  "@SmallWaterGallon, @SmallContainerwithWater, @SmallContainer, @GrossRevenue, @Date)"
                                Using cmdIncomeBackup As New SqlCommand(incomeBackupQuery, conn, transaction)
                                    cmdIncomeBackup.Parameters.AddWithValue("@RegWaterGallon", waterRefillGallonTotal)
                                    cmdIncomeBackup.Parameters.AddWithValue("@RegContainerwithWater", containerWithWaterTotal)
                                    cmdIncomeBackup.Parameters.AddWithValue("@RegContainer", containerTotal)
                                    cmdIncomeBackup.Parameters.AddWithValue("@SmallWaterGallon", smallWaterRefillTotal)
                                    cmdIncomeBackup.Parameters.AddWithValue("@SmallContainerwithWater", smallContainerWaterTotal)
                                    cmdIncomeBackup.Parameters.AddWithValue("@SmallContainer", smallContainerTotal)
                                    cmdIncomeBackup.Parameters.AddWithValue("@GrossRevenue", total)
                                    cmdIncomeBackup.Parameters.AddWithValue("@Date", [date])
                                    cmdIncomeBackup.ExecuteNonQuery()
                                End Using

                                ' Delete child records in the NetIncome table
                                Dim deleteNetIncomeQuery As String = "DELETE FROM NetIncome WHERE GrossRevenueID = @ID"
                                Using cmdDeleteNetIncome As New SqlCommand(deleteNetIncomeQuery, conn, transaction)
                                    cmdDeleteNetIncome.Parameters.AddWithValue("@ID", selectedID)
                                    cmdDeleteNetIncome.ExecuteNonQuery()
                                End Using

                                ' Delete from GrossRevenue table
                                Dim deleteIncomeQuery As String = "DELETE FROM GrossRevenue WHERE ID = @ID"
                                Using cmdDeleteIncome As New SqlCommand(deleteIncomeQuery, conn, transaction)
                                    cmdDeleteIncome.Parameters.AddWithValue("@ID", selectedID)
                                    cmdDeleteIncome.ExecuteNonQuery()
                                End Using

                                ' Delete from Sold table
                                Dim deleteSoldQuery As String = "DELETE FROM Sold WHERE ID = @ID"
                                Using cmdDeleteSold As New SqlCommand(deleteSoldQuery, conn, transaction)
                                    cmdDeleteSold.Parameters.AddWithValue("@ID", selectedID)
                                    cmdDeleteSold.ExecuteNonQuery()
                                End Using
                            Next

                            transaction.Commit()

                            MessageBox.Show("Selected row(s) deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                            RefreshDataGridView1Sold()
                            RefreshDataGridView2()
                            ClearTextBoxes()
                            RefreshDataGridView2SoldBackup()

                            DataGridView1.ClearSelection()
                            DataGridView2.ClearSelection()

                            RecycleBin.DataGridView2.ClearSelection()
                            Home.LoadAllData()
                            Home.LoadMonthlyNetIncomeChart()
                            Home.LoadMonthlyNetIncomeChartSmall()
                        Catch ex As Exception
                            transaction.Rollback()
                            MessageBox.Show("Transaction failed: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End Using
                End If
            Else
                MessageBox.Show("Please select records to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub Btn_Update_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Update.Click
        Try
            ' Validate that all required fields (regular and small) are filled
            If Txt_WaterRefill.Text.Trim() = "" OrElse _
               Txt_ContainerWater.Text.Trim() = "" OrElse _
               Txt_Container.Text.Trim() = "" OrElse _
               Txt_SmallWaterRefill.Text.Trim() = "" OrElse _
               Txt_SmallContainerWater.Text.Trim() = "" OrElse _
               Txt_SmallContainer.Text.Trim() = "" Then

                MessageBox.Show("Please fill in all required fields.", "Incomplete Data", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Ensure a single record is selected in the DataGridView
            If DataGridView1.SelectedRows.Count <> 1 Then
                MessageBox.Show("Please select a single record to update.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            Using conn As New SqlConnection(connectionString)
                conn.Open()

                ' Get data from textboxes
                Dim waterRefillGallon As Integer = Integer.Parse(Txt_WaterRefill.Text)
                Dim containerWithWater As Integer = Integer.Parse(Txt_ContainerWater.Text)
                Dim container As Integer = Integer.Parse(Txt_Container.Text)
                Dim smallWaterRefill As Integer = Integer.Parse(Txt_SmallWaterRefill.Text)
                Dim smallContainerWater As Integer = Integer.Parse(Txt_SmallContainerWater.Text)
                Dim smallContainer As Integer = Integer.Parse(Txt_SmallContainer.Text)
                Dim [date] As Date = DateTimePicker1.Value ' Use the date from DateTimePicker1

                ' Retrieve prices from the Price table including small fields
                Dim priceQuery As String = "SELECT RegWaterGallon, RegContainerwithWater, RegContainer, SmallWaterGallon, SmallContainerwithWater, SmallContainer FROM Price"
                Using cmd As New SqlCommand(priceQuery, conn)
                    Dim reader As SqlDataReader = cmd.ExecuteReader()
                    If reader.HasRows Then
                        If reader.Read() Then
                            Dim waterRefillGallonPrice As Integer = reader.GetInt32(0)
                            Dim containerWithWaterPrice As Integer = reader.GetInt32(1)
                            Dim containerPrice As Integer = reader.GetInt32(2)
                            Dim smallWaterRefillPrice As Integer = reader.GetInt32(3)
                            Dim smallContainerWaterPrice As Integer = reader.GetInt32(4)
                            Dim smallContainerPrice As Integer = reader.GetInt32(5)
                            reader.Close()

                            ' Calculate totals for regular items
                            Dim waterRefillGallonTotal As Integer = waterRefillGallon * waterRefillGallonPrice
                            Dim containerWithWaterTotal As Integer = containerWithWater * containerWithWaterPrice
                            Dim containerTotal As Integer = container * containerPrice

                            ' Calculate totals for small items
                            Dim smallWaterRefillTotal As Integer = smallWaterRefill * smallWaterRefillPrice
                            Dim smallContainerWaterTotal As Integer = smallContainerWater * smallContainerWaterPrice
                            Dim smallContainerTotal As Integer = smallContainer * smallContainerPrice

                            ' Calculate overall total (regular + small)
                            Dim total As Integer = waterRefillGallonTotal + containerWithWaterTotal + containerTotal + _
                                                   smallWaterRefillTotal + smallContainerWaterTotal + smallContainerTotal

                            ' Update data in the Sold table (including small fields)
                            Dim updateSoldQuery As String = "UPDATE Sold SET RegWaterGallon = @RegWaterGallon, " & _
                                                              "RegContainerwithWater = @RegContainerwithWater, RegContainer = @RegContainer, " & _
                                                              "SmallWaterGallon = @SmallWaterGallon, SmallContainerwithWater = @SmallContainerwithWater, " & _
                                                              "SmallContainer = @SmallContainer, [Date] = @Date " & _
                                                              "WHERE ID = @ID"
                            Using cmdUpdateSold As New SqlCommand(updateSoldQuery, conn)
                                cmdUpdateSold.Parameters.AddWithValue("@RegWaterGallon", waterRefillGallon)
                                cmdUpdateSold.Parameters.AddWithValue("@RegContainerwithWater", containerWithWater)
                                cmdUpdateSold.Parameters.AddWithValue("@RegContainer", container)
                                cmdUpdateSold.Parameters.AddWithValue("@SmallWaterGallon", smallWaterRefill)
                                cmdUpdateSold.Parameters.AddWithValue("@SmallContainerwithWater", smallContainerWater)
                                cmdUpdateSold.Parameters.AddWithValue("@SmallContainer", smallContainer)
                                cmdUpdateSold.Parameters.AddWithValue("@Date", [date])
                                cmdUpdateSold.Parameters.AddWithValue("@ID", DataGridView1.SelectedRows(0).Cells("ID").Value)
                                cmdUpdateSold.ExecuteNonQuery()
                            End Using

                            ' Update data in the GrossRevenue table (including recalculated totals for both regular and small fields)
                            Dim updateIncomeQuery As String = "UPDATE GrossRevenue SET RegWaterGallon = @RegWaterGallonTotal, " & _
                                                                "RegContainerwithWater = @RegContainerwithWaterTotal, RegContainer = @RegContainerTotal, " & _
                                                                "SmallWaterGallon = @SmallWaterGallonTotal, SmallContainerwithWater = @SmallContainerwithWaterTotal, " & _
                                                                "SmallContainer = @SmallContainerTotal, GrossRevenue = @GrossRevenue, [Date] = @Date " & _
                                                                "WHERE ID = @ID"
                            Using cmdUpdateIncome As New SqlCommand(updateIncomeQuery, conn)
                                cmdUpdateIncome.Parameters.AddWithValue("@RegWaterGallonTotal", waterRefillGallonTotal)
                                cmdUpdateIncome.Parameters.AddWithValue("@RegContainerwithWaterTotal", containerWithWaterTotal)
                                cmdUpdateIncome.Parameters.AddWithValue("@RegContainerTotal", containerTotal)
                                cmdUpdateIncome.Parameters.AddWithValue("@SmallWaterGallonTotal", smallWaterRefillTotal)
                                cmdUpdateIncome.Parameters.AddWithValue("@SmallContainerwithWaterTotal", smallContainerWaterTotal)
                                cmdUpdateIncome.Parameters.AddWithValue("@SmallContainerTotal", smallContainerTotal)
                                cmdUpdateIncome.Parameters.AddWithValue("@GrossRevenue", total)
                                cmdUpdateIncome.Parameters.AddWithValue("@Date", [date])
                                cmdUpdateIncome.Parameters.AddWithValue("@ID", DataGridView1.SelectedRows(0).Cells("ID").Value)
                                cmdUpdateIncome.ExecuteNonQuery()
                            End Using
                        End If
                    Else
                        MessageBox.Show("Prices not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return
                    End If
                End Using

                MessageBox.Show("Data updated successfully.", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information)

                RefreshDataGridView1Sold()
                RefreshDataGridView2()
                ClearTextBoxes()

                DataGridView1.ClearSelection()
                DataGridView2.ClearSelection()
                Home.LoadAllData()
                Home.LoadMonthlyNetIncomeChart()
                Home.LoadMonthlyNetIncomeChartSmall()
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub RefreshDataGridView2SoldBackup() ' Tab1
        Try
            conn.Open()
            Dim query As String = "SELECT ID, RegWaterGallon, RegContainerwithWater, RegContainer, SmallWaterGallon, SmallContainerwithWater, SmallContainer, Date FROM SoldBackup"

            cmd = New SqlCommand(query, conn)
            adapter = New SqlDataAdapter(cmd)
            dt = New DataTable()
            adapter.Fill(dt)

            RecycleBin.DataGridView2.DataSource = dt

            ' Set content alignment for each column
            For Each col As DataGridViewColumn In RecycleBin.DataGridView2.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                ' Check if column is Date column, then format the date to display month name
                If col.Name = "Date" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next

            ' Set row header alignment
            DataGridView2.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Catch ex As Exception
            MessageBox.Show("Error refreshing data grid: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    'Tab 3
    Private Sub Btn_Refresh1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh1.Click
        RefreshDataGridView2()
        DataGridView2.ClearSelection()
        Txt_Search1.Clear()
        Cb_Month1.SelectedIndex = 0
        Cb_Year1.SelectedItem = 0
    End Sub
    Private Sub Txt_Search1_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Search1.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        ' Limit the length of the text to 11 characters
        If Txt_Search1.TextLength >= 11 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    Private Sub Txt_Search1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Search1.TextChanged
        RefreshDataGridView2()
    End Sub

    Private Sub Cb_Month1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Month1.SelectedIndexChanged
        RefreshDataGridView2()
    End Sub

    Private Sub Cb_Year1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Year1.SelectedIndexChanged
        RefreshDataGridView2()
    End Sub
    ' ✅ Function para i-load ang listahan ng Months (January - December)
    Private Sub LoadMonths1()
        Cb_Month1.Items.Clear()
        Cb_Month1.Items.Add("All") ' Default option

        Dim monthNames() As String = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        }

        ' Add month names
        For Each month As String In monthNames
            Cb_Month1.Items.Add(month)
        Next

        Cb_Month1.SelectedIndex = 0 ' Default select "All"
    End Sub
    ' ✅ Function para i-load ang listahan ng Years (Fixed from 2024 - 2050)
    Private Sub LoadYears1()
        Dim startYear As Integer = 2024 ' ✅ Fixed start year
        Dim endYear As Integer = 2050   ' ✅ Fixed end year

        Try
            Cb_Year1.Items.Clear()
            Cb_Year1.Items.Add("All") ' Default option

            ' ✅ Siguraduhin na lahat ng taon mula 2024 hanggang 2050 ay nandito
            For year As Integer = startYear To endYear
                Cb_Year1.Items.Add(year.ToString())
            Next

            Cb_Year1.SelectedIndex = 0 ' Default select "All"

        Catch ex As Exception
            MessageBox.Show("Error loading years: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub RefreshDataGridView2()
        Try
            ' Base query na may WHERE clause para sa madaling pagdagdag ng filters
            Dim query As String = "SELECT ID, RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                  "SmallWaterGallon, SmallContainerwithWater, SmallContainer, GrossRevenue, Date " & _
                                  "FROM GrossRevenue WHERE 1=1"

            ' ✅ Search Filter gamit ang CAST para sa numeric columns
            Dim searchKeyword As String = Txt_Search1.Text.Trim()   ' Ginamit ang Txt_Search1 dito
            If Not String.IsNullOrEmpty(searchKeyword) Then
                query &= " AND (CAST(ID AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegWaterGallon AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegContainerwithWater AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegContainer AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallWaterGallon AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallContainerwithWater AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallContainer AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(GrossRevenue AS VARCHAR(50)) LIKE @Search)"
            End If

            ' ✅ Month Filtering gamit ang Date column
            Dim selectedMonth As String = "All"
            Dim monthNumber As Integer = 0
            If Cb_Month1.SelectedItem IsNot Nothing Then
                selectedMonth = Cb_Month1.SelectedItem.ToString()
            End If
            If selectedMonth <> "All" Then
                monthNumber = Array.IndexOf(New String() {"January", "February", "March", "April", "May", "June", _
                                                           "July", "August", "September", "October", "November", "December"}, selectedMonth) + 1
                query &= " AND MONTH(Date) = @Month"
            End If

            ' ✅ Year Filtering gamit ang Date column
            Dim selectedYear As String = "All"
            If Cb_Year1.SelectedItem IsNot Nothing Then
                selectedYear = Cb_Year1.SelectedItem.ToString()
            End If
            If selectedYear <> "All" Then
                query &= " AND YEAR(Date) = @Year"
            End If

            ' ✅ Sorting by Date (Newest First)
            query &= " ORDER BY Date ASC"

            Dim dt As New DataTable()

            ' Gamit ang Using block para sa tamang pamamahala ng connection
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    If Not String.IsNullOrEmpty(searchKeyword) Then
                        cmd.Parameters.AddWithValue("@Search", "%" & searchKeyword & "%")
                    End If

                    If selectedMonth <> "All" Then
                        cmd.Parameters.AddWithValue("@Month", monthNumber)
                    End If

                    If selectedYear <> "All" Then
                        cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(selectedYear))
                    End If

                    conn.Open()
                    Dim adapter As New SqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using

            ' I-bind ang DataTable sa DataGridView2
            DataGridView2.DataSource = dt

            ' I-update ang header texts ng mga columns
            DataGridView2.Columns("RegWaterGallon").HeaderText = "Reg Water Gallon"
            DataGridView2.Columns("RegContainerwithWater").HeaderText = "Reg Container with Water"
            DataGridView2.Columns("RegContainer").HeaderText = "Reg Container"
            DataGridView2.Columns("SmallWaterGallon").HeaderText = "Small Water Gallon"
            DataGridView2.Columns("SmallContainerwithWater").HeaderText = "Small Container with Water"
            DataGridView2.Columns("SmallContainer").HeaderText = "Small Container"
            DataGridView2.Columns("GrossRevenue").HeaderText = "Gross Revenue"

            ' I-set ang content alignment para sa bawat column at i-format ang Date column
            For Each col As DataGridViewColumn In DataGridView2.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                If col.Name = "Date" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next

            ' I-set ang row header alignment
            DataGridView2.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub
    'Tab 2
    Private Sub ClearTextBoxes1()
        Txt_Contact.Clear()
        Txt_Address.Clear()
        Txt_Quantity.Clear()
        DateTimePicker2.Value = DateTime.Now
    End Sub
    Private Sub Txt_Search2_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Search2.KeyPress
        ' Limit the length of the text to 11 characters
        If Txt_Search2.TextLength >= 50 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    Private Sub Btn_Refresh2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh2.Click

        Cb_Month2.SelectedIndex = 0
        Cb_Year2.SelectedIndex = 0
        Txt_Search2.Clear()
        RefreshDataGridView3EmployeeSalary()
        DataGridView3.ClearSelection()
        ClearTextBoxes1()

    End Sub
    Private Sub Txt_Search2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Search2.TextChanged
        RefreshDataGridView3EmployeeSalary()
    End Sub

    Private Sub Cb_Month2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Month2.SelectedIndexChanged
        RefreshDataGridView3EmployeeSalary()
    End Sub

    Private Sub Cb_Year2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Year2.SelectedIndexChanged
        RefreshDataGridView3EmployeeSalary()
    End Sub

    Private Sub LoadMonths2()
        Cb_Month2.Items.Clear()
        Cb_Month2.Items.Add("All") ' Default option

        Dim monthNames() As String = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        }

        For Each month As String In monthNames
            Cb_Month2.Items.Add(month)
        Next

        Cb_Month2.SelectedIndex = 0 ' Default select "All"
    End Sub

    Private Sub LoadYears2()
        Dim startYear As Integer = 2024 ' Fixed start year
        Dim endYear As Integer = 2050   ' Fixed end year

        Try
            Cb_Year2.Items.Clear()
            Cb_Year2.Items.Add("All") ' Default option

            For year As Integer = startYear To endYear
                Cb_Year2.Items.Add(year.ToString())
            Next

            Cb_Year2.SelectedIndex = 0 ' Default select "All"
        Catch ex As Exception
            MessageBox.Show("Error loading years: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
   Private Sub RefreshDataGridView3EmployeeSalary()
        Try
            ' Base query na may WHERE clause para sa madaling pagdagdag ng filters
            Dim query As String = "SELECT s.ID, e.EmployeeID, e.FullName, e.Address, e.ContactNumber, s.Salary, s.Date " & _
                                  "FROM EmployeeInfo e " & _
                                  "JOIN EmployeeSalary s ON e.EmployeeID = s.EmployeeID " & _
                                  "WHERE 1=1"

            ' ✅ Search Filter gamit ang Txt_Search2
            Dim searchKeyword As String = Txt_Search2.Text.Trim()
            If Not String.IsNullOrEmpty(searchKeyword) Then
                query &= " AND (e.EmployeeID LIKE @Search OR e.FullName LIKE @Search OR e.Address LIKE @Search)"
            End If

            ' ✅ Month Filtering gamit ang s.Date column
            Dim selectedMonth As String = "All"
            Dim monthNumber As Integer = 0
            If Cb_Month2.SelectedItem IsNot Nothing Then
                selectedMonth = Cb_Month2.SelectedItem.ToString()
            End If
            If selectedMonth <> "All" Then
                monthNumber = Array.IndexOf(New String() {"January", "February", "March", "April", "May", "June", _
                                                           "July", "August", "September", "October", "November", "December"}, selectedMonth) + 1
                query &= " AND MONTH(s.Date) = @Month"
            End If

            ' ✅ Year Filtering gamit ang s.Date column
            Dim selectedYear As String = "All"
            If Cb_Year2.SelectedItem IsNot Nothing Then
                selectedYear = Cb_Year2.SelectedItem.ToString()
            End If
            If selectedYear <> "All" Then
                query &= " AND YEAR(s.Date) = @Year"
            End If

            ' ✅ Sorting by Date (Newest First)
            query &= " ORDER BY s.Date ASC"

            Dim dt As New DataTable()

            ' Using block para sa tamang pamamahala ng connection
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    If Not String.IsNullOrEmpty(searchKeyword) Then
                        cmd.Parameters.AddWithValue("@Search", "%" & searchKeyword & "%")
                    End If
                    If selectedMonth <> "All" Then
                        cmd.Parameters.AddWithValue("@Month", monthNumber)
                    End If
                    If selectedYear <> "All" Then
                        cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(selectedYear))
                    End If

                    conn.Open()
                    Dim adapter As New SqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using

            ' I-bind ang DataTable sa DataGridView3
            DataGridView3.DataSource = dt

            ' I-update ang header text at i-format ang columns
            DataGridView3.Columns("ContactNumber").HeaderText = "Contact Number"

            For Each col As DataGridViewColumn In DataGridView3.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                If col.Name = "Date" Then
                    col.DefaultCellStyle.Format = "MMMM dd, yyyy"
                End If
            Next

            DataGridView3.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub DataGridView3_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles DataGridView3.SelectionChanged
        If DataGridView3.SelectedRows.Count > 0 Then
            ' If more than one row is selected, disable update and submit buttons; otherwise, enable them.
            If DataGridView3.SelectedRows.Count > 1 Then
                Btn_Update1.Enabled = False
                Btn_Submit1.Enabled = False
            Else
                Btn_Update1.Enabled = True
                Btn_Submit1.Enabled = True
            End If

            ' Populate input fields with selected row data
            Dim selectedRow As DataGridViewRow = DataGridView3.SelectedRows(0)
            Cb_EmployeeID.Text = selectedRow.Cells("EmployeeID").Value.ToString()
            Cb_Fullname.Text = selectedRow.Cells("Fullname").Value.ToString()
            Txt_Address.Text = selectedRow.Cells("Address").Value.ToString()
            Txt_Contact.Text = selectedRow.Cells("ContactNumber").Value.ToString()

            ' Retrieve the salary from the selected row
            Dim salary As Double = CDbl(selectedRow.Cells("Salary").Value)

            ' Retrieve EmployeePercent from the Price table
            Dim employeePercent As Double = GetEmployeePercentFromPrice()

            ' Compute quantity based on salary / employeePercent
            If employeePercent <> 0 Then
                Txt_Quantity.Text = (salary / employeePercent).ToString()
            End If

            ' Set the DateTimePicker to the value from the selected row
            DateTimePicker2.Value = CDate(selectedRow.Cells("Date").Value)
        Else
            ' If no row is selected, clear textboxes and reset the DateTimePicker
            ClearTextBoxes1()
            DateTimePicker2.Value = DateTime.Now
        End If
    End Sub
    Private Function GetEmployeePercentFromPrice() As Double
        Dim resultValue As Double = 0
        Try
            Using conn As New SqlConnection(connectionString)
                conn.Open()
                ' Adjust the query if you need a specific row from the Price table
                Dim query As String = "SELECT TOP 1 EmployeePercent FROM Price"
                Using cmd As New SqlCommand(query, conn)
                    Dim result As Object = cmd.ExecuteScalar()
                    If result IsNot Nothing Then
                        Double.TryParse(result.ToString(), resultValue)
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error retrieving EmployeePercent: " & ex.Message)
        End Try
        Return resultValue
    End Function
    Private Function IsValidPhoneNumber(ByVal phoneNumber As String) As Boolean
        ' Regular expression pattern for validating phone number format (Philippines format)
        Dim pattern As String = "^(09|\+639)\d{9}$"
        Return System.Text.RegularExpressions.Regex.IsMatch(phoneNumber, pattern)
    End Function
    Private Sub Txt_Contact_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Contact.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        ' Limit the length of the text to 11 characters
        If Txt_Contact.TextLength >= 11 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    Private Sub PopulateEmployeeComboBoxes()
        Try
            conn.Open()
            Dim query As String = "SELECT EmployeeID, Fullname FROM EmployeeInfo"
            cmd = New SqlCommand(query, conn)
            adapter = New SqlDataAdapter(cmd)


            Dim dtEmployee As New DataTable()
            adapter.Fill(dtEmployee)

            'Bind the same DataTable to the same ComboBox, 
            'but each one has a different DisplayMember.
            Cb_EmployeeID.DataSource = dtEmployee.Copy()
            Cb_EmployeeID.DisplayMember = "EmployeeID"
            Cb_EmployeeID.ValueMember = "EmployeeID"

            Cb_Fullname.DataSource = dtEmployee.Copy()
            Cb_Fullname.DisplayMember = "Fullname"
            Cb_Fullname.ValueMember = "Fullname"

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Cb_EmployeeID_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_EmployeeID.SelectedIndexChanged
        ' Check if the selected item is not Nothing
        If Cb_EmployeeID.SelectedItem IsNot Nothing Then
            ' Retrieve the selected DataRowView
            Dim selectedDataRowView As DataRowView = TryCast(Cb_EmployeeID.SelectedItem, DataRowView)

            ' Check if the conversion is successful and the DataRowView is not Nothing
            If selectedDataRowView IsNot Nothing Then
                ' Retrieve the value of the "Fullname" field from the DataRowView
                Dim selectedFullname As String = Convert.ToString(selectedDataRowView("Fullname"))
                ' Set the selected Fullname in the Cb_Fullname ComboBox
                Cb_Fullname.Text = selectedFullname
                ' Retrieve the Employee ID
                Dim selectedEmployeeID As Integer = Convert.ToInt32(selectedDataRowView("EmployeeID"))
                ' Call method to display employee information based on selected EmployeeID
                DisplayEmployeeInfo(selectedEmployeeID)
            End If
        End If
    End Sub

    Private Sub Cb_Fullname_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Fullname.SelectedIndexChanged

        Txt_Quantity.Clear()

        ' Check if the selected item is not Nothing
        If Cb_Fullname.SelectedItem IsNot Nothing Then
            ' Retrieve the selected DataRowView
            Dim selectedDataRowView As DataRowView = TryCast(Cb_Fullname.SelectedItem, DataRowView)

            ' Check if the conversion is successful and the DataRowView is not Nothing
            If selectedDataRowView IsNot Nothing Then
                ' Retrieve the value of the "Employee ID" field from the DataRowView
                Dim selectedEmployeeID As Integer = Convert.ToInt32(selectedDataRowView("EmployeeID"))
                ' Set the selected Employee ID in the Cb_EmployeeID ComboBox
                Cb_EmployeeID.SelectedValue = selectedEmployeeID
                ' Call method to display employee information based on selected EmployeeID
                DisplayEmployeeInfo(selectedEmployeeID)
            End If
        End If
    End Sub

    Private Sub DisplayEmployeeInfo(ByVal selectedEmployeeID As Integer)
        Try
            ' Ensure the connection is closed before opening it again
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If

            Dim query As String = "SELECT * FROM EmployeeInfo WHERE EmployeeID = @EmployeeID"
            cmd = New SqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@EmployeeID", selectedEmployeeID)
            Dim reader As SqlDataReader = cmd.ExecuteReader()

            If reader.Read() Then
                ' Display employee information in the input fields
                Txt_Address.Text = reader("Address").ToString()
                Txt_Contact.Text = reader("ContactNumber").ToString()
                ' You can similarly display other fields
            End If

            reader.Close()

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        End Try
    End Sub
    Private Sub Btn_SalaryReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SalaryReport.Click
        Try
            ' Check if there are at least two selected rows
            If DataGridView3.SelectedRows.Count < 2 Then
                MessageBox.Show("Please select at least two rows to generate the report.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Calculate the date range from the selected rows (assuming each row has a "Date" column)
            Dim startDate As Date = Date.MaxValue
            Dim endDate As Date = Date.MinValue
            For Each row As DataGridViewRow In DataGridView3.SelectedRows
                Dim rowDate As Date = Convert.ToDateTime(row.Cells("Date").Value)
                If rowDate < startDate Then startDate = rowDate
                If rowDate > endDate Then endDate = rowDate
            Next

            ' Ask for confirmation with the calculated date range
            Dim confirmationResult As DialogResult = MessageBox.Show( _
                "Are you sure you want to generate the salary report for the period: " & startDate.ToShortDateString() & " to " & endDate.ToShortDateString() & "?", _
                "Confirm Report Generation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If confirmationResult = DialogResult.No Then Return

            ' Calculate total salary
            Dim totalSalary As Double = 0
            For Each row As DataGridViewRow In DataGridView3.SelectedRows
                totalSalary += CDbl(row.Cells("Salary").Value)
            Next

            Using conn As New SqlConnection(connectionString)
                conn.Open()

                ' 1. Check if an exact salary report for the selected date range already exists.
                Dim exactCheckQuery As String = "SELECT COUNT(*) FROM SalaryReport WHERE StartDate = @StartDate AND EndDate = @EndDate"
                Using cmdExact As New SqlCommand(exactCheckQuery, conn)
                    cmdExact.Parameters.AddWithValue("@StartDate", startDate)
                    cmdExact.Parameters.AddWithValue("@EndDate", endDate)
                    Dim exactCount As Integer = Convert.ToInt32(cmdExact.ExecuteScalar())
                    If exactCount > 0 Then
                        MessageBox.Show("A salary report for the period " & startDate.ToShortDateString() & " to " & endDate.ToShortDateString() & " already exists.", _
                                        "Report Already Exists", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        Return
                    End If
                End Using

                ' 2. Check if any salary report overlaps with the selected date range.
                Dim overlapCheckQuery As String = "SELECT COUNT(*) FROM SalaryReport WHERE @StartDate <= EndDate AND @EndDate >= StartDate"
                Using cmdOverlap As New SqlCommand(overlapCheckQuery, conn)
                    cmdOverlap.Parameters.AddWithValue("@StartDate", startDate)
                    cmdOverlap.Parameters.AddWithValue("@EndDate", endDate)
                    Dim overlapCount As Integer = Convert.ToInt32(cmdOverlap.ExecuteScalar())
                    If overlapCount > 0 Then
                        MessageBox.Show("A salary report overlapping with the period " & startDate.ToShortDateString() & " to " & endDate.ToShortDateString() & " already exists.", _
                                        "Report Overlap", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        Return
                    End If
                End Using

                ' Insert the new salary report into the SalaryReport table with the calculated date range
                Dim insertQuery As String = "INSERT INTO SalaryReport (TotalSalary, Rows, StartDate, EndDate) VALUES (@TotalSalary, @Rows, @StartDate, @EndDate)"
                Using cmdInsert As New SqlCommand(insertQuery, conn)
                    cmdInsert.Parameters.AddWithValue("@TotalSalary", totalSalary)
                    cmdInsert.Parameters.AddWithValue("@Rows", DataGridView3.SelectedRows.Count)
                    cmdInsert.Parameters.AddWithValue("@StartDate", startDate)
                    cmdInsert.Parameters.AddWithValue("@EndDate", endDate)
                    cmdInsert.ExecuteNonQuery()
                End Using
            End Using

            MessageBox.Show("Salary report generated successfully for the period: " & startDate.ToShortDateString() & " to " & endDate.ToShortDateString() & ".", _
                            "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            RefreshDataGridView3EmployeeSalary()
            RefreshDataGridView2Report()
            DataGridView3.ClearSelection()
            Reports.DataGridView2.ClearSelection()
            ClearTextBoxes1()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub RefreshDataGridView2Report()
        Try
            conn.Open()
            Dim query As String = "SELECT ID, TotalSalary, Rows, StartDate, EndDate FROM SalaryReport"

            cmd = New SqlCommand(query, conn)
            adapter = New SqlDataAdapter(cmd)
            dt = New DataTable()
            adapter.Fill(dt)

            Reports.DataGridView2.DataSource = dt

            ' Set row header alignment
            DataGridView2.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub Txt_Quantity_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Quantity.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub
    Private Sub Btn_Update1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Update1.Click
        Try
            ' Check if a row is selected
            If DataGridView3.SelectedRows.Count = 0 Then
                MessageBox.Show("Please select a single record to update.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            Dim selectedRow As DataGridViewRow = DataGridView3.SelectedRows(0)
            Dim recordID As Integer = CInt(selectedRow.Cells("ID").Value)
            Dim employeeID As Integer = CInt(selectedRow.Cells("EmployeeID").Value)

            ' Validate quantity input
            Dim quantity As Integer
            If Not Integer.TryParse(Txt_Quantity.Text, quantity) Then
                MessageBox.Show("Please enter a valid quantity.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Txt_Quantity.Focus()
                Return
            End If

            ' Ensure quantity is positive
            If quantity <= 0 Then
                MessageBox.Show("Quantity must be a positive number.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Txt_Quantity.Clear()
                Txt_Quantity.Focus()
                Return
            End If

            Dim updateDate As Date = DateTimePicker2.Value.Date

            ' Database connection
            Using conn As New SqlConnection(connectionString)
                conn.Open()

                Using transaction As SqlTransaction = conn.BeginTransaction()
                    ' 1. Check if a Sold record exists for the updated date and get total quantity
                    Dim totalSoldQuantity As Integer = 0
                    Dim checkSoldQuery As String = "SELECT RegWaterGallon, RegContainerwithWater, RegContainer, " &
                                                  "SmallWaterGallon, SmallContainerwithWater, SmallContainer " &
                                                  "FROM Sold WHERE CONVERT(DATE, [Date]) = CONVERT(DATE, @Date)"
                    Using cmdCheckSold As New SqlCommand(checkSoldQuery, conn, transaction)
                        cmdCheckSold.Parameters.AddWithValue("@Date", updateDate)
                        Using reader As SqlDataReader = cmdCheckSold.ExecuteReader()
                            If Not reader.Read() Then
                                reader.Close()
                                MessageBox.Show("No sales record found for the selected date. Please enter sales data first.", "No Sales Data", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                transaction.Rollback()
                                RefreshDataGridView3EmployeeSalary()
                                DataGridView3.ClearSelection()
                                ClearTextBoxes1()
                                Return
                            End If

                            ' Calculate total quantity from Sold table
                            totalSoldQuantity = reader.GetInt32(0) + reader.GetInt32(1) + reader.GetInt32(2) +
                                                reader.GetInt32(3) + reader.GetInt32(4) + reader.GetInt32(5)
                            reader.Close()
                        End Using
                    End Using

                    ' 2. Check for duplicate entry for the same EmployeeID and date (excluding the current record)
                    Dim checkDuplicateQuery As String = "SELECT COUNT(*) FROM EmployeeSalary " &
                                                       "WHERE EmployeeID = @EmployeeID AND CONVERT(DATE, [Date]) = CONVERT(DATE, @Date) AND ID <> @ID"
                    Using cmdCheckDuplicate As New SqlCommand(checkDuplicateQuery, conn, transaction)
                        cmdCheckDuplicate.Parameters.AddWithValue("@EmployeeID", employeeID)
                        cmdCheckDuplicate.Parameters.AddWithValue("@Date", updateDate)
                        cmdCheckDuplicate.Parameters.AddWithValue("@ID", recordID)
                        Dim existingRecords As Integer = CInt(cmdCheckDuplicate.ExecuteScalar())
                        If existingRecords > 0 Then
                            MessageBox.Show("This employee already has a salary set for the updated date.", "Duplicate Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            transaction.Rollback()
                            RefreshDataGridView3EmployeeSalary()
                            DataGridView3.ClearSelection()
                            ClearTextBoxes1()
                            Return
                        End If
                    End Using

                    ' 3. Retrieve the EmployeePercent from the Price table
                    Dim employeePercent As Decimal
                    Dim selectPercentQuery As String = "SELECT TOP 1 EmployeePercent FROM Price"
                    Using cmdSelectPercent As New SqlCommand(selectPercentQuery, conn, transaction)
                        Dim result As Object = cmdSelectPercent.ExecuteScalar()
                        If result Is Nothing Then
                            MessageBox.Show("No EmployeePercent found in the Price table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            transaction.Rollback()
                            Return
                        End If
                        employeePercent = Convert.ToDecimal(result)
                    End Using

                    ' 4. Calculate the total quantity already submitted by all employees for this date (excluding the current record)
                    Dim totalSubmittedQuantity As Integer = 0
                    Dim checkSubmittedQuery As String = "SELECT SUM(Salary / @EmployeePercent) FROM EmployeeSalary " &
                                                       "WHERE CONVERT(DATE, [Date]) = CONVERT(DATE, @Date) AND ID <> @ID"
                    Using cmdCheckSubmitted As New SqlCommand(checkSubmittedQuery, conn, transaction)
                        cmdCheckSubmitted.Parameters.AddWithValue("@EmployeePercent", employeePercent)
                        cmdCheckSubmitted.Parameters.AddWithValue("@Date", updateDate)
                        cmdCheckSubmitted.Parameters.AddWithValue("@ID", recordID)
                        Dim result As Object = cmdCheckSubmitted.ExecuteScalar()
                        If result IsNot DBNull.Value Then
                            totalSubmittedQuantity = Convert.ToInt32(result)
                        End If
                    End Using

                    ' 5. Validate that the new quantity plus already submitted quantities does not exceed total sold quantity
                    Dim newTotalQuantity As Integer = totalSubmittedQuantity + quantity
                    If newTotalQuantity > totalSoldQuantity Then
                        MessageBox.Show("Your total input for salary this date (" & newTotalQuantity & ") it exceeds total sold quantity (" & totalSoldQuantity & "). ", "Invalid Quantity", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        transaction.Rollback()
                        Txt_Quantity.Clear()
                        Txt_Quantity.Focus()
                        Return
                    End If

                    ' 6. Compute the salary using quantity * employeePercent
                    Dim computedSalary As Decimal = quantity * employeePercent

                    ' 7. Update the record
                    Dim updateQuery As String = "UPDATE EmployeeSalary SET Salary = @Salary, [Date] = @Date WHERE ID = @ID"
                    Using cmdUpdate As New SqlCommand(updateQuery, conn, transaction)
                        cmdUpdate.Parameters.AddWithValue("@Salary", computedSalary)
                        cmdUpdate.Parameters.AddWithValue("@Date", updateDate)
                        cmdUpdate.Parameters.AddWithValue("@ID", recordID)
                        cmdUpdate.ExecuteNonQuery()
                    End Using

                    ' 8. Commit the transaction and show success message
                    transaction.Commit()
                    MessageBox.Show("Data updated successfully.", "Update Successful", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    RefreshDataGridView3EmployeeSalary()
                    DataGridView3.ClearSelection()
                    ClearTextBoxes1()
                    Home.LoadMonthlyNetIncomeChart()
                    Home.LoadMonthlyNetIncomeChartSmall()
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub LoadEmployeePercent()
        Try
            Using conn As New SqlConnection(connectionString)
                conn.Open()
                Dim query As String = "SELECT TOP 1 EmployeePercent FROM Price"
                Using cmd As New SqlCommand(query, conn)
                    Dim result As Object = cmd.ExecuteScalar()
                    If result IsNot Nothing Then
                        Label28.Text = result.ToString()
                    Else
                        Label28.Text = "N/A"
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading Employee Commission: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Edit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Edit.Click
        Try
            ' Prompt user for the new EmployeePercent using an InputBox
            Dim input As String = InputBox("Enter new Employee Commission (Positive whole number, 1-999):", "Employee Commission", Label28.Text)

            ' Check if the user cancelled or left the input blank
            If String.IsNullOrWhiteSpace(input) Then
                MessageBox.Show("Update cancelled.", "Update Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            ' Check if the input starts with zero
            If input.StartsWith("0") Then
                MessageBox.Show("Employee Commission cannot start with zero.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Validate the input: must be numeric, positive, whole number, no special characters
            If Not IsNumeric(input) Then
                MessageBox.Show("Please enter a valid number. No special characters or letters allowed.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            Dim newPercent As Integer
            If Not Integer.TryParse(input, newPercent) Then
                MessageBox.Show("Please enter a whole number.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Check for negative numbers
            If newPercent < 0 Then
                MessageBox.Show("Employee Commission cannot be negative.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Check if the input is zero
            If newPercent = 0 Then
                MessageBox.Show("Employee Commission cannot be zero.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Check if the input exceeds 3 digits
            If input.Length > 3 Then
                MessageBox.Show("Employee Commission cannot exceed 3 digits.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Update the Price table (assumes updating the row with ID = 1)
            Using conn As New SqlConnection(connectionString)
                conn.Open()
                Dim query As String = "UPDATE Price SET EmployeePercent = @newPercent WHERE ID = 1"
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@newPercent", newPercent)
                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()
                    If rowsAffected > 0 Then
                        MessageBox.Show("Employee Commission updated successfully.", "Update Successful", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        MessageBox.Show("No rows were updated. Please verify your table data.", "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    End If
                End Using
            End Using

            ' Refresh the label to show the updated value
            LoadEmployeePercent()

        Catch ex As Exception
            MessageBox.Show("Error updating EmployeePercent: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub Btn_Submit1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Submit1.Click
        Try
            ' Check if required fields are empty
            If Cb_EmployeeID.SelectedIndex = -1 OrElse String.IsNullOrWhiteSpace(Txt_Quantity.Text) Then
                MessageBox.Show("Please fill in all required fields.", "Incomplete Field", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Validate quantity as an integer
            Dim quantity As Integer
            If Not Integer.TryParse(Txt_Quantity.Text, quantity) Then
                MessageBox.Show("Quantity must be a valid integer.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Txt_Quantity.Clear()
                Txt_Quantity.Focus()
                Return
            End If

            ' Ensure quantity is positive
            If quantity <= 0 Then
                MessageBox.Show("Quantity must be a positive number.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Txt_Quantity.Clear()
                Txt_Quantity.Focus()
                Return
            End If

            ' Assign values
            Dim employeeID As Integer = CInt(Cb_EmployeeID.SelectedValue)
            Dim date1 As Date = DateTimePicker2.Value.Date

            ' Database connection
            Using conn As New SqlConnection(connectionString)
                conn.Open()

                Using transaction As SqlTransaction = conn.BeginTransaction()
                    ' 1. Check if a Sold record exists for the selected date and get total quantity
                    Dim totalSoldQuantity As Integer = 0
                    Dim checkSoldQuery As String = "SELECT RegWaterGallon, RegContainerwithWater, RegContainer, " &
                                                  "SmallWaterGallon, SmallContainerwithWater, SmallContainer " &
                                                  "FROM Sold WHERE CONVERT(DATE, [Date]) = CONVERT(DATE, @Date)"
                    Using cmdCheckSold As New SqlCommand(checkSoldQuery, conn, transaction)
                        cmdCheckSold.Parameters.AddWithValue("@Date", date1)
                        Using reader As SqlDataReader = cmdCheckSold.ExecuteReader()
                            If Not reader.Read() Then
                                reader.Close()
                                MessageBox.Show("No sales record found for the selected date. Please enter sales data first.", "No Sales Data", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                transaction.Rollback()
                                RefreshDataGridView3EmployeeSalary()
                                DataGridView3.ClearSelection()
                                ClearTextBoxes1()
                                Return
                            End If

                            ' Calculate total quantity from Sold table
                            totalSoldQuantity = reader.GetInt32(0) + reader.GetInt32(1) + reader.GetInt32(2) +
                                                reader.GetInt32(3) + reader.GetInt32(4) + reader.GetInt32(5)
                            reader.Close()
                        End Using
                    End Using

                    ' 2. Check for duplicate entry for the same EmployeeID and date
                    Dim checkDuplicateQuery As String = "SELECT COUNT(*) FROM EmployeeSalary " &
                                                       "WHERE EmployeeID = @EmployeeID AND CONVERT(DATE, [Date]) = CONVERT(DATE, @Date)"
                    Using cmdCheckDuplicate As New SqlCommand(checkDuplicateQuery, conn, transaction)
                        cmdCheckDuplicate.Parameters.AddWithValue("@EmployeeID", employeeID)
                        cmdCheckDuplicate.Parameters.AddWithValue("@Date", date1)
                        Dim existingRecords As Integer = CInt(cmdCheckDuplicate.ExecuteScalar())
                        If existingRecords > 0 Then
                            MessageBox.Show("This employee's salary for that date has already been set.", "Duplicate Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            transaction.Rollback()
                            RefreshDataGridView3EmployeeSalary()
                            DataGridView3.ClearSelection()
                            ClearTextBoxes1()
                            Return
                        End If
                    End Using

                    ' 3. Retrieve the EmployeePercent from the Price table
                    Dim employeePercent As Decimal
                    Dim selectPercentQuery As String = "SELECT TOP 1 EmployeePercent FROM Price"
                    Using cmdSelectPercent As New SqlCommand(selectPercentQuery, conn, transaction)
                        Dim result As Object = cmdSelectPercent.ExecuteScalar()
                        If result Is Nothing Then
                            MessageBox.Show("No EmployeePercent found in the Price table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            transaction.Rollback()
                            Return
                        End If
                        employeePercent = Convert.ToDecimal(result)
                    End Using

                    ' 4. Calculate the total quantity already submitted by all employees for this date
                    Dim totalSubmittedQuantity As Integer = 0
                    Dim checkSubmittedQuery As String = "SELECT SUM(Salary / @EmployeePercent) FROM EmployeeSalary " &
                                                       "WHERE CONVERT(DATE, [Date]) = CONVERT(DATE, @Date)"
                    Using cmdCheckSubmitted As New SqlCommand(checkSubmittedQuery, conn, transaction)
                        cmdCheckSubmitted.Parameters.AddWithValue("@EmployeePercent", employeePercent)
                        cmdCheckSubmitted.Parameters.AddWithValue("@Date", date1)
                        Dim result As Object = cmdCheckSubmitted.ExecuteScalar()
                        If result IsNot DBNull.Value Then
                            totalSubmittedQuantity = Convert.ToInt32(result)
                        End If
                    End Using

                    ' 5. Validate that the new quantity plus already submitted quantities does not exceed total sold quantity
                    Dim newTotalQuantity As Integer = totalSubmittedQuantity + quantity
                    If newTotalQuantity > totalSoldQuantity Then
                        MessageBox.Show("Your total input for salary this date (" & newTotalQuantity & ") it exceeds total sold quantity (" & totalSoldQuantity & "). ", "Invalid Quantity", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        transaction.Rollback()
                        Txt_Quantity.Clear()
                        Txt_Quantity.Focus()
                        Return
                    End If

                    ' 6. Compute the salary using quantity * employeePercent
                    Dim computedSalary As Decimal = quantity * employeePercent

                    ' 7. Insert data
                    Dim insertQuery As String = "INSERT INTO EmployeeSalary (EmployeeID, Salary, [Date]) " &
                                                "VALUES (@EmployeeID, @Salary, @Date)"
                    Using cmdInsert As New SqlCommand(insertQuery, conn, transaction)
                        cmdInsert.Parameters.AddWithValue("@EmployeeID", employeeID)
                        cmdInsert.Parameters.AddWithValue("@Salary", computedSalary)
                        cmdInsert.Parameters.AddWithValue("@Date", date1)
                        cmdInsert.ExecuteNonQuery()
                    End Using

                    ' 8. Commit the transaction and show success message
                    transaction.Commit()
                    MessageBox.Show("Data submitted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    RefreshDataGridView3EmployeeSalary()
                    DataGridView3.ClearSelection()
                    ClearTextBoxes1()
                    Home.LoadMonthlyNetIncomeChart()
                    Home.LoadMonthlyNetIncomeChartSmall()
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub Btn_Delete1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete1.Click
        Try
            ' Check if any rows are selected
            If DataGridView3.SelectedRows.Count = 0 Then
                MessageBox.Show("Please select records to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' Ask for confirmation before deleting
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete the selected row(s)?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If result <> DialogResult.Yes Then Exit Sub

            Using conn As New SqlConnection(connectionString)
                conn.Open()

                ' Start a transaction to ensure atomicity
                Using transaction As SqlTransaction = conn.BeginTransaction()
                    Try
                        ' Enable IDENTITY_INSERT for backup table
                        Using cmdIdentityOn As New SqlCommand("SET IDENTITY_INSERT EmployeeSalaryBackup ON", conn, transaction)
                            cmdIdentityOn.ExecuteNonQuery()
                        End Using

                        ' Prepare SQL commands
                        Dim backupQuery As String = "INSERT INTO EmployeeSalaryBackup ([ID], [EmployeeID], [Fullname], [Address], [ContactNumber], [Salary], [Date]) " &
                                                    "VALUES (@ID, @EmployeeID, @Fullname, @Address, @ContactNumber, @Salary, @Date)"

                        ' DELETE queries (in correct order)
                        Dim deleteSalaryQuery As String = "DELETE FROM EmployeeSalary WHERE ID = @ID"

                        ' Loop through all selected rows
                        For Each selectedRow As DataGridViewRow In DataGridView3.SelectedRows
                            ' Validate Employee ID
                            If selectedRow.Cells("ID").Value Is Nothing OrElse IsDBNull(selectedRow.Cells("EmployeeID").Value) Then
                                MessageBox.Show("EmployeeID is missing for a selected row.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                transaction.Rollback()
                                Return
                            End If

                            ' Extract data
                            Dim recordID As Integer = CInt(selectedRow.Cells("ID").Value)
                            Dim employeeID As Integer = CInt(selectedRow.Cells("EmployeeID").Value)
                            Dim fullname As String = selectedRow.Cells("Fullname").Value.ToString()
                            Dim address As String = selectedRow.Cells("Address").Value.ToString()
                            Dim contactNumber As String = selectedRow.Cells("ContactNumber").Value.ToString()
                            Dim salary As Decimal = Convert.ToDecimal(selectedRow.Cells("Salary").Value)
                            Dim dateValue As Date = Convert.ToDateTime(selectedRow.Cells("Date").Value)

                            ' Backup the record
                            Using cmdBackup As New SqlCommand(backupQuery, conn, transaction)
                                cmdBackup.Parameters.Add("@ID", SqlDbType.Int).Value = recordID
                                cmdBackup.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeID
                                cmdBackup.Parameters.Add("@Fullname", SqlDbType.NVarChar, 255).Value = fullname
                                cmdBackup.Parameters.Add("@Address", SqlDbType.NVarChar, 255).Value = address
                                cmdBackup.Parameters.Add("@ContactNumber", SqlDbType.NVarChar, 50).Value = contactNumber
                                cmdBackup.Parameters.Add("@Salary", SqlDbType.Decimal).Value = salary
                                cmdBackup.Parameters.Add("@Date", SqlDbType.DateTime).Value = dateValue
                                cmdBackup.ExecuteNonQuery()
                            End Using

                            ' Step 1: Delete from EmployeeSalary first
                            Using cmdDeleteSalary As New SqlCommand(deleteSalaryQuery, conn, transaction)
                                cmdDeleteSalary.Parameters.Add("@ID", SqlDbType.Int).Value = recordID
                                cmdDeleteSalary.ExecuteNonQuery()
                            End Using
                        Next

                        ' Disable IDENTITY_INSERT
                        Using cmdIdentityOff As New SqlCommand("SET IDENTITY_INSERT EmployeeSalaryBackup OFF", conn, transaction)
                            cmdIdentityOff.ExecuteNonQuery()
                        End Using

                        ' Commit the transaction
                        transaction.Commit()
                        MessageBox.Show("Selected records deleted successfully after backup.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                        ' Refresh the DataGridView
                        RefreshDataGridView3EmployeeSalary()
                        DataGridView3.ClearSelection()
                        ClearTextBoxes1()
                        Home.LoadMonthlyNetIncomeChart()
                        Home.LoadMonthlyNetIncomeChartSmall()
                    Catch ex As Exception
                        ' Rollback in case of error
                        transaction.Rollback()
                        MessageBox.Show("Transaction failed: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            End Using
        Catch ex As SqlException
            MessageBox.Show("Database Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            MessageBox.Show("Unexpected Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_UserInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_UserInfo.Click
        Me.Hide()
        UserProfile.Show()
        ClearTextBoxes()
        Cb_Month.SelectedIndex = 0
        Cb_Year.SelectedIndex = 0
        RefreshDataGridView1Sold()
        DataGridView1.ClearSelection()
    End Sub

    Private Sub Btn_Logout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Logout.Click
        Dim _exit As DialogResult = MessageBox.Show(
                   "Are you sure you want to Logout?",
                   "Logout",
                   MessageBoxButtons.OKCancel,
                   MessageBoxIcon.Warning)

        If _exit = DialogResult.OK Then
            ' 1) Update the latest LoginHistory record with LogoutTime
            Try
                Using logoutCon As New SqlConnection(connectionString)
                    logoutCon.Open()
                    Using logoutCmd As New SqlCommand(
                        "UPDATE LoginHistory " & _
                        "SET LogoutTime = GETDATE() " & _
                        "WHERE HistoryID = ( " & _
                        "  SELECT TOP 1 HistoryID " & _
                        "  FROM LoginHistory " & _
                        "  WHERE LogoutTime IS NULL " & _
                        "  ORDER BY HistoryID DESC " & _
                        ");",
                        logoutCon)
                        logoutCmd.ExecuteNonQuery()
                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show(
                    "Error updating logout time: " & ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error)
            End Try

            ' 2) Show Login form
            Login.Show()
            Me.Hide()
            Login.Txt_Username.Focus()
            Login.Txt_Password.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub TabControl1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabControl1.Click
        ' Other initialization tasks
        RefreshDataGridView1Sold()
        RefreshDataGridView2()
        RefreshDataGridView3EmployeeSalary()

        DataGridView1.ClearSelection()
        DataGridView3.ClearSelection()
    End Sub
    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles TabControl1.SelectedIndexChanged
        If TabControl1.SelectedTab Is TabPage4 Then
            Cb_Month.SelectedIndex = 0
            Cb_Year.SelectedIndex = 0

            Cb_Month1.SelectedIndex = 0
            Cb_Year1.SelectedIndex = 0

            Cb_Month2.SelectedIndex = 0
            Cb_Year2.SelectedIndex = 0

            Cb_Month3.SelectedIndex = 0
            Cb_Year3.SelectedIndex = 0

            RefreshDataGridView1Sold()
            RefreshDataGridView2()
            RefreshDataGridView3EmployeeSalary()
            RefreshDataGridView4()

            DataGridView1.ClearSelection()
            DataGridView3.ClearSelection()
        End If
    End Sub
    'Tab 4

    Private Sub Btn_Refresh3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh3.Click
        Cb_Month3.SelectedIndex = 0
        Cb_Year3.SelectedIndex = 0
        RefreshDataGridView4()
        DataGridView4.ClearSelection()
    End Sub
    Private Sub Cb_Month3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Month3.SelectedIndexChanged
        LoadNetIncomeData()
    End Sub

    ' Event handler para sa year ComboBox
    Private Sub Cb_Year3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Year3.SelectedIndexChanged
        LoadNetIncomeData()
    End Sub

    ' ✅ Function para i-load ang listahan ng Months (January - December) para sa tab 3
    Private Sub LoadMonths3()
        Cb_Month3.Items.Clear()
        Cb_Month3.Items.Add("All") ' Default option

        Dim monthNames() As String = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        }

        For Each month As String In monthNames
            Cb_Month3.Items.Add(month)
        Next

        Cb_Month3.SelectedIndex = 0 ' Default select "All"
    End Sub

    ' ✅ Function para i-load ang listahan ng Years (2024 - 2050) para sa tab 3
    Private Sub LoadYears3()
        Dim startYear As Integer = 2024 ' Fixed start year
        Dim endYear As Integer = 2050   ' Fixed end year

        Try
            Cb_Year3.Items.Clear()
            Cb_Year3.Items.Add("All") ' Default option

            For year As Integer = startYear To endYear
                Cb_Year3.Items.Add(year.ToString())
            Next

            Cb_Year3.SelectedIndex = 0 ' Default select "All"
        Catch ex As Exception
            MessageBox.Show("Error loading years: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub RefreshDataGridView4()
        Try
            ' Base query gamit ang WHERE clause para madaling maidagdag ang filters
            Dim query As String = "SELECT ni.ID, es.Salary, gr.GrossRevenue, " & _
                                  "(gr.GrossRevenue - es.Salary) AS NetIncome, ni.Date " & _
                                  "FROM NetIncome ni " & _
                                  "JOIN EmployeeSalary es ON ni.SalaryID = es.ID " & _
                                  "JOIN GrossRevenue gr ON ni.GrossRevenueID = gr.ID " & _
                                  "WHERE es.Date = gr.Date AND ni.Date = es.Date"

            ' I-bind ang DataTable sa DataGridView4
            DataGridView4.DataSource = dt

            ' I-format ang columns: center alignment at format para sa Date column
            For Each col As DataGridViewColumn In DataGridView4.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                If col.Name = "Date" Then
                    col.DefaultCellStyle.Format = "MMMM dd, yyyy"
                End If
            Next

            DataGridView4.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        ' Tawagin ang mga karagdagang function kung kinakailangan
        LoadNetIncomeData()
        AutoComputeNetIncome()
    End Sub
    Private Sub AutoComputeNetIncome()
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()

                Dim query As String =
                    "SELECT es.ID AS SalaryID, gr.ID AS GrossRevenueID, es.Date, " &
                    "COALESCE(es.Salary, 0) AS Salary, COALESCE(gr.GrossRevenue, 0) AS GrossRevenue " &
                    "FROM EmployeeSalary es " &
                    "JOIN GrossRevenue gr ON es.Date = gr.Date " &
                    "WHERE NOT EXISTS (SELECT 1 FROM NetIncome ni WHERE ni.Date = es.Date)"

                Using command As New SqlCommand(query, connection)
                    Dim reader As SqlDataReader = command.ExecuteReader()

                    Dim netIncomeCommands As New List(Of SqlCommand)

                    While reader.Read()
                        Dim salaryID As Integer = CInt(reader("SalaryID"))
                        Dim grossRevenueID As Integer = CInt(reader("GrossRevenueID"))
                        Dim transactionDate As Date = CDate(reader("Date"))
                        Dim salary As Decimal = CDec(reader("Salary"))
                        Dim grossRevenue As Decimal = CDec(reader("GrossRevenue"))

                        If grossRevenue = 0 Then Continue While

                        Dim netIncome As Decimal = grossRevenue - salary

                        Dim insertCmd As New SqlCommand(
                            "INSERT INTO NetIncome (SalaryID, GrossRevenueID, NetIncome, Date) " &
                            "VALUES (@SalaryID, @GrossRevenueID, @NetIncome, @Date)",
                            connection
                        )

                        insertCmd.Parameters.AddWithValue("@SalaryID", salaryID)
                        insertCmd.Parameters.AddWithValue("@GrossRevenueID", grossRevenueID)
                        insertCmd.Parameters.AddWithValue("@NetIncome", netIncome)
                        insertCmd.Parameters.AddWithValue("@Date", transactionDate)

                        netIncomeCommands.Add(insertCmd)
                    End While

                    reader.Close()

                    For Each cmda In netIncomeCommands
                        cmda.ExecuteNonQuery()
                    Next

                End Using
            End Using

            LoadNetIncomeData()

        Catch ex As Exception
            MessageBox.Show("Error computing Net Income: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub LoadNetIncomeData()
        Using connection As New SqlConnection(connectionString)
            ' Base query na may WHERE clause para sa madaling pagdagdag ng filters
            Dim query As String = _
                "SELECT es.Date AS [Transaction Date], " & _
                "COALESCE(SUM(es.Salary), 0) AS [Total Salary], " & _
                "COALESCE(gr.GrossRevenue, 0) AS [Gross Revenue], " & _
                "(COALESCE(gr.GrossRevenue, 0) - COALESCE(SUM(es.Salary), 0)) AS [Net Income] " & _
                "FROM EmployeeSalary es " & _
                "JOIN GrossRevenue gr ON es.Date = gr.Date " & _
                "WHERE 1=1 "

            ' ✅ Month Filtering gamit ang es.Date column
            Dim selectedMonth As String = "All"
            Dim monthNumber As Integer = 0
            If Cb_Month3.SelectedItem IsNot Nothing Then
                selectedMonth = Cb_Month3.SelectedItem.ToString()
            End If
            If selectedMonth <> "All" Then
                monthNumber = Array.IndexOf(New String() {"January", "February", "March", "April", "May", "June", _
                                                           "July", "August", "September", "October", "November", "December"}, selectedMonth) + 1
                query &= " AND MONTH(es.Date) = @Month"
            End If

            ' ✅ Year Filtering gamit ang es.Date column
            Dim selectedYear As String = "All"
            If Cb_Year3.SelectedItem IsNot Nothing Then
                selectedYear = Cb_Year3.SelectedItem.ToString()
            End If
            If selectedYear <> "All" Then
                query &= " AND YEAR(es.Date) = @Year"
            End If

            ' GROUP BY at ORDER BY (Ascending para ang latest na insert ay nasa baba)
            query &= " GROUP BY es.Date, gr.GrossRevenue"
            query &= " ORDER BY es.Date ASC"

            Dim dt As New DataTable()

            ' Using block para sa tamang pamamahala ng connection at pag-fill ng DataTable
            Using cmd As New SqlCommand(query, connection)
                If selectedMonth <> "All" Then
                    cmd.Parameters.AddWithValue("@Month", monthNumber)
                End If
                If selectedYear <> "All" Then
                    cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(selectedYear))
                End If

                connection.Open()
                Dim adapter As New SqlDataAdapter(cmd)
                adapter.Fill(dt)
                connection.Close()
            End Using

            ' I-bind ang DataTable sa DataGridView4
            DataGridView4.DataSource = dt

            ' Center-align ang cell content sa lahat ng columns
            For Each column As DataGridViewColumn In DataGridView4.Columns
                column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            Next
            DataGridView4.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        End Using
    End Sub

    Private Sub Txt_SmallWaterRefill_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_SmallWaterRefill.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Txt_SmallContainerWater_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_SmallContainerWater.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Txt_SmallContainer_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_SmallContainer.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Cb_Fullname_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Cb_Fullname.KeyPress
        ' Payagan ang control characters tulad ng Backspace, Enter, etc.
        If Char.IsControl(e.KeyChar) Then Exit Sub

        ' Papayagan lang ang mga letra, dot, at space
        If Not Char.IsLetter(e.KeyChar) AndAlso e.KeyChar <> "."c AndAlso e.KeyChar <> " "c Then
            e.Handled = True
            Exit Sub
        End If

        ' Kung key na pinindot ay letra, i-format ito base sa posisyon
        If Char.IsLetter(e.KeyChar) Then
            Dim pos As Integer = Cb_Fullname.SelectionStart
            ' Kung unang character ng textbox o pagkatapos ng space, gawing uppercase
            If pos = 0 OrElse (pos > 0 AndAlso Cb_Fullname.Text.Chars(pos - 1) = " "c) Then
                e.KeyChar = Char.ToUpper(e.KeyChar)
            Else
                ' Kung nasa gitna ng salita, gawing lowercase
                e.KeyChar = Char.ToLower(e.KeyChar)
            End If
        End If
    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label5.Click

    End Sub
End Class