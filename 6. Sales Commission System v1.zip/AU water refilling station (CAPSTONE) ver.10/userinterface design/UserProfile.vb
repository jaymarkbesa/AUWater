﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class UserProfile
    Private ReadOnly connectionString As String =
        ConfigurationManager.ConnectionStrings("MyDB").ConnectionString
    Private conn As New SqlConnection(connectionString)
    Private adapter As SqlDataAdapter
    Private dt As DataTable

    ' === Form Load ===
    Private Sub UserProfile_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        RefreshDataGridView1()
        RefreshLoginHistory()
        DataGridView1.ClearSelection()
        DataGridView2.ClearSelection()
        ClearTextBoxes()
    End Sub

    ' === Refresh Profiles Grid ===
    Private Sub RefreshDataGridView1()
        Try
            Dim query As String =
                "SELECT UI.ID, UI.FullName, UI.Gmail, UI.PhoneNumber, UI.Date, L.Username " &
                "FROM UserInfo AS UI " &
                "INNER JOIN [Login] AS L ON UI.UserID = L.ID;"
            dt = New DataTable()
            adapter = New SqlDataAdapter(query, conn)
            adapter.Fill(dt)
            DataGridView1.DataSource = dt

            DataGridView1.Columns("PhoneNumber").HeaderText = "Phone Number"
            For Each col As DataGridViewColumn In DataGridView1.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                If col.Name = "Date" Then col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
            Next
            DataGridView1.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Catch ex As Exception
            MessageBox.Show("Error loading profiles: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' === Refresh LoginHistory Grid ===
    Public Sub RefreshLoginHistory()
        Try
            Dim query As String =
                "SELECT HistoryID, LoginTime, LogoutTime " &
                "FROM LoginHistory " &
                "ORDER BY LoginTime DESC;"
            Dim historyDt As New DataTable()
            Dim historyAdapter As New SqlDataAdapter(query, conn)
            historyAdapter.Fill(historyDt)
            DataGridView2.DataSource = historyDt

            With DataGridView2
                .Columns("HistoryID").HeaderText = "ID"
                .Columns("LoginTime").HeaderText = "Login Time"
                .Columns("LogoutTime").HeaderText = "Logout Time"
                .Columns("LoginTime").DefaultCellStyle.Format = "MMMM dd, yyyy hh:mm:ss tt"
                .Columns("LogoutTime").DefaultCellStyle.Format = "MMMM dd, yyyy hh:mm:ss tt"
                For Each col As DataGridViewColumn In .Columns
                    col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                Next
                .RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            End With
        Catch ex As Exception
            MessageBox.Show("Error loading login history: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' === Clear all input TextBoxes ===
    Private Sub ClearTextBoxes()
        Txt_Fullname.Clear()
        Txt_Gmail.Clear()
        Txt_Contact.Clear()
        Txt_Username.Clear()
        Txt_CurrentPass.Clear()
        Txt_NewPass.Clear()
        Txt_ConfirmPass.Clear()
    End Sub

    ' === Navigation & Clear Buttons ===
    Private Sub Btn_Back_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_Back.Click
        Me.Hide()
        Home.Show()
        ClearTextBoxes()
        DataGridView1.ClearSelection()
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_Clear.Click
        ClearTextBoxes()
        DataGridView1.ClearSelection()
    End Sub

    ' === Password Visibility Toggles ===
    Private Sub Btn_ShowPass_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_ShowPass.Click
        Txt_NewPass.UseSystemPasswordChar = Not Txt_NewPass.UseSystemPasswordChar
    End Sub

    Private Sub Btn_ShowPass1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_ShowPass1.Click
        Txt_ConfirmPass.UseSystemPasswordChar = Not Txt_ConfirmPass.UseSystemPasswordChar
    End Sub

    Private Sub Btn_ShowPass2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_ShowPass2.Click
        Txt_CurrentPass.UseSystemPasswordChar = Not Txt_CurrentPass.UseSystemPasswordChar
    End Sub

    ' === TextBox Navigation on Enter ===
    Private Sub Txt_Fullname_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles Txt_Fullname.KeyDown
        If e.KeyCode = Keys.Enter Then e.SuppressKeyPress = True : Txt_Gmail.Focus()
    End Sub
    Private Sub Txt_Gmail_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles Txt_Gmail.KeyDown
        If e.KeyCode = Keys.Enter Then e.SuppressKeyPress = True : Txt_Contact.Focus()
    End Sub
    Private Sub Txt_Contact_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles Txt_Contact.KeyDown
        If e.KeyCode = Keys.Enter Then e.SuppressKeyPress = True : Txt_Username.Focus()
    End Sub
    Private Sub Txt_Username_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles Txt_Username.KeyDown
        If e.KeyCode = Keys.Enter Then e.SuppressKeyPress = True : Txt_CurrentPass.Focus()
    End Sub
    Private Sub Txt_CurrentPass_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles Txt_CurrentPass.KeyDown
        If e.KeyCode = Keys.Enter Then e.SuppressKeyPress = True : Txt_NewPass.Focus()
    End Sub
    Private Sub Txt_NewPass_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles Txt_NewPass.KeyDown
        If e.KeyCode = Keys.Enter Then e.SuppressKeyPress = True : Txt_ConfirmPass.Focus()
    End Sub
    Private Sub Txt_ConfirmPass_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles Txt_ConfirmPass.KeyDown
        If e.KeyCode = Keys.Enter Then e.SuppressKeyPress = True : Btn_Update_Click(sender, e)
    End Sub

    ' === Numeric-only Contact ===
    Private Sub Txt_Contact_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles Txt_Contact.KeyPress
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then e.Handled = True
        If Txt_Contact.TextLength >= 11 AndAlso Not Char.IsControl(e.KeyChar) Then e.Handled = True
    End Sub

    ' === Update User Profile ===
    Private Sub Btn_Update_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_Update.Click
        Try
            ' Ensure a profile is selected
            If DataGridView1.SelectedRows.Count = 0 Then
                MessageBox.Show("Please select a row to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If

            ' Ensure current password is entered
            If String.IsNullOrWhiteSpace(Txt_CurrentPass.Text) Then
                MessageBox.Show("Please enter your current password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_CurrentPass.Focus()
                Return
            End If

            ' Ensure required fields are filled
            If String.IsNullOrWhiteSpace(Txt_Fullname.Text) OrElse
               String.IsNullOrWhiteSpace(Txt_Gmail.Text) OrElse
               String.IsNullOrWhiteSpace(Txt_Contact.Text) OrElse
               String.IsNullOrWhiteSpace(Txt_Username.Text) Then
                MessageBox.Show("Please fill in all required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If

            ' Verify current password
            Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)
            Dim userInfoID As Integer = Convert.ToInt32(selectedRow.Cells("ID").Value)
            Dim isCurrentValid As Boolean
            Using checkCon As New SqlConnection(connectionString)
                Using checkCmd As New SqlCommand(
                    "SELECT COUNT(*) FROM [Login] " &
                    "WHERE ID = (SELECT UserID FROM UserInfo WHERE ID = @UID) " &
                    "AND Password COLLATE Latin1_General_CS_AS = @PWD", checkCon)
                    checkCmd.Parameters.AddWithValue("@UID", userInfoID)
                    checkCmd.Parameters.AddWithValue("@PWD", Txt_CurrentPass.Text.Trim())
                    checkCon.Open()
                    isCurrentValid = Convert.ToInt32(checkCmd.ExecuteScalar()) > 0
                End Using
            End Using
            If Not isCurrentValid Then
                MessageBox.Show("Current password is incorrect.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_CurrentPass.Clear()
                Txt_CurrentPass.Focus()
                Return
            End If

            ' Validate email & phone
            If Not IsValidEmail(Txt_Gmail.Text.Trim()) Then
                MessageBox.Show("Please enter a valid email address.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Gmail.Clear()
                Txt_Gmail.Focus()
                Return
            End If
            If Not IsValidPhoneNumber(Txt_Contact.Text.Trim()) Then
                MessageBox.Show("Please enter a valid phone number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Contact.Clear()
                Txt_Contact.Focus()
                Return
            End If

            ' Determine if password should be updated
            Dim updatePassword As Boolean = False
            If Not String.IsNullOrWhiteSpace(Txt_NewPass.Text) OrElse Not String.IsNullOrWhiteSpace(Txt_ConfirmPass.Text) Then
                If String.IsNullOrWhiteSpace(Txt_NewPass.Text) OrElse String.IsNullOrWhiteSpace(Txt_ConfirmPass.Text) Then
                    MessageBox.Show("Fill both new password and confirmation.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return
                End If
                If Txt_NewPass.Text.Trim() <> Txt_ConfirmPass.Text.Trim() Then
                    MessageBox.Show("New password and confirmation do not match.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_NewPass.Clear() : Txt_ConfirmPass.Clear() : Txt_NewPass.Focus()
                    Return
                End If
                If Txt_NewPass.Text.Trim() = Txt_CurrentPass.Text.Trim() Then
                    MessageBox.Show("New password must differ from current.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_NewPass.Clear() : Txt_ConfirmPass.Clear() : Txt_NewPass.Focus()
                    Return
                End If
                updatePassword = True
            End If

            ' Proceed with updates
            Using updateCon As New SqlConnection(connectionString)
                updateCon.Open()
                ' Update UserInfo
                Using uiCmd As New SqlCommand(
                    "UPDATE UserInfo SET FullName=@FN, Gmail=@G, PhoneNumber=@PN, [Date]=@D WHERE ID=@UID", updateCon)
                    uiCmd.Parameters.AddWithValue("@FN", Txt_Fullname.Text.Trim())
                    uiCmd.Parameters.AddWithValue("@G", Txt_Gmail.Text.Trim())
                    uiCmd.Parameters.AddWithValue("@PN", Txt_Contact.Text.Trim())
                    uiCmd.Parameters.AddWithValue("@D", DateTimePicker2.Value.ToString("yyyy-MM-dd"))
                    uiCmd.Parameters.AddWithValue("@UID", userInfoID)
                    If uiCmd.ExecuteNonQuery() > 0 Then
                        ' Update Login
                        Dim loginSql As String
                        If updatePassword Then
                            loginSql = "UPDATE [Login] SET Username=@UN, Password=@PWD " &
                                       "WHERE ID=(SELECT UserID FROM UserInfo WHERE ID=@UID)"
                        Else
                            loginSql = "UPDATE [Login] SET Username=@UN " &
                                       "WHERE ID=(SELECT UserID FROM UserInfo WHERE ID=@UID)"
                        End If
                        Using loginCmd As New SqlCommand(loginSql, updateCon)
                            loginCmd.Parameters.AddWithValue("@UN", Txt_Username.Text.Trim())
                            If updatePassword Then
                                loginCmd.Parameters.AddWithValue("@PWD", Txt_NewPass.Text.Trim())
                            End If
                            loginCmd.Parameters.AddWithValue("@UID", userInfoID)
                            If loginCmd.ExecuteNonQuery() > 0 Then
                                MessageBox.Show("User profile updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                RefreshDataGridView1()
                                ClearTextBoxes()
                                DataGridView1.ClearSelection()
                            Else
                                MessageBox.Show("Failed to update Login table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            End If
                        End Using
                    Else
                        MessageBox.Show("Failed to update UserInfo table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' === Populate inputs when profile selected ===
    Private Sub DataGridView1_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles DataGridView1.SelectionChanged
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim row = DataGridView1.SelectedRows(0)
            Txt_Fullname.Text = row.Cells("FullName").Value.ToString()
            Txt_Gmail.Text = row.Cells("Gmail").Value.ToString()
            Txt_Contact.Text = row.Cells("PhoneNumber").Value.ToString()
            Txt_Username.Text = row.Cells("Username").Value.ToString()
            DateTimePicker1.Value = Convert.ToDateTime(row.Cells("Date").Value)
            Txt_Fullname.Enabled = True
            Txt_Gmail.Enabled = True
            Txt_Contact.Enabled = True
            Txt_Username.Enabled = True
            Txt_CurrentPass.Enabled = True
            Txt_NewPass.Enabled = True
            Txt_ConfirmPass.Enabled = True
        Else
            ClearTextBoxes()
            DataGridView1.ClearSelection()
            Txt_Fullname.Enabled = False
            Txt_Gmail.Enabled = False
            Txt_Contact.Enabled = False
            Txt_Username.Enabled = False
            Txt_CurrentPass.Enabled = False
            Txt_NewPass.Enabled = False
            Txt_ConfirmPass.Enabled = False
        End If
    End Sub

    ' === FullName formatting ===
    Private Sub Txt_Fullname_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles Txt_Fullname.KeyPress
        If Char.IsControl(e.KeyChar) Then Return
        If Not Char.IsLetter(e.KeyChar) AndAlso e.KeyChar <> "."c AndAlso e.KeyChar <> " "c Then
            e.Handled = True : Return
        End If
        If Char.IsLetter(e.KeyChar) Then
            Dim pos = Txt_Fullname.SelectionStart
            e.KeyChar = If(pos = 0 OrElse Txt_Fullname.Text.Chars(pos - 1) = " "c,
                          Char.ToUpper(e.KeyChar),
                          Char.ToLower(e.KeyChar))
        End If
    End Sub

    ' === Email & Phone Validators ===
    Private Function IsValidEmail(ByVal email As String) As Boolean
        Dim pattern As String = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        Return System.Text.RegularExpressions.Regex.IsMatch(email, pattern)
    End Function

    Private Function IsValidPhoneNumber(ByVal phoneNumber As String) As Boolean
        Dim pattern As String = "^(09|\+639)\d{9}$"
        Return System.Text.RegularExpressions.Regex.IsMatch(phoneNumber, pattern)
    End Function

End Class
