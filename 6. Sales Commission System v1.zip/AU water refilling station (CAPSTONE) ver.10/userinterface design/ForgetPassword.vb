﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Net
Imports System.Net.Mail
Imports System.Configuration
Imports System.Text.RegularExpressions

Public Class ForgetPassword
    Dim Username As String = "mail.org.noreply@gmail.com"
    Dim Password As String = "lzen zabl fdpj kbku"
    Dim connectionString As String = ConfigurationManager.ConnectionStrings("MyDB").ConnectionString
    Dim conn As New SqlConnection(connectionString)

    Private generatedOTP As String
    Private userID As Integer

    Private Sub ForgetPassword_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        generatedOTP = GenerateRandomOTP()

        If My.Settings.CooldownEndTime = Date.MinValue Then
            My.Settings.CooldownEndTime = #12:00:00 AM#
            My.Settings.Save()
        End If
    End Sub

    Private Function GenerateRandomOTP() As String
        Dim random As New Random()
        Const chars As String = "0123456789"
        Return New String(Enumerable.Repeat(chars, 5).Select(Function(s) s(random.Next(s.Length))).ToArray())
    End Function

    Private Function IsValidEmail(ByVal email As String) As Boolean
        Dim pattern As String = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        Return Regex.IsMatch(email, pattern)
    End Function

    Private Sub Btn_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        Me.Hide()
        Login.Show()
    End Sub

    Private Sub Txt_Gmail_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Gmail.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True ' Suppress the Enter key press
            Btn_Confirm_Click(sender, e) ' Trigger the confirm button click event
        End If
    End Sub

    ' Helper function para itakda ang cooldown
    Private Sub TriggerCooldown()
        My.Settings.CooldownEndTime = DateTime.Now.AddMinutes(3)
        My.Settings.Save()
    End Sub

    Private mistakeCount As Integer = 0 ' Ilagay ito sa class level

    Private Sub Btn_Confirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Confirm.Click
        Try
            ' I-check kung active pa ang cooldown
            If DateTime.Now < My.Settings.CooldownEndTime Then
                Dim remaining As TimeSpan = My.Settings.CooldownEndTime - DateTime.Now
                MessageBox.Show("Please wait for " & remaining.Minutes.ToString() & " minute(s) and " & remaining.Seconds.ToString() & " second(s) before trying again.", _
                                "Cooldown Active", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If

            ' Validate email format
            If Not IsValidEmail(Txt_Gmail.Text) Then
                MessageBox.Show("Please enter a valid email address.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Gmail.Clear()
                Txt_Gmail.Focus()
                Exit Sub
            End If

            ' Check if email exists in database
            Dim query As String = "SELECT UserInfo.UserID, UserInfo.Gmail, Login.Username, Login.Password " & _
                                  "FROM UserInfo INNER JOIN Login ON UserInfo.UserID = Login.ID " & _
                                  "WHERE UserInfo.Gmail = @Gmail"
            Dim cmd As New SqlCommand(query, conn)
            cmd.Parameters.Add("@Gmail", SqlDbType.NVarChar).Value = Txt_Gmail.Text

            Dim da As New SqlDataAdapter(cmd)
            Dim dt As New DataTable
            da.Fill(dt)

            Dim currentPassword As String = ""

            If dt.Rows.Count > 0 Then
                userID = CInt(dt.Rows(0)(0))
                Txt_Username.Text = dt.Rows(0)(2).ToString()
                currentPassword = dt.Rows(0)(3).ToString() ' Kunin ang current password mula sa database
            Else
                MessageBox.Show("The email address is not registered.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Gmail.Clear()
                Txt_Gmail.Focus()
                Exit Sub
            End If

            ' Mag-send ng OTP sa email
            Dim smtp As New SmtpClient
            smtp.UseDefaultCredentials = False
            smtp.Credentials = New Net.NetworkCredential(Username, Password)
            smtp.Port = 587
            smtp.EnableSsl = True
            smtp.Host = "smtp.gmail.com"

            Dim mail As New MailMessage
            mail.From = New MailAddress(Username, "Au Water Refilling Station")
            mail.To.Add(Txt_Gmail.Text)
            mail.Subject = "Password Recovery OTP"
            mail.Body = "Hi " & Txt_Username.Text & ",<br/><br/>" & _
                        "Your OTP for password recovery is: <b>" & generatedOTP & "</b><br/><br/>" & _
                        "Please enter this OTP in the system to reset your password.<br/><br/>" & _
                        "THANK YOU!"
            mail.IsBodyHtml = True

            smtp.Send(mail)

            MessageBox.Show("An OTP has been sent to your email. Please check your inbox.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Gamitin ang custom input dialog para sa OTP
            Dim otpDialog As New HiddenInputDialog("Enter the OTP sent to your email:", "OTP Verification")
            Dim inputOTP As String = ""
            If otpDialog.ShowDialog() = DialogResult.OK Then
                inputOTP = otpDialog.InputValue
            Else
                If mistakeCount >= 1 Then
                    TriggerCooldown()
                    MessageBox.Show("OTP input was cancelled or blank. You must wait 3 minutes before trying again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mistakeCount = 0
                Else
                    mistakeCount += 1
                    MessageBox.Show("OTP input was cancelled or blank. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                Exit Sub
            End If

            ' Validate OTP
            If inputOTP <> generatedOTP Then
                If mistakeCount >= 1 Then
                    TriggerCooldown()
                    MessageBox.Show("Invalid OTP. You must wait 3 minutes before trying again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mistakeCount = 0
                Else
                    mistakeCount += 1
                    MessageBox.Show("Invalid OTP. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                Txt_Gmail.Clear()
                Exit Sub
            End If

            ' Gamitin ang custom input dialog para sa New Password
            Dim newPassDialog As New HiddenInputDialog("Enter your new password:", "Reset Password")
            Dim newPassword As String = ""
            If newPassDialog.ShowDialog() = DialogResult.OK Then
                newPassword = newPassDialog.InputValue
            Else
                If mistakeCount >= 1 Then
                    TriggerCooldown()
                    MessageBox.Show("Password input was cancelled or blank. You must wait 3 minutes before trying again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mistakeCount = 0
                Else
                    mistakeCount += 1
                    MessageBox.Show("Password input was cancelled or blank. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                Exit Sub
            End If

            ' I-check kung ang new password ay kapareho ng current password
            If newPassword = currentPassword Then
                If mistakeCount >= 1 Then
                    TriggerCooldown()
                    MessageBox.Show("New password cannot be the same as the current password. You must wait 3 minutes before trying again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mistakeCount = 0
                Else
                    mistakeCount += 1
                    MessageBox.Show("New password cannot be the same as the current password. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                Exit Sub
            End If

            ' Gamitin ang custom input dialog para sa Confirm Password
            Dim confirmPassDialog As New HiddenInputDialog("Confirm your new password:", "Confirm Password")
            Dim confirmPassword As String = ""
            If confirmPassDialog.ShowDialog() = DialogResult.OK Then
                confirmPassword = confirmPassDialog.InputValue
            Else
                If mistakeCount >= 1 Then
                    TriggerCooldown()
                    MessageBox.Show("Confirm password input was cancelled or blank. You must wait 3 minutes before trying again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mistakeCount = 0
                Else
                    mistakeCount += 1
                    MessageBox.Show("Confirm password input was cancelled or blank. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                Exit Sub
            End If

            ' I-check kung tugma ang new password at confirm password
            If newPassword <> confirmPassword Then
                If mistakeCount >= 1 Then
                    TriggerCooldown()
                    MessageBox.Show("Passwords do not match. You must wait 3 minutes before trying again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    mistakeCount = 0
                Else
                    mistakeCount += 1
                    MessageBox.Show("Passwords do not match. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                Exit Sub
            End If

            ' Reset mistake counter kapag tama na ang lahat
            mistakeCount = 0

            ' Update password sa database
            UpdatePassword(newPassword)
            MessageBox.Show("Your password has been successfully updated!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Txt_Gmail.Clear()
            Login.Show()
            Me.Hide()

        Catch ex As Exception
            MsgBox(ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub UpdatePassword(ByVal newPassword As String)
        Try
            Dim updateQuery As String = "UPDATE Login SET Password = @NewPassword WHERE ID = @UserID"
            Dim updateCmd As New SqlCommand(updateQuery, conn)
            updateCmd.Parameters.Add("@NewPassword", SqlDbType.NVarChar).Value = newPassword
            updateCmd.Parameters.Add("@UserID", SqlDbType.Int).Value = userID

            conn.Open()
            updateCmd.ExecuteNonQuery()
            conn.Close()

        Catch ex As Exception
            MessageBox.Show("Error updating password: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class
