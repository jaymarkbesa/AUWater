﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ChartArea1 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend1 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series1 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea2 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend2 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series2 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Home))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Btn_UserInfo = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Btn_Logout = New System.Windows.Forms.Button()
        Me.Btn_Recycle = New System.Windows.Forms.Button()
        Me.Btn_Reports = New System.Windows.Forms.Button()
        Me.Btn_EmployeeInfo = New System.Windows.Forms.Button()
        Me.Btn_Bills = New System.Windows.Forms.Button()
        Me.Btn_Calculation = New System.Windows.Forms.Button()
        Me.Btn_Home = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Txt_Time = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Lbl_WaterRefillSold = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Lbl_ContainerWaterSold = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Lbl_WaterRefillIncome = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Lbl_ContainerWaterIncome = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Lbl_ContainerSold = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Lbl_ContainerIncome = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Txt_PriceGallon = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Txt_PriceContainerWater = New System.Windows.Forms.TextBox()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Txt_PriceContainer = New System.Windows.Forms.TextBox()
        Me.Btn_EditPrice = New System.Windows.Forms.Button()
        Me.Btn_Save = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel_Form1 = New System.Windows.Forms.Panel()
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel35 = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Panel34 = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Panel33 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel30 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Btn_Edit = New System.Windows.Forms.Button()
        Me.Btn_AddGallon = New System.Windows.Forms.Button()
        Me.Panel_Form2 = New System.Windows.Forms.Panel()
        Me.Chart2 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel48 = New System.Windows.Forms.Panel()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Lbl_SmallContainerIncome = New System.Windows.Forms.Label()
        Me.Panel47 = New System.Windows.Forms.Panel()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.Lbl_SmallContainerSold = New System.Windows.Forms.Label()
        Me.Panel46 = New System.Windows.Forms.Panel()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Lbl_ContainerIncome1 = New System.Windows.Forms.Label()
        Me.Panel45 = New System.Windows.Forms.Panel()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Lbl_ContainerSold1 = New System.Windows.Forms.Label()
        Me.Panel44 = New System.Windows.Forms.Panel()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.Lbl_SmallContainerwithWaterIncome = New System.Windows.Forms.Label()
        Me.Panel43 = New System.Windows.Forms.Panel()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.Lbl_SmallContainerwithWaterSold = New System.Windows.Forms.Label()
        Me.Panel42 = New System.Windows.Forms.Panel()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Lbl_ContainerWaterIncome1 = New System.Windows.Forms.Label()
        Me.Panel41 = New System.Windows.Forms.Panel()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.Lbl_ContainerWaterSold1 = New System.Windows.Forms.Label()
        Me.Panel40 = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.Lbl_SmallRefillIncome = New System.Windows.Forms.Label()
        Me.Panel39 = New System.Windows.Forms.Panel()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.Lbl_SmallRefillSold = New System.Windows.Forms.Label()
        Me.Panel38 = New System.Windows.Forms.Panel()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Lbl_WaterRefillIncome1 = New System.Windows.Forms.Label()
        Me.Panel37 = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.Lbl_WaterRefillSold1 = New System.Windows.Forms.Label()
        Me.Btn_Change = New System.Windows.Forms.Button()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Txt_PriceSmallContainer = New System.Windows.Forms.TextBox()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Txt_PriceSmallContainerWater = New System.Windows.Forms.TextBox()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Txt_PriceSmallGallon = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Txt_PriceContainer1 = New System.Windows.Forms.TextBox()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Txt_PriceContainerWater1 = New System.Windows.Forms.TextBox()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Txt_PriceGallon1 = New System.Windows.Forms.TextBox()
        Me.Btn_EditPrice1 = New System.Windows.Forms.Button()
        Me.Btn_Save1 = New System.Windows.Forms.Button()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Cb_Year = New System.Windows.Forms.ComboBox()
        Me.Cb_Month = New System.Windows.Forms.ComboBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Cb_Year1 = New System.Windows.Forms.ComboBox()
        Me.Cb_Month1 = New System.Windows.Forms.ComboBox()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel_Form1.SuspendLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel35.SuspendLayout()
        Me.Panel34.SuspendLayout()
        Me.Panel33.SuspendLayout()
        Me.Panel32.SuspendLayout()
        Me.Panel31.SuspendLayout()
        Me.Panel30.SuspendLayout()
        Me.Panel_Form2.SuspendLayout()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel48.SuspendLayout()
        Me.Panel29.SuspendLayout()
        Me.Panel47.SuspendLayout()
        Me.Panel28.SuspendLayout()
        Me.Panel46.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel45.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel44.SuspendLayout()
        Me.Panel26.SuspendLayout()
        Me.Panel43.SuspendLayout()
        Me.Panel25.SuspendLayout()
        Me.Panel42.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel41.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.Panel40.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.Panel39.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.Panel38.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel37.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.Panel27.SuspendLayout()
        Me.Panel24.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Btn_UserInfo)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Btn_Logout)
        Me.Panel1.Controls.Add(Me.Btn_Recycle)
        Me.Panel1.Controls.Add(Me.Btn_Reports)
        Me.Panel1.Controls.Add(Me.Btn_EmployeeInfo)
        Me.Panel1.Controls.Add(Me.Btn_Bills)
        Me.Panel1.Controls.Add(Me.Btn_Calculation)
        Me.Panel1.Controls.Add(Me.Btn_Home)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(284, 789)
        Me.Panel1.TabIndex = 0
        '
        'Btn_UserInfo
        '
        Me.Btn_UserInfo.BackColor = System.Drawing.Color.Transparent
        Me.Btn_UserInfo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_UserInfo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_UserInfo.FlatAppearance.BorderSize = 0
        Me.Btn_UserInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_UserInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_UserInfo.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_settings_32
        Me.Btn_UserInfo.Location = New System.Drawing.Point(164, 224)
        Me.Btn_UserInfo.Name = "Btn_UserInfo"
        Me.Btn_UserInfo.Size = New System.Drawing.Size(42, 38)
        Me.Btn_UserInfo.TabIndex = 74
        Me.Btn_UserInfo.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(70, 231)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 27)
        Me.Label1.TabIndex = 73
        Me.Label1.Text = "ADMIN"
        '
        'Btn_Logout
        '
        Me.Btn_Logout.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Logout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Logout.FlatAppearance.BorderSize = 0
        Me.Btn_Logout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Logout.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Logout.ForeColor = System.Drawing.Color.White
        Me.Btn_Logout.Location = New System.Drawing.Point(27, 719)
        Me.Btn_Logout.Name = "Btn_Logout"
        Me.Btn_Logout.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Logout.TabIndex = 72
        Me.Btn_Logout.Text = "LOGOUT"
        Me.Btn_Logout.UseVisualStyleBackColor = False
        '
        'Btn_Recycle
        '
        Me.Btn_Recycle.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Recycle.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Recycle.FlatAppearance.BorderSize = 0
        Me.Btn_Recycle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Recycle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Recycle.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Recycle.ForeColor = System.Drawing.Color.White
        Me.Btn_Recycle.Location = New System.Drawing.Point(27, 565)
        Me.Btn_Recycle.Name = "Btn_Recycle"
        Me.Btn_Recycle.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Recycle.TabIndex = 71
        Me.Btn_Recycle.Text = "ARCHIVE"
        Me.Btn_Recycle.UseVisualStyleBackColor = False
        '
        'Btn_Reports
        '
        Me.Btn_Reports.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Reports.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Reports.FlatAppearance.BorderSize = 0
        Me.Btn_Reports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Reports.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Reports.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Reports.ForeColor = System.Drawing.Color.White
        Me.Btn_Reports.Location = New System.Drawing.Point(27, 510)
        Me.Btn_Reports.Name = "Btn_Reports"
        Me.Btn_Reports.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Reports.TabIndex = 70
        Me.Btn_Reports.Text = "REPORTS"
        Me.Btn_Reports.UseVisualStyleBackColor = False
        '
        'Btn_EmployeeInfo
        '
        Me.Btn_EmployeeInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_EmployeeInfo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_EmployeeInfo.FlatAppearance.BorderSize = 0
        Me.Btn_EmployeeInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_EmployeeInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_EmployeeInfo.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_EmployeeInfo.ForeColor = System.Drawing.Color.White
        Me.Btn_EmployeeInfo.Location = New System.Drawing.Point(27, 345)
        Me.Btn_EmployeeInfo.Name = "Btn_EmployeeInfo"
        Me.Btn_EmployeeInfo.Size = New System.Drawing.Size(231, 49)
        Me.Btn_EmployeeInfo.TabIndex = 69
        Me.Btn_EmployeeInfo.Text = "EMPLOYEE INFORMATION"
        Me.Btn_EmployeeInfo.UseVisualStyleBackColor = False
        '
        'Btn_Bills
        '
        Me.Btn_Bills.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Bills.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Bills.FlatAppearance.BorderSize = 0
        Me.Btn_Bills.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Bills.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Bills.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Bills.ForeColor = System.Drawing.Color.White
        Me.Btn_Bills.Location = New System.Drawing.Point(27, 455)
        Me.Btn_Bills.Name = "Btn_Bills"
        Me.Btn_Bills.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Bills.TabIndex = 68
        Me.Btn_Bills.Text = "WATER BILLS AND ELECTRICITY"
        Me.Btn_Bills.UseVisualStyleBackColor = False
        '
        'Btn_Calculation
        '
        Me.Btn_Calculation.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Calculation.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Calculation.FlatAppearance.BorderSize = 0
        Me.Btn_Calculation.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Calculation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Calculation.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Calculation.ForeColor = System.Drawing.Color.White
        Me.Btn_Calculation.Location = New System.Drawing.Point(27, 400)
        Me.Btn_Calculation.Name = "Btn_Calculation"
        Me.Btn_Calculation.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Calculation.TabIndex = 67
        Me.Btn_Calculation.Text = "SALARY AND INCOME CALCULATION"
        Me.Btn_Calculation.UseVisualStyleBackColor = False
        '
        'Btn_Home
        '
        Me.Btn_Home.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Home.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Home.FlatAppearance.BorderSize = 2
        Me.Btn_Home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Home.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Home.ForeColor = System.Drawing.Color.White
        Me.Btn_Home.Location = New System.Drawing.Point(27, 290)
        Me.Btn_Home.Name = "Btn_Home"
        Me.Btn_Home.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Home.TabIndex = 65
        Me.Btn_Home.Text = "HOME"
        Me.Btn_Home.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = Global.WindowsApplication1.My.Resources.Resources._439432707_3811750089048465_8998649572546640568_n_removebg_preview2
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(284, 218)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 64
        Me.PictureBox1.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Txt_Time)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(284, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1008, 94)
        Me.Panel3.TabIndex = 10
        '
        'Txt_Time
        '
        Me.Txt_Time.Font = New System.Drawing.Font("Rockwell", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Time.ForeColor = System.Drawing.Color.White
        Me.Txt_Time.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_time_501
        Me.Txt_Time.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Txt_Time.Location = New System.Drawing.Point(176, 9)
        Me.Txt_Time.Name = "Txt_Time"
        Me.Txt_Time.Size = New System.Drawing.Size(656, 70)
        Me.Txt_Time.TabIndex = 0
        Me.Txt_Time.Text = "DATE"
        Me.Txt_Time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Transparent
        Me.Panel4.Controls.Add(Me.Lbl_WaterRefillSold)
        Me.Panel4.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel4.ForeColor = System.Drawing.Color.White
        Me.Panel4.Location = New System.Drawing.Point(3, 3)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(173, 100)
        Me.Panel4.TabIndex = 11
        '
        'Lbl_WaterRefillSold
        '
        Me.Lbl_WaterRefillSold.AutoSize = True
        Me.Lbl_WaterRefillSold.Font = New System.Drawing.Font("Rockwell", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_WaterRefillSold.Location = New System.Drawing.Point(58, 16)
        Me.Lbl_WaterRefillSold.Name = "Lbl_WaterRefillSold"
        Me.Lbl_WaterRefillSold.Size = New System.Drawing.Size(62, 68)
        Me.Lbl_WaterRefillSold.TabIndex = 1
        Me.Lbl_WaterRefillSold.Text = "0"
        Me.Lbl_WaterRefillSold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Transparent
        Me.Panel5.Controls.Add(Me.Lbl_ContainerWaterSold)
        Me.Panel5.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel5.ForeColor = System.Drawing.Color.White
        Me.Panel5.Location = New System.Drawing.Point(1, 3)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(178, 100)
        Me.Panel5.TabIndex = 12
        '
        'Lbl_ContainerWaterSold
        '
        Me.Lbl_ContainerWaterSold.AutoSize = True
        Me.Lbl_ContainerWaterSold.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_ContainerWaterSold.Location = New System.Drawing.Point(58, 16)
        Me.Lbl_ContainerWaterSold.Name = "Lbl_ContainerWaterSold"
        Me.Lbl_ContainerWaterSold.Size = New System.Drawing.Size(62, 68)
        Me.Lbl_ContainerWaterSold.TabIndex = 2
        Me.Lbl_ContainerWaterSold.Text = "0"
        Me.Lbl_ContainerWaterSold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Transparent
        Me.Panel6.Controls.Add(Me.Lbl_WaterRefillIncome)
        Me.Panel6.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel6.ForeColor = System.Drawing.Color.White
        Me.Panel6.Location = New System.Drawing.Point(4, 1)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(95, 100)
        Me.Panel6.TabIndex = 13
        '
        'Lbl_WaterRefillIncome
        '
        Me.Lbl_WaterRefillIncome.AutoSize = True
        Me.Lbl_WaterRefillIncome.Font = New System.Drawing.Font("Rockwell", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_WaterRefillIncome.Location = New System.Drawing.Point(33, 35)
        Me.Lbl_WaterRefillIncome.Name = "Lbl_WaterRefillIncome"
        Me.Lbl_WaterRefillIncome.Size = New System.Drawing.Size(29, 31)
        Me.Lbl_WaterRefillIncome.TabIndex = 2
        Me.Lbl_WaterRefillIncome.Text = "0"
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.Transparent
        Me.Panel7.Controls.Add(Me.Lbl_ContainerWaterIncome)
        Me.Panel7.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel7.ForeColor = System.Drawing.Color.White
        Me.Panel7.Location = New System.Drawing.Point(4, 3)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(95, 100)
        Me.Panel7.TabIndex = 14
        '
        'Lbl_ContainerWaterIncome
        '
        Me.Lbl_ContainerWaterIncome.AutoSize = True
        Me.Lbl_ContainerWaterIncome.Font = New System.Drawing.Font("Rockwell", 16.2!)
        Me.Lbl_ContainerWaterIncome.Location = New System.Drawing.Point(33, 35)
        Me.Lbl_ContainerWaterIncome.Name = "Lbl_ContainerWaterIncome"
        Me.Lbl_ContainerWaterIncome.Size = New System.Drawing.Size(29, 31)
        Me.Lbl_ContainerWaterIncome.TabIndex = 3
        Me.Lbl_ContainerWaterIncome.Text = "0"
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.Transparent
        Me.Panel8.Controls.Add(Me.Lbl_ContainerSold)
        Me.Panel8.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel8.ForeColor = System.Drawing.Color.White
        Me.Panel8.Location = New System.Drawing.Point(2, 0)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(178, 100)
        Me.Panel8.TabIndex = 13
        '
        'Lbl_ContainerSold
        '
        Me.Lbl_ContainerSold.AutoSize = True
        Me.Lbl_ContainerSold.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_ContainerSold.Location = New System.Drawing.Point(58, 16)
        Me.Lbl_ContainerSold.Name = "Lbl_ContainerSold"
        Me.Lbl_ContainerSold.Size = New System.Drawing.Size(62, 68)
        Me.Lbl_ContainerSold.TabIndex = 2
        Me.Lbl_ContainerSold.Text = "0"
        Me.Lbl_ContainerSold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel9.Controls.Add(Me.Lbl_ContainerIncome)
        Me.Panel9.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel9.ForeColor = System.Drawing.Color.White
        Me.Panel9.Location = New System.Drawing.Point(4, 2)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(95, 100)
        Me.Panel9.TabIndex = 15
        '
        'Lbl_ContainerIncome
        '
        Me.Lbl_ContainerIncome.AutoSize = True
        Me.Lbl_ContainerIncome.Font = New System.Drawing.Font("Rockwell", 16.2!)
        Me.Lbl_ContainerIncome.Location = New System.Drawing.Point(33, 35)
        Me.Lbl_ContainerIncome.Name = "Lbl_ContainerIncome"
        Me.Lbl_ContainerIncome.Size = New System.Drawing.Size(29, 31)
        Me.Lbl_ContainerIncome.TabIndex = 4
        Me.Lbl_ContainerIncome.Text = "0"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label16.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(53, 26)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(180, 22)
        Me.Label16.TabIndex = 17
        Me.Label16.Text = "Per Water Gallon's"
        '
        'Txt_PriceGallon
        '
        Me.Txt_PriceGallon.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceGallon.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceGallon.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceGallon.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceGallon.Location = New System.Drawing.Point(109, 64)
        Me.Txt_PriceGallon.Name = "Txt_PriceGallon"
        Me.Txt_PriceGallon.ReadOnly = True
        Me.Txt_PriceGallon.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceGallon.TabIndex = 0
        Me.Txt_PriceGallon.Text = "0"
        Me.Txt_PriceGallon.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.Txt_PriceGallon)
        Me.Panel2.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel2.ForeColor = System.Drawing.Color.White
        Me.Panel2.Location = New System.Drawing.Point(56, 13)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(287, 116)
        Me.Panel2.TabIndex = 26
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel10.Controls.Add(Me.Label2)
        Me.Panel10.Controls.Add(Me.Txt_PriceContainerWater)
        Me.Panel10.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel10.ForeColor = System.Drawing.Color.White
        Me.Panel10.Location = New System.Drawing.Point(348, 13)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(287, 116)
        Me.Panel10.TabIndex = 27
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label2.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(12, 17)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(262, 40)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Per Container with Water"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_PriceContainerWater
        '
        Me.Txt_PriceContainerWater.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceContainerWater.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceContainerWater.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceContainerWater.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceContainerWater.Location = New System.Drawing.Point(109, 64)
        Me.Txt_PriceContainerWater.Name = "Txt_PriceContainerWater"
        Me.Txt_PriceContainerWater.ReadOnly = True
        Me.Txt_PriceContainerWater.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceContainerWater.TabIndex = 1
        Me.Txt_PriceContainerWater.Text = "0"
        Me.Txt_PriceContainerWater.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel11.Controls.Add(Me.Label19)
        Me.Panel11.Controls.Add(Me.Txt_PriceContainer)
        Me.Panel11.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel11.ForeColor = System.Drawing.Color.White
        Me.Panel11.Location = New System.Drawing.Point(641, 13)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(287, 116)
        Me.Panel11.TabIndex = 28
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label19.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(76, 26)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(135, 22)
        Me.Label19.TabIndex = 17
        Me.Label19.Text = "Per Container"
        '
        'Txt_PriceContainer
        '
        Me.Txt_PriceContainer.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceContainer.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceContainer.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceContainer.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceContainer.Location = New System.Drawing.Point(109, 64)
        Me.Txt_PriceContainer.Name = "Txt_PriceContainer"
        Me.Txt_PriceContainer.ReadOnly = True
        Me.Txt_PriceContainer.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceContainer.TabIndex = 2
        Me.Txt_PriceContainer.Text = "0"
        Me.Txt_PriceContainer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Btn_EditPrice
        '
        Me.Btn_EditPrice.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_EditPrice.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_EditPrice.FlatAppearance.BorderSize = 0
        Me.Btn_EditPrice.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_EditPrice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_EditPrice.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_EditPrice.ForeColor = System.Drawing.Color.White
        Me.Btn_EditPrice.Location = New System.Drawing.Point(326, 615)
        Me.Btn_EditPrice.Name = "Btn_EditPrice"
        Me.Btn_EditPrice.Size = New System.Drawing.Size(165, 49)
        Me.Btn_EditPrice.TabIndex = 67
        Me.Btn_EditPrice.Text = "EDIT PRICE"
        Me.Btn_EditPrice.UseVisualStyleBackColor = False
        Me.Btn_EditPrice.Visible = False
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Save.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Save.FlatAppearance.BorderSize = 0
        Me.Btn_Save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Save.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(326, 615)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(165, 49)
        Me.Btn_Save.TabIndex = 68
        Me.Btn_Save.Text = "SAVE"
        Me.Btn_Save.UseVisualStyleBackColor = False
        Me.Btn_Save.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'Panel_Form1
        '
        Me.Panel_Form1.Controls.Add(Me.Label53)
        Me.Panel_Form1.Controls.Add(Me.Label51)
        Me.Panel_Form1.Controls.Add(Me.Label52)
        Me.Panel_Form1.Controls.Add(Me.Cb_Year)
        Me.Panel_Form1.Controls.Add(Me.Cb_Month)
        Me.Panel_Form1.Controls.Add(Me.Chart1)
        Me.Panel_Form1.Controls.Add(Me.Panel35)
        Me.Panel_Form1.Controls.Add(Me.Panel34)
        Me.Panel_Form1.Controls.Add(Me.Panel33)
        Me.Panel_Form1.Controls.Add(Me.Panel32)
        Me.Panel_Form1.Controls.Add(Me.Panel31)
        Me.Panel_Form1.Controls.Add(Me.Panel30)
        Me.Panel_Form1.Controls.Add(Me.Btn_Edit)
        Me.Panel_Form1.Controls.Add(Me.Btn_EditPrice)
        Me.Panel_Form1.Controls.Add(Me.Btn_AddGallon)
        Me.Panel_Form1.Controls.Add(Me.Panel11)
        Me.Panel_Form1.Controls.Add(Me.Panel10)
        Me.Panel_Form1.Controls.Add(Me.Panel2)
        Me.Panel_Form1.Controls.Add(Me.Btn_Save)
        Me.Panel_Form1.Location = New System.Drawing.Point(290, 100)
        Me.Panel_Form1.Name = "Panel_Form1"
        Me.Panel_Form1.Size = New System.Drawing.Size(990, 677)
        Me.Panel_Form1.TabIndex = 69
        '
        'Chart1
        '
        ChartArea1.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea1)
        Legend1.Name = "Legend1"
        Me.Chart1.Legends.Add(Legend1)
        Me.Chart1.Location = New System.Drawing.Point(240, 314)
        Me.Chart1.Name = "Chart1"
        Series1.ChartArea = "ChartArea1"
        Series1.Legend = "Legend1"
        Series1.Name = "Series1"
        Me.Chart1.Series.Add(Series1)
        Me.Chart1.Size = New System.Drawing.Size(688, 295)
        Me.Chart1.TabIndex = 76
        Me.Chart1.Text = "Chart1"
        '
        'Panel35
        '
        Me.Panel35.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel35.Controls.Add(Me.Label14)
        Me.Panel35.Controls.Add(Me.Label17)
        Me.Panel35.Controls.Add(Me.Panel9)
        Me.Panel35.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel35.ForeColor = System.Drawing.Color.White
        Me.Panel35.Location = New System.Drawing.Point(825, 135)
        Me.Panel35.Name = "Panel35"
        Me.Panel35.Size = New System.Drawing.Size(103, 175)
        Me.Panel35.TabIndex = 75
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(8, 141)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(86, 21)
        Me.Label14.TabIndex = 18
        Me.Label14.Text = "Revenue"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(20, 114)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(62, 21)
        Me.Label17.TabIndex = 17
        Me.Label17.Text = "Gross"
        '
        'Panel34
        '
        Me.Panel34.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel34.Controls.Add(Me.Label13)
        Me.Panel34.Controls.Add(Me.Panel8)
        Me.Panel34.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel34.ForeColor = System.Drawing.Color.White
        Me.Panel34.Location = New System.Drawing.Point(641, 135)
        Me.Panel34.Name = "Panel34"
        Me.Panel34.Size = New System.Drawing.Size(180, 175)
        Me.Panel34.TabIndex = 74
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(48, 126)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(86, 21)
        Me.Label13.TabIndex = 14
        Me.Label13.Text = "Quantity"
        '
        'Panel33
        '
        Me.Panel33.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel33.Controls.Add(Me.Label9)
        Me.Panel33.Controls.Add(Me.Label10)
        Me.Panel33.Controls.Add(Me.Panel7)
        Me.Panel33.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel33.ForeColor = System.Drawing.Color.White
        Me.Panel33.Location = New System.Drawing.Point(532, 135)
        Me.Panel33.Name = "Panel33"
        Me.Panel33.Size = New System.Drawing.Size(103, 175)
        Me.Panel33.TabIndex = 73
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(8, 143)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(86, 21)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Revenue"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(20, 116)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(62, 21)
        Me.Label10.TabIndex = 15
        Me.Label10.Text = "Gross"
        '
        'Panel32
        '
        Me.Panel32.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel32.Controls.Add(Me.Label11)
        Me.Panel32.Controls.Add(Me.Panel5)
        Me.Panel32.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel32.ForeColor = System.Drawing.Color.White
        Me.Panel32.Location = New System.Drawing.Point(349, 135)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(180, 175)
        Me.Panel32.TabIndex = 72
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(47, 126)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(86, 21)
        Me.Label11.TabIndex = 13
        Me.Label11.Text = "Quantity"
        '
        'Panel31
        '
        Me.Panel31.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel31.Controls.Add(Me.Label8)
        Me.Panel31.Controls.Add(Me.Label5)
        Me.Panel31.Controls.Add(Me.Panel6)
        Me.Panel31.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel31.ForeColor = System.Drawing.Color.White
        Me.Panel31.Location = New System.Drawing.Point(240, 135)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(103, 175)
        Me.Panel31.TabIndex = 71
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(8, 140)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(86, 21)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Revenue"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(20, 113)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 21)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Gross"
        '
        'Panel30
        '
        Me.Panel30.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel30.Controls.Add(Me.Label4)
        Me.Panel30.Controls.Add(Me.Panel4)
        Me.Panel30.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel30.ForeColor = System.Drawing.Color.White
        Me.Panel30.Location = New System.Drawing.Point(56, 135)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(178, 175)
        Me.Panel30.TabIndex = 70
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(47, 126)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 21)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Quantity"
        '
        'Btn_Edit
        '
        Me.Btn_Edit.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Edit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Edit.FlatAppearance.BorderSize = 0
        Me.Btn_Edit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Edit.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Edit.ForeColor = System.Drawing.Color.White
        Me.Btn_Edit.Location = New System.Drawing.Point(412, 615)
        Me.Btn_Edit.Name = "Btn_Edit"
        Me.Btn_Edit.Size = New System.Drawing.Size(165, 49)
        Me.Btn_Edit.TabIndex = 3
        Me.Btn_Edit.Text = "EDIT"
        Me.Btn_Edit.UseVisualStyleBackColor = False
        '
        'Btn_AddGallon
        '
        Me.Btn_AddGallon.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_AddGallon.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_AddGallon.FlatAppearance.BorderSize = 0
        Me.Btn_AddGallon.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_AddGallon.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_AddGallon.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_AddGallon.ForeColor = System.Drawing.Color.White
        Me.Btn_AddGallon.Location = New System.Drawing.Point(499, 615)
        Me.Btn_AddGallon.Name = "Btn_AddGallon"
        Me.Btn_AddGallon.Size = New System.Drawing.Size(165, 49)
        Me.Btn_AddGallon.TabIndex = 69
        Me.Btn_AddGallon.Text = "ADD GALLON"
        Me.Btn_AddGallon.UseVisualStyleBackColor = False
        Me.Btn_AddGallon.Visible = False
        '
        'Panel_Form2
        '
        Me.Panel_Form2.Controls.Add(Me.Label20)
        Me.Panel_Form2.Controls.Add(Me.Label49)
        Me.Panel_Form2.Controls.Add(Me.Label56)
        Me.Panel_Form2.Controls.Add(Me.Cb_Year1)
        Me.Panel_Form2.Controls.Add(Me.Cb_Month1)
        Me.Panel_Form2.Controls.Add(Me.Chart2)
        Me.Panel_Form2.Controls.Add(Me.Panel48)
        Me.Panel_Form2.Controls.Add(Me.Panel47)
        Me.Panel_Form2.Controls.Add(Me.Panel46)
        Me.Panel_Form2.Controls.Add(Me.Panel45)
        Me.Panel_Form2.Controls.Add(Me.Panel44)
        Me.Panel_Form2.Controls.Add(Me.Panel43)
        Me.Panel_Form2.Controls.Add(Me.Panel42)
        Me.Panel_Form2.Controls.Add(Me.Panel41)
        Me.Panel_Form2.Controls.Add(Me.Panel40)
        Me.Panel_Form2.Controls.Add(Me.Panel39)
        Me.Panel_Form2.Controls.Add(Me.Panel38)
        Me.Panel_Form2.Controls.Add(Me.Panel37)
        Me.Panel_Form2.Controls.Add(Me.Btn_Change)
        Me.Panel_Form2.Controls.Add(Me.Panel27)
        Me.Panel_Form2.Controls.Add(Me.Panel24)
        Me.Panel_Form2.Controls.Add(Me.Panel21)
        Me.Panel_Form2.Controls.Add(Me.Panel12)
        Me.Panel_Form2.Controls.Add(Me.Panel13)
        Me.Panel_Form2.Controls.Add(Me.Panel14)
        Me.Panel_Form2.Controls.Add(Me.Btn_EditPrice1)
        Me.Panel_Form2.Controls.Add(Me.Btn_Save1)
        Me.Panel_Form2.Location = New System.Drawing.Point(290, 100)
        Me.Panel_Form2.Name = "Panel_Form2"
        Me.Panel_Form2.Size = New System.Drawing.Size(990, 677)
        Me.Panel_Form2.TabIndex = 70
        '
        'Chart2
        '
        ChartArea2.Name = "ChartArea1"
        Me.Chart2.ChartAreas.Add(ChartArea2)
        Legend2.Name = "Legend1"
        Me.Chart2.Legends.Add(Legend2)
        Me.Chart2.Location = New System.Drawing.Point(185, 390)
        Me.Chart2.Name = "Chart2"
        Series2.ChartArea = "ChartArea1"
        Series2.Legend = "Legend1"
        Series2.Name = "Series1"
        Me.Chart2.Series.Add(Series2)
        Me.Chart2.Size = New System.Drawing.Size(797, 229)
        Me.Chart2.TabIndex = 100
        Me.Chart2.Text = "Chart2"
        '
        'Panel48
        '
        Me.Panel48.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel48.Controls.Add(Me.Label46)
        Me.Panel48.Controls.Add(Me.Label47)
        Me.Panel48.Controls.Add(Me.Label48)
        Me.Panel48.Controls.Add(Me.Panel29)
        Me.Panel48.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel48.ForeColor = System.Drawing.Color.White
        Me.Panel48.Location = New System.Drawing.Point(825, 264)
        Me.Panel48.Name = "Panel48"
        Me.Panel48.Size = New System.Drawing.Size(157, 120)
        Me.Panel48.TabIndex = 99
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(35, 92)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(86, 21)
        Me.Label46.TabIndex = 75
        Me.Label46.Text = "Revenue"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(47, 65)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(62, 21)
        Me.Label47.TabIndex = 74
        Me.Label47.Text = "Gross"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(41, 101)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(0, 21)
        Me.Label48.TabIndex = 3
        '
        'Panel29
        '
        Me.Panel29.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel29.Controls.Add(Me.Label55)
        Me.Panel29.Controls.Add(Me.Lbl_SmallContainerIncome)
        Me.Panel29.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel29.ForeColor = System.Drawing.Color.White
        Me.Panel29.Location = New System.Drawing.Point(1, 3)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(154, 56)
        Me.Panel29.TabIndex = 87
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(41, 94)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(0, 21)
        Me.Label55.TabIndex = 5
        '
        'Lbl_SmallContainerIncome
        '
        Me.Lbl_SmallContainerIncome.AutoSize = True
        Me.Lbl_SmallContainerIncome.Font = New System.Drawing.Font("Rockwell", 16.2!)
        Me.Lbl_SmallContainerIncome.Location = New System.Drawing.Point(63, 13)
        Me.Lbl_SmallContainerIncome.Name = "Lbl_SmallContainerIncome"
        Me.Lbl_SmallContainerIncome.Size = New System.Drawing.Size(29, 31)
        Me.Lbl_SmallContainerIncome.TabIndex = 4
        Me.Lbl_SmallContainerIncome.Text = "0"
        '
        'Panel47
        '
        Me.Panel47.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel47.Controls.Add(Me.Label45)
        Me.Panel47.Controls.Add(Me.Panel28)
        Me.Panel47.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel47.ForeColor = System.Drawing.Color.White
        Me.Panel47.Location = New System.Drawing.Point(825, 135)
        Me.Panel47.Name = "Panel47"
        Me.Panel47.Size = New System.Drawing.Size(157, 123)
        Me.Panel47.TabIndex = 98
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Rockwell", 12.0!)
        Me.Label45.Location = New System.Drawing.Point(34, 95)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(88, 22)
        Me.Label45.TabIndex = 71
        Me.Label45.Text = "Quantity"
        '
        'Panel28
        '
        Me.Panel28.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel28.Controls.Add(Me.Lbl_SmallContainerSold)
        Me.Panel28.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel28.ForeColor = System.Drawing.Color.White
        Me.Panel28.Location = New System.Drawing.Point(7, 3)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(143, 85)
        Me.Panel28.TabIndex = 86
        '
        'Lbl_SmallContainerSold
        '
        Me.Lbl_SmallContainerSold.AutoSize = True
        Me.Lbl_SmallContainerSold.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_SmallContainerSold.Location = New System.Drawing.Point(40, 8)
        Me.Lbl_SmallContainerSold.Name = "Lbl_SmallContainerSold"
        Me.Lbl_SmallContainerSold.Size = New System.Drawing.Size(62, 68)
        Me.Lbl_SmallContainerSold.TabIndex = 2
        Me.Lbl_SmallContainerSold.Text = "0"
        Me.Lbl_SmallContainerSold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel46
        '
        Me.Panel46.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel46.Controls.Add(Me.Label41)
        Me.Panel46.Controls.Add(Me.Label42)
        Me.Panel46.Controls.Add(Me.Label44)
        Me.Panel46.Controls.Add(Me.Panel15)
        Me.Panel46.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel46.ForeColor = System.Drawing.Color.White
        Me.Panel46.Location = New System.Drawing.Point(662, 264)
        Me.Panel46.Name = "Panel46"
        Me.Panel46.Size = New System.Drawing.Size(157, 120)
        Me.Panel46.TabIndex = 97
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(35, 92)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(86, 21)
        Me.Label41.TabIndex = 75
        Me.Label41.Text = "Revenue"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(47, 65)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(62, 21)
        Me.Label42.TabIndex = 74
        Me.Label42.Text = "Gross"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(41, 101)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(0, 21)
        Me.Label44.TabIndex = 3
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel15.Controls.Add(Me.Label54)
        Me.Panel15.Controls.Add(Me.Lbl_ContainerIncome1)
        Me.Panel15.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel15.ForeColor = System.Drawing.Color.White
        Me.Panel15.Location = New System.Drawing.Point(1, 3)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(154, 56)
        Me.Panel15.TabIndex = 75
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(41, 94)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(0, 21)
        Me.Label54.TabIndex = 5
        '
        'Lbl_ContainerIncome1
        '
        Me.Lbl_ContainerIncome1.AutoSize = True
        Me.Lbl_ContainerIncome1.Font = New System.Drawing.Font("Rockwell", 16.2!)
        Me.Lbl_ContainerIncome1.Location = New System.Drawing.Point(63, 13)
        Me.Lbl_ContainerIncome1.Name = "Lbl_ContainerIncome1"
        Me.Lbl_ContainerIncome1.Size = New System.Drawing.Size(29, 31)
        Me.Lbl_ContainerIncome1.TabIndex = 4
        Me.Lbl_ContainerIncome1.Text = "0"
        '
        'Panel45
        '
        Me.Panel45.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel45.Controls.Add(Me.Label40)
        Me.Panel45.Controls.Add(Me.Panel16)
        Me.Panel45.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel45.ForeColor = System.Drawing.Color.White
        Me.Panel45.Location = New System.Drawing.Point(662, 135)
        Me.Panel45.Name = "Panel45"
        Me.Panel45.Size = New System.Drawing.Size(157, 123)
        Me.Panel45.TabIndex = 96
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Rockwell", 12.0!)
        Me.Label40.Location = New System.Drawing.Point(34, 95)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(88, 22)
        Me.Label40.TabIndex = 71
        Me.Label40.Text = "Quantity"
        '
        'Panel16
        '
        Me.Panel16.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel16.Controls.Add(Me.Lbl_ContainerSold1)
        Me.Panel16.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel16.ForeColor = System.Drawing.Color.White
        Me.Panel16.Location = New System.Drawing.Point(7, 3)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(143, 85)
        Me.Panel16.TabIndex = 72
        '
        'Lbl_ContainerSold1
        '
        Me.Lbl_ContainerSold1.AutoSize = True
        Me.Lbl_ContainerSold1.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_ContainerSold1.Location = New System.Drawing.Point(40, 8)
        Me.Lbl_ContainerSold1.Name = "Lbl_ContainerSold1"
        Me.Lbl_ContainerSold1.Size = New System.Drawing.Size(62, 68)
        Me.Lbl_ContainerSold1.TabIndex = 2
        Me.Lbl_ContainerSold1.Text = "0"
        Me.Lbl_ContainerSold1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel44
        '
        Me.Panel44.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel44.Controls.Add(Me.Label37)
        Me.Panel44.Controls.Add(Me.Label38)
        Me.Panel44.Controls.Add(Me.Label39)
        Me.Panel44.Controls.Add(Me.Panel26)
        Me.Panel44.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel44.ForeColor = System.Drawing.Color.White
        Me.Panel44.Location = New System.Drawing.Point(499, 264)
        Me.Panel44.Name = "Panel44"
        Me.Panel44.Size = New System.Drawing.Size(157, 120)
        Me.Panel44.TabIndex = 95
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(35, 92)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(86, 21)
        Me.Label37.TabIndex = 75
        Me.Label37.Text = "Revenue"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(47, 65)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(62, 21)
        Me.Label38.TabIndex = 74
        Me.Label38.Text = "Gross"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(41, 101)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(0, 21)
        Me.Label39.TabIndex = 3
        '
        'Panel26
        '
        Me.Panel26.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel26.Controls.Add(Me.Lbl_SmallContainerwithWaterIncome)
        Me.Panel26.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel26.ForeColor = System.Drawing.Color.White
        Me.Panel26.Location = New System.Drawing.Point(1, 3)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(154, 56)
        Me.Panel26.TabIndex = 84
        '
        'Lbl_SmallContainerwithWaterIncome
        '
        Me.Lbl_SmallContainerwithWaterIncome.AutoSize = True
        Me.Lbl_SmallContainerwithWaterIncome.Font = New System.Drawing.Font("Rockwell", 16.2!)
        Me.Lbl_SmallContainerwithWaterIncome.Location = New System.Drawing.Point(63, 13)
        Me.Lbl_SmallContainerwithWaterIncome.Name = "Lbl_SmallContainerwithWaterIncome"
        Me.Lbl_SmallContainerwithWaterIncome.Size = New System.Drawing.Size(29, 31)
        Me.Lbl_SmallContainerwithWaterIncome.TabIndex = 3
        Me.Lbl_SmallContainerwithWaterIncome.Text = "0"
        '
        'Panel43
        '
        Me.Panel43.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel43.Controls.Add(Me.Label34)
        Me.Panel43.Controls.Add(Me.Panel25)
        Me.Panel43.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel43.ForeColor = System.Drawing.Color.White
        Me.Panel43.Location = New System.Drawing.Point(499, 135)
        Me.Panel43.Name = "Panel43"
        Me.Panel43.Size = New System.Drawing.Size(157, 123)
        Me.Panel43.TabIndex = 94
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Rockwell", 12.0!)
        Me.Label34.Location = New System.Drawing.Point(34, 95)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(88, 22)
        Me.Label34.TabIndex = 71
        Me.Label34.Text = "Quantity"
        '
        'Panel25
        '
        Me.Panel25.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel25.Controls.Add(Me.Lbl_SmallContainerwithWaterSold)
        Me.Panel25.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel25.ForeColor = System.Drawing.Color.White
        Me.Panel25.Location = New System.Drawing.Point(7, 3)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(143, 85)
        Me.Panel25.TabIndex = 83
        '
        'Lbl_SmallContainerwithWaterSold
        '
        Me.Lbl_SmallContainerwithWaterSold.AutoSize = True
        Me.Lbl_SmallContainerwithWaterSold.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_SmallContainerwithWaterSold.Location = New System.Drawing.Point(40, 8)
        Me.Lbl_SmallContainerwithWaterSold.Name = "Lbl_SmallContainerwithWaterSold"
        Me.Lbl_SmallContainerwithWaterSold.Size = New System.Drawing.Size(62, 68)
        Me.Lbl_SmallContainerwithWaterSold.TabIndex = 2
        Me.Lbl_SmallContainerwithWaterSold.Text = "0"
        Me.Lbl_SmallContainerwithWaterSold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel42
        '
        Me.Panel42.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel42.Controls.Add(Me.Label27)
        Me.Panel42.Controls.Add(Me.Label28)
        Me.Panel42.Controls.Add(Me.Label29)
        Me.Panel42.Controls.Add(Me.Panel17)
        Me.Panel42.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel42.ForeColor = System.Drawing.Color.White
        Me.Panel42.Location = New System.Drawing.Point(334, 264)
        Me.Panel42.Name = "Panel42"
        Me.Panel42.Size = New System.Drawing.Size(157, 120)
        Me.Panel42.TabIndex = 93
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(35, 92)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(86, 21)
        Me.Label27.TabIndex = 75
        Me.Label27.Text = "Revenue"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(47, 65)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(62, 21)
        Me.Label28.TabIndex = 74
        Me.Label28.Text = "Gross"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(41, 101)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(0, 21)
        Me.Label29.TabIndex = 3
        '
        'Panel17
        '
        Me.Panel17.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel17.Controls.Add(Me.Lbl_ContainerWaterIncome1)
        Me.Panel17.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel17.ForeColor = System.Drawing.Color.White
        Me.Panel17.Location = New System.Drawing.Point(1, 3)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(154, 56)
        Me.Panel17.TabIndex = 74
        '
        'Lbl_ContainerWaterIncome1
        '
        Me.Lbl_ContainerWaterIncome1.AutoSize = True
        Me.Lbl_ContainerWaterIncome1.Font = New System.Drawing.Font("Rockwell", 16.2!)
        Me.Lbl_ContainerWaterIncome1.Location = New System.Drawing.Point(63, 13)
        Me.Lbl_ContainerWaterIncome1.Name = "Lbl_ContainerWaterIncome1"
        Me.Lbl_ContainerWaterIncome1.Size = New System.Drawing.Size(29, 31)
        Me.Lbl_ContainerWaterIncome1.TabIndex = 3
        Me.Lbl_ContainerWaterIncome1.Text = "0"
        '
        'Panel41
        '
        Me.Panel41.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel41.Controls.Add(Me.Label26)
        Me.Panel41.Controls.Add(Me.Panel19)
        Me.Panel41.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel41.ForeColor = System.Drawing.Color.White
        Me.Panel41.Location = New System.Drawing.Point(334, 135)
        Me.Panel41.Name = "Panel41"
        Me.Panel41.Size = New System.Drawing.Size(157, 123)
        Me.Panel41.TabIndex = 92
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Rockwell", 12.0!)
        Me.Label26.Location = New System.Drawing.Point(34, 95)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(88, 22)
        Me.Label26.TabIndex = 71
        Me.Label26.Text = "Quantity"
        '
        'Panel19
        '
        Me.Panel19.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel19.Controls.Add(Me.Lbl_ContainerWaterSold1)
        Me.Panel19.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel19.ForeColor = System.Drawing.Color.White
        Me.Panel19.Location = New System.Drawing.Point(7, 3)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(143, 85)
        Me.Panel19.TabIndex = 71
        '
        'Lbl_ContainerWaterSold1
        '
        Me.Lbl_ContainerWaterSold1.AutoSize = True
        Me.Lbl_ContainerWaterSold1.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_ContainerWaterSold1.Location = New System.Drawing.Point(40, 8)
        Me.Lbl_ContainerWaterSold1.Name = "Lbl_ContainerWaterSold1"
        Me.Lbl_ContainerWaterSold1.Size = New System.Drawing.Size(62, 68)
        Me.Lbl_ContainerWaterSold1.TabIndex = 2
        Me.Lbl_ContainerWaterSold1.Text = "0"
        Me.Lbl_ContainerWaterSold1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel40
        '
        Me.Panel40.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel40.Controls.Add(Me.Label23)
        Me.Panel40.Controls.Add(Me.Label24)
        Me.Panel40.Controls.Add(Me.Label25)
        Me.Panel40.Controls.Add(Me.Panel23)
        Me.Panel40.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel40.ForeColor = System.Drawing.Color.White
        Me.Panel40.Location = New System.Drawing.Point(170, 264)
        Me.Panel40.Name = "Panel40"
        Me.Panel40.Size = New System.Drawing.Size(157, 120)
        Me.Panel40.TabIndex = 91
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(35, 92)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(86, 21)
        Me.Label23.TabIndex = 75
        Me.Label23.Text = "Revenue"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(47, 65)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(62, 21)
        Me.Label24.TabIndex = 74
        Me.Label24.Text = "Gross"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(41, 101)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(0, 21)
        Me.Label25.TabIndex = 3
        '
        'Panel23
        '
        Me.Panel23.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel23.Controls.Add(Me.Lbl_SmallRefillIncome)
        Me.Panel23.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel23.ForeColor = System.Drawing.Color.White
        Me.Panel23.Location = New System.Drawing.Point(1, 3)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(154, 56)
        Me.Panel23.TabIndex = 81
        '
        'Lbl_SmallRefillIncome
        '
        Me.Lbl_SmallRefillIncome.AutoSize = True
        Me.Lbl_SmallRefillIncome.Font = New System.Drawing.Font("Rockwell", 16.2!)
        Me.Lbl_SmallRefillIncome.Location = New System.Drawing.Point(63, 13)
        Me.Lbl_SmallRefillIncome.Name = "Lbl_SmallRefillIncome"
        Me.Lbl_SmallRefillIncome.Size = New System.Drawing.Size(29, 31)
        Me.Lbl_SmallRefillIncome.TabIndex = 2
        Me.Lbl_SmallRefillIncome.Text = "0"
        '
        'Panel39
        '
        Me.Panel39.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel39.Controls.Add(Me.Label22)
        Me.Panel39.Controls.Add(Me.Panel22)
        Me.Panel39.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel39.ForeColor = System.Drawing.Color.White
        Me.Panel39.Location = New System.Drawing.Point(170, 135)
        Me.Panel39.Name = "Panel39"
        Me.Panel39.Size = New System.Drawing.Size(157, 123)
        Me.Panel39.TabIndex = 90
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Rockwell", 12.0!)
        Me.Label22.Location = New System.Drawing.Point(34, 95)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(88, 22)
        Me.Label22.TabIndex = 71
        Me.Label22.Text = "Quantity"
        '
        'Panel22
        '
        Me.Panel22.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel22.Controls.Add(Me.Lbl_SmallRefillSold)
        Me.Panel22.Location = New System.Drawing.Point(7, 3)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(143, 85)
        Me.Panel22.TabIndex = 80
        '
        'Lbl_SmallRefillSold
        '
        Me.Lbl_SmallRefillSold.AutoSize = True
        Me.Lbl_SmallRefillSold.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_SmallRefillSold.ForeColor = System.Drawing.Color.White
        Me.Lbl_SmallRefillSold.Location = New System.Drawing.Point(40, 8)
        Me.Lbl_SmallRefillSold.Name = "Lbl_SmallRefillSold"
        Me.Lbl_SmallRefillSold.Size = New System.Drawing.Size(62, 68)
        Me.Lbl_SmallRefillSold.TabIndex = 9
        Me.Lbl_SmallRefillSold.Text = "0"
        Me.Lbl_SmallRefillSold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel38
        '
        Me.Panel38.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel38.Controls.Add(Me.Label18)
        Me.Panel38.Controls.Add(Me.Label21)
        Me.Panel38.Controls.Add(Me.Label15)
        Me.Panel38.Controls.Add(Me.Panel18)
        Me.Panel38.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel38.ForeColor = System.Drawing.Color.White
        Me.Panel38.Location = New System.Drawing.Point(5, 264)
        Me.Panel38.Name = "Panel38"
        Me.Panel38.Size = New System.Drawing.Size(157, 120)
        Me.Panel38.TabIndex = 89
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(35, 92)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(86, 21)
        Me.Label18.TabIndex = 75
        Me.Label18.Text = "Revenue"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(47, 65)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(62, 21)
        Me.Label21.TabIndex = 74
        Me.Label21.Text = "Gross"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(41, 101)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(0, 21)
        Me.Label15.TabIndex = 3
        '
        'Panel18
        '
        Me.Panel18.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel18.Controls.Add(Me.Label33)
        Me.Panel18.Controls.Add(Me.Lbl_WaterRefillIncome1)
        Me.Panel18.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel18.ForeColor = System.Drawing.Color.White
        Me.Panel18.Location = New System.Drawing.Point(1, 3)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(154, 56)
        Me.Panel18.TabIndex = 73
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(41, 101)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(0, 21)
        Me.Label33.TabIndex = 3
        '
        'Lbl_WaterRefillIncome1
        '
        Me.Lbl_WaterRefillIncome1.AutoSize = True
        Me.Lbl_WaterRefillIncome1.Font = New System.Drawing.Font("Rockwell", 16.2!)
        Me.Lbl_WaterRefillIncome1.Location = New System.Drawing.Point(64, 11)
        Me.Lbl_WaterRefillIncome1.Name = "Lbl_WaterRefillIncome1"
        Me.Lbl_WaterRefillIncome1.Size = New System.Drawing.Size(29, 31)
        Me.Lbl_WaterRefillIncome1.TabIndex = 2
        Me.Lbl_WaterRefillIncome1.Text = "0"
        '
        'Panel37
        '
        Me.Panel37.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel37.Controls.Add(Me.Label12)
        Me.Panel37.Controls.Add(Me.Panel20)
        Me.Panel37.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel37.ForeColor = System.Drawing.Color.White
        Me.Panel37.Location = New System.Drawing.Point(5, 135)
        Me.Panel37.Name = "Panel37"
        Me.Panel37.Size = New System.Drawing.Size(157, 123)
        Me.Panel37.TabIndex = 88
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(34, 95)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(88, 22)
        Me.Label12.TabIndex = 71
        Me.Label12.Text = "Quantity"
        '
        'Panel20
        '
        Me.Panel20.BackColor = System.Drawing.Color.Transparent
        Me.Panel20.Controls.Add(Me.Lbl_WaterRefillSold1)
        Me.Panel20.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel20.ForeColor = System.Drawing.Color.White
        Me.Panel20.Location = New System.Drawing.Point(7, 3)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(143, 85)
        Me.Panel20.TabIndex = 70
        '
        'Lbl_WaterRefillSold1
        '
        Me.Lbl_WaterRefillSold1.AutoSize = True
        Me.Lbl_WaterRefillSold1.Font = New System.Drawing.Font("Rockwell", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_WaterRefillSold1.Location = New System.Drawing.Point(40, 8)
        Me.Lbl_WaterRefillSold1.Name = "Lbl_WaterRefillSold1"
        Me.Lbl_WaterRefillSold1.Size = New System.Drawing.Size(62, 68)
        Me.Lbl_WaterRefillSold1.TabIndex = 1
        Me.Lbl_WaterRefillSold1.Text = "0"
        Me.Lbl_WaterRefillSold1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Btn_Change
        '
        Me.Btn_Change.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Change.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Change.FlatAppearance.BorderSize = 0
        Me.Btn_Change.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Change.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Change.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Change.ForeColor = System.Drawing.Color.White
        Me.Btn_Change.Location = New System.Drawing.Point(499, 625)
        Me.Btn_Change.Name = "Btn_Change"
        Me.Btn_Change.Size = New System.Drawing.Size(165, 49)
        Me.Btn_Change.TabIndex = 8
        Me.Btn_Change.Text = "CHANGE"
        Me.Btn_Change.UseVisualStyleBackColor = False
        '
        'Panel27
        '
        Me.Panel27.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel27.Controls.Add(Me.Label50)
        Me.Panel27.Controls.Add(Me.Txt_PriceSmallContainer)
        Me.Panel27.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel27.ForeColor = System.Drawing.Color.White
        Me.Panel27.Location = New System.Drawing.Point(825, 7)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(157, 122)
        Me.Panel27.TabIndex = 85
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label50.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.White
        Me.Label50.Location = New System.Drawing.Point(11, 32)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(135, 20)
        Me.Label50.TabIndex = 17
        Me.Label50.Text = "Small Container"
        '
        'Txt_PriceSmallContainer
        '
        Me.Txt_PriceSmallContainer.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceSmallContainer.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceSmallContainer.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceSmallContainer.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceSmallContainer.Location = New System.Drawing.Point(37, 83)
        Me.Txt_PriceSmallContainer.Name = "Txt_PriceSmallContainer"
        Me.Txt_PriceSmallContainer.ReadOnly = True
        Me.Txt_PriceSmallContainer.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceSmallContainer.TabIndex = 5
        Me.Txt_PriceSmallContainer.Text = "0"
        Me.Txt_PriceSmallContainer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel24
        '
        Me.Panel24.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel24.Controls.Add(Me.Label36)
        Me.Panel24.Controls.Add(Me.Label43)
        Me.Panel24.Controls.Add(Me.Txt_PriceSmallContainerWater)
        Me.Panel24.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel24.ForeColor = System.Drawing.Color.White
        Me.Panel24.Location = New System.Drawing.Point(499, 7)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(157, 122)
        Me.Panel24.TabIndex = 82
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(25, 43)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(107, 21)
        Me.Label36.TabIndex = 18
        Me.Label36.Text = "with Water"
        '
        'Label43
        '
        Me.Label43.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label43.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.White
        Me.Label43.Location = New System.Drawing.Point(10, 11)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(136, 40)
        Me.Label43.TabIndex = 17
        Me.Label43.Text = "Small Container"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_PriceSmallContainerWater
        '
        Me.Txt_PriceSmallContainerWater.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceSmallContainerWater.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceSmallContainerWater.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceSmallContainerWater.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceSmallContainerWater.Location = New System.Drawing.Point(37, 83)
        Me.Txt_PriceSmallContainerWater.Name = "Txt_PriceSmallContainerWater"
        Me.Txt_PriceSmallContainerWater.ReadOnly = True
        Me.Txt_PriceSmallContainerWater.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceSmallContainerWater.TabIndex = 3
        Me.Txt_PriceSmallContainerWater.Text = "0"
        Me.Txt_PriceSmallContainerWater.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel21
        '
        Me.Panel21.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel21.Controls.Add(Me.Label31)
        Me.Panel21.Controls.Add(Me.Txt_PriceSmallGallon)
        Me.Panel21.Controls.Add(Me.Label32)
        Me.Panel21.Location = New System.Drawing.Point(170, 7)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(157, 122)
        Me.Panel21.TabIndex = 79
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Rockwell", 10.8!)
        Me.Label31.ForeColor = System.Drawing.Color.White
        Me.Label31.Location = New System.Drawing.Point(11, 43)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(128, 21)
        Me.Label31.TabIndex = 21
        Me.Label31.Text = "Water Gallon"
        '
        'Txt_PriceSmallGallon
        '
        Me.Txt_PriceSmallGallon.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceSmallGallon.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceSmallGallon.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceSmallGallon.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceSmallGallon.Location = New System.Drawing.Point(37, 83)
        Me.Txt_PriceSmallGallon.Name = "Txt_PriceSmallGallon"
        Me.Txt_PriceSmallGallon.ReadOnly = True
        Me.Txt_PriceSmallGallon.Size = New System.Drawing.Size(82, 27)
        Me.Txt_PriceSmallGallon.TabIndex = 1
        Me.Txt_PriceSmallGallon.Text = "0"
        Me.Txt_PriceSmallGallon.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label32.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.White
        Me.Label32.Location = New System.Drawing.Point(45, 15)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(61, 22)
        Me.Label32.TabIndex = 20
        Me.Label32.Text = "Small"
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel12.Controls.Add(Me.Label3)
        Me.Panel12.Controls.Add(Me.Txt_PriceContainer1)
        Me.Panel12.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel12.ForeColor = System.Drawing.Color.White
        Me.Panel12.Location = New System.Drawing.Point(662, 7)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(157, 122)
        Me.Panel12.TabIndex = 78
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label3.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(27, 32)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 22)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Container"
        '
        'Txt_PriceContainer1
        '
        Me.Txt_PriceContainer1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceContainer1.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceContainer1.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceContainer1.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceContainer1.Location = New System.Drawing.Point(37, 83)
        Me.Txt_PriceContainer1.Name = "Txt_PriceContainer1"
        Me.Txt_PriceContainer1.ReadOnly = True
        Me.Txt_PriceContainer1.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceContainer1.TabIndex = 4
        Me.Txt_PriceContainer1.Text = "0"
        Me.Txt_PriceContainer1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel13.Controls.Add(Me.Label35)
        Me.Panel13.Controls.Add(Me.Label6)
        Me.Panel13.Controls.Add(Me.Txt_PriceContainerWater1)
        Me.Panel13.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel13.ForeColor = System.Drawing.Color.White
        Me.Panel13.Location = New System.Drawing.Point(334, 7)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(157, 122)
        Me.Panel13.TabIndex = 77
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(23, 45)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(107, 21)
        Me.Label35.TabIndex = 18
        Me.Label35.Text = "with Water"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label6.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(3, 10)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(151, 40)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "Container"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_PriceContainerWater1
        '
        Me.Txt_PriceContainerWater1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceContainerWater1.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceContainerWater1.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceContainerWater1.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceContainerWater1.Location = New System.Drawing.Point(37, 83)
        Me.Txt_PriceContainerWater1.Name = "Txt_PriceContainerWater1"
        Me.Txt_PriceContainerWater1.ReadOnly = True
        Me.Txt_PriceContainerWater1.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceContainerWater1.TabIndex = 2
        Me.Txt_PriceContainerWater1.Text = "0"
        Me.Txt_PriceContainerWater1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel14
        '
        Me.Panel14.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel14.Controls.Add(Me.Label30)
        Me.Panel14.Controls.Add(Me.Label7)
        Me.Panel14.Controls.Add(Me.Txt_PriceGallon1)
        Me.Panel14.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel14.ForeColor = System.Drawing.Color.White
        Me.Panel14.Location = New System.Drawing.Point(5, 7)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(157, 122)
        Me.Panel14.TabIndex = 76
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(36, 45)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(81, 21)
        Me.Label30.TabIndex = 18
        Me.Label30.Text = "Gallon's"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label7.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(45, 17)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(66, 22)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Water"
        '
        'Txt_PriceGallon1
        '
        Me.Txt_PriceGallon1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceGallon1.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceGallon1.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceGallon1.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceGallon1.Location = New System.Drawing.Point(37, 83)
        Me.Txt_PriceGallon1.Name = "Txt_PriceGallon1"
        Me.Txt_PriceGallon1.ReadOnly = True
        Me.Txt_PriceGallon1.Size = New System.Drawing.Size(82, 27)
        Me.Txt_PriceGallon1.TabIndex = 0
        Me.Txt_PriceGallon1.Text = "0"
        Me.Txt_PriceGallon1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Btn_EditPrice1
        '
        Me.Btn_EditPrice1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_EditPrice1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_EditPrice1.FlatAppearance.BorderSize = 0
        Me.Btn_EditPrice1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_EditPrice1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_EditPrice1.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_EditPrice1.ForeColor = System.Drawing.Color.White
        Me.Btn_EditPrice1.Location = New System.Drawing.Point(326, 625)
        Me.Btn_EditPrice1.Name = "Btn_EditPrice1"
        Me.Btn_EditPrice1.Size = New System.Drawing.Size(165, 49)
        Me.Btn_EditPrice1.TabIndex = 7
        Me.Btn_EditPrice1.Text = "EDIT PRICE"
        Me.Btn_EditPrice1.UseVisualStyleBackColor = False
        '
        'Btn_Save1
        '
        Me.Btn_Save1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Save1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Save1.FlatAppearance.BorderSize = 0
        Me.Btn_Save1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Save1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Save1.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Save1.ForeColor = System.Drawing.Color.White
        Me.Btn_Save1.Location = New System.Drawing.Point(415, 625)
        Me.Btn_Save1.Name = "Btn_Save1"
        Me.Btn_Save1.Size = New System.Drawing.Size(165, 49)
        Me.Btn_Save1.TabIndex = 6
        Me.Btn_Save1.Text = "SAVE"
        Me.Btn_Save1.UseVisualStyleBackColor = False
        Me.Btn_Save1.Visible = False
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.White
        Me.Label51.Location = New System.Drawing.Point(54, 458)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(78, 27)
        Me.Label51.TabIndex = 122
        Me.Label51.Text = "Year :"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.ForeColor = System.Drawing.Color.White
        Me.Label52.Location = New System.Drawing.Point(54, 384)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(95, 27)
        Me.Label52.TabIndex = 121
        Me.Label52.Text = "Month :"
        '
        'Cb_Year
        '
        Me.Cb_Year.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Year.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Year.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Year.FormattingEnabled = True
        Me.Cb_Year.Location = New System.Drawing.Point(59, 488)
        Me.Cb_Year.Name = "Cb_Year"
        Me.Cb_Year.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Year.TabIndex = 120
        '
        'Cb_Month
        '
        Me.Cb_Month.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Month.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Month.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Month.FormattingEnabled = True
        Me.Cb_Month.Location = New System.Drawing.Point(59, 414)
        Me.Cb_Month.Name = "Cb_Month"
        Me.Cb_Month.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Month.TabIndex = 119
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Rockwell", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.White
        Me.Label53.Location = New System.Drawing.Point(71, 326)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(128, 38)
        Me.Label53.TabIndex = 123
        Me.Label53.Text = "Sorting"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Rockwell", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.White
        Me.Label20.Location = New System.Drawing.Point(24, 400)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(128, 38)
        Me.Label20.TabIndex = 128
        Me.Label20.Text = "Sorting"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.White
        Me.Label49.Location = New System.Drawing.Point(7, 532)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(78, 27)
        Me.Label49.TabIndex = 127
        Me.Label49.Text = "Year :"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.ForeColor = System.Drawing.Color.White
        Me.Label56.Location = New System.Drawing.Point(7, 458)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(95, 27)
        Me.Label56.TabIndex = 126
        Me.Label56.Text = "Month :"
        '
        'Cb_Year1
        '
        Me.Cb_Year1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Year1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Year1.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Year1.FormattingEnabled = True
        Me.Cb_Year1.Location = New System.Drawing.Point(12, 562)
        Me.Cb_Year1.Name = "Cb_Year1"
        Me.Cb_Year1.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Year1.TabIndex = 125
        '
        'Cb_Month1
        '
        Me.Cb_Month1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Month1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Month1.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Month1.FormattingEnabled = True
        Me.Cb_Month1.Location = New System.Drawing.Point(12, 488)
        Me.Cb_Month1.Name = "Cb_Month1"
        Me.Cb_Month1.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Month1.TabIndex = 124
        '
        'Home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1292, 789)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel_Form1)
        Me.Controls.Add(Me.Panel_Form2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Home"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AU WATER REFILLING STATION"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.Panel_Form1.ResumeLayout(False)
        Me.Panel_Form1.PerformLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel35.ResumeLayout(False)
        Me.Panel35.PerformLayout()
        Me.Panel34.ResumeLayout(False)
        Me.Panel34.PerformLayout()
        Me.Panel33.ResumeLayout(False)
        Me.Panel33.PerformLayout()
        Me.Panel32.ResumeLayout(False)
        Me.Panel32.PerformLayout()
        Me.Panel31.ResumeLayout(False)
        Me.Panel31.PerformLayout()
        Me.Panel30.ResumeLayout(False)
        Me.Panel30.PerformLayout()
        Me.Panel_Form2.ResumeLayout(False)
        Me.Panel_Form2.PerformLayout()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel48.ResumeLayout(False)
        Me.Panel48.PerformLayout()
        Me.Panel29.ResumeLayout(False)
        Me.Panel29.PerformLayout()
        Me.Panel47.ResumeLayout(False)
        Me.Panel47.PerformLayout()
        Me.Panel28.ResumeLayout(False)
        Me.Panel28.PerformLayout()
        Me.Panel46.ResumeLayout(False)
        Me.Panel46.PerformLayout()
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        Me.Panel45.ResumeLayout(False)
        Me.Panel45.PerformLayout()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.Panel44.ResumeLayout(False)
        Me.Panel44.PerformLayout()
        Me.Panel26.ResumeLayout(False)
        Me.Panel26.PerformLayout()
        Me.Panel43.ResumeLayout(False)
        Me.Panel43.PerformLayout()
        Me.Panel25.ResumeLayout(False)
        Me.Panel25.PerformLayout()
        Me.Panel42.ResumeLayout(False)
        Me.Panel42.PerformLayout()
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        Me.Panel41.ResumeLayout(False)
        Me.Panel41.PerformLayout()
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout()
        Me.Panel40.ResumeLayout(False)
        Me.Panel40.PerformLayout()
        Me.Panel23.ResumeLayout(False)
        Me.Panel23.PerformLayout()
        Me.Panel39.ResumeLayout(False)
        Me.Panel39.PerformLayout()
        Me.Panel22.ResumeLayout(False)
        Me.Panel22.PerformLayout()
        Me.Panel38.ResumeLayout(False)
        Me.Panel38.PerformLayout()
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        Me.Panel37.ResumeLayout(False)
        Me.Panel37.PerformLayout()
        Me.Panel20.ResumeLayout(False)
        Me.Panel20.PerformLayout()
        Me.Panel27.ResumeLayout(False)
        Me.Panel27.PerformLayout()
        Me.Panel24.ResumeLayout(False)
        Me.Panel24.PerformLayout()
        Me.Panel21.ResumeLayout(False)
        Me.Panel21.PerformLayout()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.Panel14.ResumeLayout(False)
        Me.Panel14.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Txt_Time As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_WaterRefillSold As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_ContainerWaterSold As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_WaterRefillIncome As System.Windows.Forms.Label
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_ContainerSold As System.Windows.Forms.Label
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_ContainerWaterIncome As System.Windows.Forms.Label
    Friend WithEvents Lbl_ContainerIncome As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Btn_Home As System.Windows.Forms.Button
    Friend WithEvents Btn_Bills As System.Windows.Forms.Button
    Friend WithEvents Btn_Calculation As System.Windows.Forms.Button
    Friend WithEvents Btn_Recycle As System.Windows.Forms.Button
    Friend WithEvents Btn_Reports As System.Windows.Forms.Button
    Friend WithEvents Btn_EmployeeInfo As System.Windows.Forms.Button
    Friend WithEvents Btn_Logout As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Btn_UserInfo As System.Windows.Forms.Button
    Friend WithEvents Txt_PriceGallon As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceContainerWater As System.Windows.Forms.TextBox
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceContainer As System.Windows.Forms.TextBox
    Friend WithEvents Btn_EditPrice As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Panel_Form1 As System.Windows.Forms.Panel
    Friend WithEvents Panel_Form2 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Save1 As System.Windows.Forms.Button
    Friend WithEvents Btn_EditPrice1 As System.Windows.Forms.Button
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceContainer1 As System.Windows.Forms.TextBox
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceContainerWater1 As System.Windows.Forms.TextBox
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceGallon1 As System.Windows.Forms.TextBox
    Friend WithEvents Panel15 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_ContainerIncome1 As System.Windows.Forms.Label
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_ContainerSold1 As System.Windows.Forms.Label
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_ContainerWaterIncome1 As System.Windows.Forms.Label
    Friend WithEvents Panel18 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_WaterRefillIncome1 As System.Windows.Forms.Label
    Friend WithEvents Panel19 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_ContainerWaterSold1 As System.Windows.Forms.Label
    Friend WithEvents Panel20 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_WaterRefillSold1 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Panel23 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_SmallRefillIncome As System.Windows.Forms.Label
    Friend WithEvents Panel22 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_SmallRefillSold As System.Windows.Forms.Label
    Friend WithEvents Panel21 As System.Windows.Forms.Panel
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceSmallGallon As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Panel24 As System.Windows.Forms.Panel
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceSmallContainerWater As System.Windows.Forms.TextBox
    Friend WithEvents Panel26 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_SmallContainerwithWaterIncome As System.Windows.Forms.Label
    Friend WithEvents Panel25 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_SmallContainerwithWaterSold As System.Windows.Forms.Label
    Friend WithEvents Panel29 As System.Windows.Forms.Panel
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Lbl_SmallContainerIncome As System.Windows.Forms.Label
    Friend WithEvents Panel28 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_SmallContainerSold As System.Windows.Forms.Label
    Friend WithEvents Panel27 As System.Windows.Forms.Panel
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceSmallContainer As System.Windows.Forms.TextBox
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Btn_AddGallon As System.Windows.Forms.Button
    Friend WithEvents Btn_Edit As System.Windows.Forms.Button
    Friend WithEvents Btn_Change As System.Windows.Forms.Button
    Friend WithEvents Panel31 As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel30 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Panel35 As System.Windows.Forms.Panel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Panel34 As System.Windows.Forms.Panel
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Panel33 As System.Windows.Forms.Panel
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Panel32 As System.Windows.Forms.Panel
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Chart1 As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents Panel40 As System.Windows.Forms.Panel
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Panel39 As System.Windows.Forms.Panel
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Panel38 As System.Windows.Forms.Panel
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Panel37 As System.Windows.Forms.Panel
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Panel42 As System.Windows.Forms.Panel
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Panel41 As System.Windows.Forms.Panel
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Panel48 As System.Windows.Forms.Panel
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Panel47 As System.Windows.Forms.Panel
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Panel46 As System.Windows.Forms.Panel
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Panel45 As System.Windows.Forms.Panel
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Panel44 As System.Windows.Forms.Panel
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Panel43 As System.Windows.Forms.Panel
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Chart2 As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Cb_Year As System.Windows.Forms.ComboBox
    Friend WithEvents Cb_Month As System.Windows.Forms.ComboBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Cb_Year1 As System.Windows.Forms.ComboBox
    Friend WithEvents Cb_Month1 As System.Windows.Forms.ComboBox
End Class
