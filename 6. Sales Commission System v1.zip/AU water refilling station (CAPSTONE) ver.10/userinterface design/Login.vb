﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class Login
    ' === Connection & State ===
    Private ReadOnly connectionString As String =
        ConfigurationManager.ConnectionStrings("MyDB").ConnectionString

    Private failedAttempts As Integer = 0
    Private currentHistoryId As Integer = 0

    ' === Form Load ===
    Private Sub Login_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Txt_Password.UseSystemPasswordChar = True

        If My.Settings.CooldownLog = Date.MinValue Then
            My.Settings.CooldownLog = #12:00:00 AM#
            My.Settings.Save()
        End If
    End Sub

    ' === LOGIN BUTTON ===
    Private Sub Btn_Login_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_Login.Click
        Dim username As String = Txt_Username.Text.Trim()
        Dim password As String = Txt_Password.Text

        ' 1) Username required
        If String.IsNullOrWhiteSpace(username) Then
            MessageBox.Show("Please enter a username.", "Incomplete Field", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Txt_Username.Focus()
            Return
        End If

        ' 2) Cooldown check
        If DateTime.Now < My.Settings.CooldownLog Then
            Dim remaining As TimeSpan = My.Settings.CooldownLog.Subtract(DateTime.Now)
            MessageBox.Show( _
                "Please wait for " & remaining.Minutes.ToString() & " minute(s) and " & _
                remaining.Seconds.ToString() & " second(s).", _
                "Cooldown Active", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' 3) Password required
        If String.IsNullOrWhiteSpace(password) Then
            MessageBox.Show("Please enter a password.", "Incomplete Field", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Txt_Password.Focus()
            Return
        End If

        ' 4) Validate credentials
        If ValidateUser(username, password) Then
            ' — Log successful login
            currentHistoryId = LogLogin()

            ' Reset attempts & cooldown
            failedAttempts = 0
            My.Settings.CooldownLog = Date.MinValue
            My.Settings.Save()

            MessageBox.Show("Login Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Hide()
            Dim dashboardForm As New Home()
            dashboardForm.Show()

            Txt_Username.Clear()
            Txt_Password.Clear()
            Txt_Username.Focus()
            UserProfile.RefreshLoginHistory()
        Else
            ' — Failed login
            failedAttempts += 1

            If failedAttempts >= 2 Then
                MessageBox.Show("Too many attempts. Your account is locked for 3 minutes.", "Too Many Attempts", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                TriggerCooldown(3)

                Dim remaining As TimeSpan = My.Settings.CooldownLog.Subtract(DateTime.Now)
                MessageBox.Show( _
                    "Please wait for " & remaining.Minutes.ToString() & " minute(s) and " & _
                    remaining.Seconds.ToString() & " second(s).", _
                    "Cooldown Active", MessageBoxButtons.OK, MessageBoxIcon.Warning)

                Txt_Username.Clear()
                Txt_Password.Clear()
                Txt_Username.Focus()
                Return
            Else
                MessageBox.Show("Invalid username or password", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            Txt_Username.Clear()
            Txt_Password.Clear()
            Txt_Username.Focus()
        End If
    End Sub

    ' === HELPER: Trigger Cooldown ===
    Private Sub TriggerCooldown(ByVal minutes As Integer)
        My.Settings.CooldownLog = DateTime.Now.AddMinutes(minutes)
        My.Settings.Save()
    End Sub

    ' === HELPER: Validate User ===
    Private Function ValidateUser(ByVal username As String, ByVal password As String) As Boolean
        Try
            Using conn As New SqlConnection(connectionString)
                conn.Open()
                Dim sql As String = "SELECT COUNT(*) FROM [Login] " & _
                                    "WHERE Username COLLATE Latin1_General_CS_AS = @u " & _
                                    "AND Password COLLATE Latin1_General_CS_AS = @p"
                Using cmd As New SqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@u", username)
                    cmd.Parameters.AddWithValue("@p", password)
                    Return Convert.ToInt32(cmd.ExecuteScalar()) > 0
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error validating user: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    ' === HELPER: Log Login, return new HistoryID ===
    Private Function LogLogin() As Integer
        Dim newId As Integer
        Using conn As New SqlConnection(connectionString)
            conn.Open()
            Dim sql As String = "INSERT INTO LoginHistory (LoginTime) VALUES (GETDATE()); " & _
                                "SELECT CAST(SCOPE_IDENTITY() AS INT)"
            Using cmd As New SqlCommand(sql, conn)
                newId = CInt(cmd.ExecuteScalar())
            End Using
        End Using
        Return newId
    End Function

    ' === SHOW/HIDE PASSWORD BUTTON ===
    Private Sub Btn_ShowPass_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_ShowPass.Click
        Txt_Password.UseSystemPasswordChar = Not Txt_Password.UseSystemPasswordChar
    End Sub

    ' === KEYDOWN HANDLERS ===
    Private Sub Txt_Username_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles Txt_Username.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            Txt_Password.Focus()
        End If
    End Sub

    Private Sub Txt_Password_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles Txt_Password.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            Btn_Login_Click(sender, e)
        End If
    End Sub

    ' === FORGOT PASSWORD LINK ===
    Private Sub LinkLabel1_LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Dim forgetForm As New ForgetPassword()
        forgetForm.Show()
        Me.Hide()
        Txt_Username.Clear()
        Txt_Password.Clear()
    End Sub

    ' === EXIT BUTTON ===
    Private Sub Btn_Exit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_Exit.Click
        If MessageBox.Show("Are you sure you want to Exit?", "Exit",
                           MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) = DialogResult.OK Then
            Application.Exit()
        End If
    End Sub
End Class
