﻿Public Class HiddenInputDialog
    Inherits Form

    Public Property InputValue As String = ""
    Private inputTextBox As TextBox
    Private okButton As Button
    Private btnCancel As Button
    ' Add a checkbox for Show/Hide toggle
    Private chkShow As CheckBox

    Public Sub New(ByVal prompt As String, ByVal title As String)
        Me.Text = title
        Me.FormBorderStyle = FormBorderStyle.FixedDialog
        Me.StartPosition = FormStartPosition.CenterParent
        Me.Width = 350
        Me.Height = 180
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.ShowInTaskbar = False

        ' Prompt label
        Dim lblPrompt As New Label() With {
            .Text = prompt,
            .Left = 10,
            .Top = 10,
            .Width = 320
        }
        Me.Controls.Add(lblPrompt)

        ' Input textbox (masked by default)
        inputTextBox = New TextBox() With {
            .Left = 10,
            .Top = lblPrompt.Bottom + 10,
            .Width = 320,
            .UseSystemPasswordChar = True
        }
        Me.Controls.Add(inputTextBox)

        ' Show/Hide checkbox
        chkShow = New CheckBox() With {
            .Text = "Show",
            .Left = 10,
            .Top = inputTextBox.Bottom + 5,
            .AutoSize = True
        }
        AddHandler chkShow.CheckedChanged, AddressOf OnShowCheckedChanged
        Me.Controls.Add(chkShow)

        ' OK button
        okButton = New Button() With {
            .Text = "OK",
            .Left = 10,
            .Top = chkShow.Bottom + 10,
            .DialogResult = DialogResult.OK
        }
        Me.Controls.Add(okButton)

        ' Cancel button
        btnCancel = New Button() With {
            .Text = "Cancel",
            .Left = okButton.Right + 10,
            .Top = chkShow.Bottom + 10,
            .DialogResult = DialogResult.Cancel
        }
        Me.Controls.Add(btnCancel)

        Me.AcceptButton = okButton
        Me.CancelButton = btnCancel
    End Sub

    Protected Overrides Sub OnFormClosing(ByVal e As FormClosingEventArgs)
        MyBase.OnFormClosing(e)
        If Me.DialogResult = DialogResult.OK Then
            InputValue = inputTextBox.Text
        End If
    End Sub

    Private Sub OnShowCheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
        ' Toggle masking
        inputTextBox.UseSystemPasswordChar = Not chkShow.Checked
    End Sub
End Class
