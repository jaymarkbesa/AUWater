﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Reports
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Reports))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Btn_ExportGrossRevenue = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Cb_Year = New System.Windows.Forms.ComboBox()
        Me.Cb_Month = New System.Windows.Forms.ComboBox()
        Me.Btn_Refresh = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Txt_Search = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Btn_ExportSalary = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Cb_Year1 = New System.Windows.Forms.ComboBox()
        Me.Cb_Month1 = New System.Windows.Forms.ComboBox()
        Me.Btn_Refresh1 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Txt_Search1 = New System.Windows.Forms.TextBox()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Btn_UserInfo = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Btn_Logout = New System.Windows.Forms.Button()
        Me.Btn_Recycle = New System.Windows.Forms.Button()
        Me.Btn_Reports = New System.Windows.Forms.Button()
        Me.Btn_EmployeeInfo = New System.Windows.Forms.Button()
        Me.Btn_Bills = New System.Windows.Forms.Button()
        Me.Btn_Calculation = New System.Windows.Forms.Button()
        Me.Btn_Home = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Btn_Export = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TabControl1.Location = New System.Drawing.Point(290, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.Padding = New System.Drawing.Point(30, 10)
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(990, 765)
        Me.TabControl1.TabIndex = 24
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage1.Controls.Add(Me.Btn_ExportGrossRevenue)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Cb_Year)
        Me.TabPage1.Controls.Add(Me.Cb_Month)
        Me.TabPage1.Controls.Add(Me.Btn_Refresh)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Txt_Search)
        Me.TabPage1.Controls.Add(Me.DataGridView1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 43)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(982, 718)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Gross Revenue Report"
        '
        'Btn_ExportGrossRevenue
        '
        Me.Btn_ExportGrossRevenue.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_ExportGrossRevenue.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_ExportGrossRevenue.FlatAppearance.BorderSize = 0
        Me.Btn_ExportGrossRevenue.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_ExportGrossRevenue.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_ExportGrossRevenue.Font = New System.Drawing.Font("Rockwell", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_ExportGrossRevenue.ForeColor = System.Drawing.Color.White
        Me.Btn_ExportGrossRevenue.Location = New System.Drawing.Point(825, 18)
        Me.Btn_ExportGrossRevenue.Name = "Btn_ExportGrossRevenue"
        Me.Btn_ExportGrossRevenue.Size = New System.Drawing.Size(142, 49)
        Me.Btn_ExportGrossRevenue.TabIndex = 144
        Me.Btn_ExportGrossRevenue.Text = "EXPORT RECORD"
        Me.Btn_ExportGrossRevenue.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(636, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 27)
        Me.Label2.TabIndex = 141
        Me.Label2.Text = "Year :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(465, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(95, 27)
        Me.Label3.TabIndex = 140
        Me.Label3.Text = "Month :"
        '
        'Cb_Year
        '
        Me.Cb_Year.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Year.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Year.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Year.FormattingEnabled = True
        Me.Cb_Year.Location = New System.Drawing.Point(641, 39)
        Me.Cb_Year.Name = "Cb_Year"
        Me.Cb_Year.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Year.TabIndex = 3
        '
        'Cb_Month
        '
        Me.Cb_Month.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Month.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Month.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Month.FormattingEnabled = True
        Me.Cb_Month.Location = New System.Drawing.Point(470, 39)
        Me.Cb_Month.Name = "Cb_Month"
        Me.Cb_Month.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Month.TabIndex = 2
        '
        'Btn_Refresh
        '
        Me.Btn_Refresh.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Refresh.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Refresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Btn_Refresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Refresh.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Refresh.ForeColor = System.Drawing.Color.White
        Me.Btn_Refresh.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_refresh_24
        Me.Btn_Refresh.Location = New System.Drawing.Point(355, 36)
        Me.Btn_Refresh.Name = "Btn_Refresh"
        Me.Btn_Refresh.Size = New System.Drawing.Size(44, 37)
        Me.Btn_Refresh.TabIndex = 1
        Me.Btn_Refresh.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(6, 40)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(102, 27)
        Me.Label7.TabIndex = 137
        Me.Label7.Text = "Search :"
        '
        'Txt_Search
        '
        Me.Txt_Search.BackColor = System.Drawing.Color.White
        Me.Txt_Search.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Search.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Search.Location = New System.Drawing.Point(114, 40)
        Me.Txt_Search.Name = "Txt_Search"
        Me.Txt_Search.Size = New System.Drawing.Size(235, 27)
        Me.Txt_Search.TabIndex = 0
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView1.Cursor = System.Windows.Forms.Cursors.Hand
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.GridColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView1.Location = New System.Drawing.Point(5, 79)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(126, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(221, Byte), Integer))
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(968, 604)
        Me.DataGridView1.TabIndex = 134
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage2.Controls.Add(Me.Btn_ExportSalary)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.Cb_Year1)
        Me.TabPage2.Controls.Add(Me.Cb_Month1)
        Me.TabPage2.Controls.Add(Me.Btn_Refresh1)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.Txt_Search1)
        Me.TabPage2.Controls.Add(Me.DataGridView2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 43)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(982, 718)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Salary Report"
        '
        'Btn_ExportSalary
        '
        Me.Btn_ExportSalary.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_ExportSalary.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_ExportSalary.FlatAppearance.BorderSize = 0
        Me.Btn_ExportSalary.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_ExportSalary.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_ExportSalary.Font = New System.Drawing.Font("Rockwell", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_ExportSalary.ForeColor = System.Drawing.Color.White
        Me.Btn_ExportSalary.Location = New System.Drawing.Point(825, 18)
        Me.Btn_ExportSalary.Name = "Btn_ExportSalary"
        Me.Btn_ExportSalary.Size = New System.Drawing.Size(142, 49)
        Me.Btn_ExportSalary.TabIndex = 145
        Me.Btn_ExportSalary.Text = "EXPORT RECORD"
        Me.Btn_ExportSalary.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(636, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(78, 27)
        Me.Label4.TabIndex = 133
        Me.Label4.Text = "Year :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(465, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(95, 27)
        Me.Label5.TabIndex = 132
        Me.Label5.Text = "Month :"
        '
        'Cb_Year1
        '
        Me.Cb_Year1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Year1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Year1.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Year1.FormattingEnabled = True
        Me.Cb_Year1.Location = New System.Drawing.Point(641, 39)
        Me.Cb_Year1.Name = "Cb_Year1"
        Me.Cb_Year1.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Year1.TabIndex = 3
        '
        'Cb_Month1
        '
        Me.Cb_Month1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Month1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Month1.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Month1.FormattingEnabled = True
        Me.Cb_Month1.Location = New System.Drawing.Point(470, 39)
        Me.Cb_Month1.Name = "Cb_Month1"
        Me.Cb_Month1.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Month1.TabIndex = 2
        '
        'Btn_Refresh1
        '
        Me.Btn_Refresh1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Refresh1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Refresh1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Btn_Refresh1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Refresh1.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Refresh1.ForeColor = System.Drawing.Color.White
        Me.Btn_Refresh1.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_refresh_24
        Me.Btn_Refresh1.Location = New System.Drawing.Point(355, 36)
        Me.Btn_Refresh1.Name = "Btn_Refresh1"
        Me.Btn_Refresh1.Size = New System.Drawing.Size(44, 37)
        Me.Btn_Refresh1.TabIndex = 1
        Me.Btn_Refresh1.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(6, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(102, 27)
        Me.Label6.TabIndex = 129
        Me.Label6.Text = "Search :"
        '
        'Txt_Search1
        '
        Me.Txt_Search1.BackColor = System.Drawing.Color.White
        Me.Txt_Search1.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Search1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Search1.Location = New System.Drawing.Point(114, 40)
        Me.Txt_Search1.Name = "Txt_Search1"
        Me.Txt_Search1.Size = New System.Drawing.Size(235, 27)
        Me.Txt_Search1.TabIndex = 0
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToResizeColumns = False
        Me.DataGridView2.AllowUserToResizeRows = False
        Me.DataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView2.Cursor = System.Windows.Forms.Cursors.Hand
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView2.DefaultCellStyle = DataGridViewCellStyle6
        Me.DataGridView2.GridColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView2.Location = New System.Drawing.Point(5, 79)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.ReadOnly = True
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(126, Byte), Integer))
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView2.RowHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.DataGridView2.RowHeadersVisible = False
        Me.DataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(221, Byte), Integer))
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black
        Me.DataGridView2.RowsDefaultCellStyle = DataGridViewCellStyle8
        Me.DataGridView2.RowTemplate.Height = 24
        Me.DataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView2.Size = New System.Drawing.Size(968, 604)
        Me.DataGridView2.TabIndex = 123
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Btn_UserInfo)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Btn_Logout)
        Me.Panel1.Controls.Add(Me.Btn_Recycle)
        Me.Panel1.Controls.Add(Me.Btn_Reports)
        Me.Panel1.Controls.Add(Me.Btn_EmployeeInfo)
        Me.Panel1.Controls.Add(Me.Btn_Bills)
        Me.Panel1.Controls.Add(Me.Btn_Calculation)
        Me.Panel1.Controls.Add(Me.Btn_Home)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(284, 789)
        Me.Panel1.TabIndex = 78
        '
        'Btn_UserInfo
        '
        Me.Btn_UserInfo.BackColor = System.Drawing.Color.Transparent
        Me.Btn_UserInfo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_UserInfo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_UserInfo.FlatAppearance.BorderSize = 0
        Me.Btn_UserInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_UserInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_UserInfo.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_settings_32
        Me.Btn_UserInfo.Location = New System.Drawing.Point(164, 224)
        Me.Btn_UserInfo.Name = "Btn_UserInfo"
        Me.Btn_UserInfo.Size = New System.Drawing.Size(42, 38)
        Me.Btn_UserInfo.TabIndex = 76
        Me.Btn_UserInfo.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(70, 231)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 27)
        Me.Label1.TabIndex = 75
        Me.Label1.Text = "ADMIN"
        '
        'Btn_Logout
        '
        Me.Btn_Logout.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Logout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Logout.FlatAppearance.BorderSize = 0
        Me.Btn_Logout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Logout.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Logout.ForeColor = System.Drawing.Color.White
        Me.Btn_Logout.Location = New System.Drawing.Point(27, 719)
        Me.Btn_Logout.Name = "Btn_Logout"
        Me.Btn_Logout.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Logout.TabIndex = 72
        Me.Btn_Logout.Text = "LOGOUT"
        Me.Btn_Logout.UseVisualStyleBackColor = False
        '
        'Btn_Recycle
        '
        Me.Btn_Recycle.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Recycle.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Recycle.FlatAppearance.BorderSize = 0
        Me.Btn_Recycle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Recycle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Recycle.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Recycle.ForeColor = System.Drawing.Color.White
        Me.Btn_Recycle.Location = New System.Drawing.Point(27, 565)
        Me.Btn_Recycle.Name = "Btn_Recycle"
        Me.Btn_Recycle.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Recycle.TabIndex = 71
        Me.Btn_Recycle.Text = "RECYCLE BIN"
        Me.Btn_Recycle.UseVisualStyleBackColor = False
        '
        'Btn_Reports
        '
        Me.Btn_Reports.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Reports.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Reports.FlatAppearance.BorderSize = 2
        Me.Btn_Reports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Reports.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Reports.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Reports.ForeColor = System.Drawing.Color.White
        Me.Btn_Reports.Location = New System.Drawing.Point(27, 510)
        Me.Btn_Reports.Name = "Btn_Reports"
        Me.Btn_Reports.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Reports.TabIndex = 70
        Me.Btn_Reports.Text = "REPORTS"
        Me.Btn_Reports.UseVisualStyleBackColor = False
        '
        'Btn_EmployeeInfo
        '
        Me.Btn_EmployeeInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_EmployeeInfo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_EmployeeInfo.FlatAppearance.BorderSize = 0
        Me.Btn_EmployeeInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_EmployeeInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_EmployeeInfo.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_EmployeeInfo.ForeColor = System.Drawing.Color.White
        Me.Btn_EmployeeInfo.Location = New System.Drawing.Point(27, 345)
        Me.Btn_EmployeeInfo.Name = "Btn_EmployeeInfo"
        Me.Btn_EmployeeInfo.Size = New System.Drawing.Size(231, 49)
        Me.Btn_EmployeeInfo.TabIndex = 69
        Me.Btn_EmployeeInfo.Text = "EMPLOYEE INFORMATION"
        Me.Btn_EmployeeInfo.UseVisualStyleBackColor = False
        '
        'Btn_Bills
        '
        Me.Btn_Bills.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Bills.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Bills.FlatAppearance.BorderSize = 0
        Me.Btn_Bills.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Bills.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Bills.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Bills.ForeColor = System.Drawing.Color.White
        Me.Btn_Bills.Location = New System.Drawing.Point(27, 455)
        Me.Btn_Bills.Name = "Btn_Bills"
        Me.Btn_Bills.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Bills.TabIndex = 68
        Me.Btn_Bills.Text = "WATER BILLS AND ELECTRICITY"
        Me.Btn_Bills.UseVisualStyleBackColor = False
        '
        'Btn_Calculation
        '
        Me.Btn_Calculation.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Calculation.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Calculation.FlatAppearance.BorderSize = 0
        Me.Btn_Calculation.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Calculation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Calculation.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Calculation.ForeColor = System.Drawing.Color.White
        Me.Btn_Calculation.Location = New System.Drawing.Point(27, 400)
        Me.Btn_Calculation.Name = "Btn_Calculation"
        Me.Btn_Calculation.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Calculation.TabIndex = 67
        Me.Btn_Calculation.Text = "SALARY AND INCOME CALCULATION"
        Me.Btn_Calculation.UseVisualStyleBackColor = False
        '
        'Btn_Home
        '
        Me.Btn_Home.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Home.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Home.FlatAppearance.BorderSize = 0
        Me.Btn_Home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Home.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Home.ForeColor = System.Drawing.Color.White
        Me.Btn_Home.Location = New System.Drawing.Point(27, 290)
        Me.Btn_Home.Name = "Btn_Home"
        Me.Btn_Home.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Home.TabIndex = 65
        Me.Btn_Home.Text = "HOME"
        Me.Btn_Home.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = Global.WindowsApplication1.My.Resources.Resources._439432707_3811750089048465_8998649572546640568_n_removebg_preview1
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(284, 218)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 64
        Me.PictureBox1.TabStop = False
        '
        'Btn_Export
        '
        Me.Btn_Export.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Export.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Export.FlatAppearance.BorderSize = 0
        Me.Btn_Export.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Export.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Export.Font = New System.Drawing.Font("Rockwell", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Export.ForeColor = System.Drawing.Color.White
        Me.Btn_Export.Location = New System.Drawing.Point(825, 18)
        Me.Btn_Export.Name = "Btn_Export"
        Me.Btn_Export.Size = New System.Drawing.Size(142, 49)
        Me.Btn_Export.TabIndex = 142
        Me.Btn_Export.Text = "EXPORT RECORD"
        Me.Btn_Export.UseVisualStyleBackColor = False
        '
        'Reports
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1292, 789)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Reports"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AU WATER REFILLING STATION"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Btn_UserInfo As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Btn_Logout As System.Windows.Forms.Button
    Friend WithEvents Btn_Recycle As System.Windows.Forms.Button
    Friend WithEvents Btn_Reports As System.Windows.Forms.Button
    Friend WithEvents Btn_EmployeeInfo As System.Windows.Forms.Button
    Friend WithEvents Btn_Bills As System.Windows.Forms.Button
    Friend WithEvents Btn_Calculation As System.Windows.Forms.Button
    Friend WithEvents Btn_Home As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Cb_Year1 As System.Windows.Forms.ComboBox
    Friend WithEvents Cb_Month1 As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_Refresh1 As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_Search1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Cb_Year As System.Windows.Forms.ComboBox
    Friend WithEvents Cb_Month As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_Refresh As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_Search As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents Btn_Export As System.Windows.Forms.Button
    Friend WithEvents Btn_ExportGrossRevenue As System.Windows.Forms.Button
    Friend WithEvents Btn_ExportSalary As System.Windows.Forms.Button
End Class
