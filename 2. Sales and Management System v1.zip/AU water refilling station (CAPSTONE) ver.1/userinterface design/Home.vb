﻿Imports System.Data.SqlClient
Imports System.Text
Public Class Home
    Dim connectionString As String = "Data Source=LAPTOP-E6UDS97D\SQLEXPRESS;Initial Catalog=Au Water Refilling Station;Integrated Security=True"
    Dim conn As New SqlConnection(connectionString)
    Dim cmd As SqlCommand
    Dim adapter As SqlDataAdapter
    Dim dt As DataTable

    Public Sub Home_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
        LoadAllData()

        If My.Settings.ShowSalaryAndIncome Then
            Panel_Form1.Visible = False
            Panel_Form2.Visible = True

            SalaryAndIncome.Label26.Visible = True
            SalaryAndIncome.Label15.Visible = True
            SalaryAndIncome.Label16.Visible = True
            SalaryAndIncome.Txt_SmallWaterRefill.Visible = True
            SalaryAndIncome.Txt_SmallContainerWater.Visible = True
            SalaryAndIncome.Txt_SmallContainer.Visible = True
        Else
            SalaryAndIncome.Label26.Visible = False
            SalaryAndIncome.Label15.Visible = False
            SalaryAndIncome.Label16.Visible = False
            SalaryAndIncome.Txt_SmallWaterRefill.Visible = False
            SalaryAndIncome.Txt_SmallContainerWater.Visible = False
            SalaryAndIncome.Txt_SmallContainer.Visible = False
        End If

    End Sub
    ' Sa loob ng Home form (Home.vb)
    Public Sub LoadAllData()
        'Regular Gallons

        'Gallon Refill
        LoadWaterRefillGallons()
        LoadWaterRefillGallons3()

        'Container with water
        LoadWaterRefillGallons1()
        LoadWaterRefillGallons4()

        'Container
        LoadWaterRefillGallons2()
        LoadWaterRefillGallons5()

        'Prices of Regular Gallons
        LoadPriceData()
        LoadPriceData1()
        LoadPriceData2()

        'Small Gallons

        'Small Gallon Refill
        LoadWaterRefillGallons6()
        LoadWaterRefillGallons7()

        'Small Container with water
        LoadWaterRefillGallons8()
        LoadWaterRefillGallons9()

        'Small Container
        LoadWaterRefillGallons10()
        LoadWaterRefillGallons11()

        'Prices of Small Gallons
        LoadPriceData3()
        LoadPriceData4()
        LoadPriceData5()

    End Sub
    ' Regular Gallons
    Private Sub LoadWaterRefillGallons()
        Dim query As String = "SELECT RegWaterGallon FROM Sold"
        Dim cmd As New SqlCommand(query, conn)

        Try
            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim totalGallons As Integer = 0

            While reader.Read()
                ' Kada row na binabasa, idadagdag ang laman ng column sa totalGallons.
                Dim gallon As Integer = 0
                If Integer.TryParse(reader("RegWaterGallon").ToString(), gallon) Then
                    totalGallons += gallon
                End If
            End While

            If totalGallons > 0 Then
                ' I-set ang resulta sa Text property ng Label.
                Lbl_WaterRefillSold.Text = totalGallons.ToString()
                Lbl_WaterRefillSold1.Text = totalGallons.ToString()

                ' I-set ang TextAlign property ng Label sa Center.
                Lbl_WaterRefillSold.TextAlign = ContentAlignment.MiddleCenter
                Lbl_WaterRefillSold1.TextAlign = ContentAlignment.MiddleCenter

                ' I-set ang AutoSize property ng Label sa True upang mag-adjust ito depende sa laman nito.
                Lbl_WaterRefillSold.AutoSize = True
                Lbl_WaterRefillSold1.AutoSize = True

                ' I-center ang Label sa loob ng Panel4 gamit ang Anchor property.
                Lbl_WaterRefillSold.Anchor = AnchorStyles.None
                Lbl_WaterRefillSold1.Anchor = AnchorStyles.None

                Lbl_WaterRefillSold.Location = New Point((Panel4.Width - Lbl_WaterRefillSold.Width) \ 2, (Panel4.Height - Lbl_WaterRefillSold.Height) \ 2)
                Lbl_WaterRefillSold1.Location = New Point((Panel20.Width - Lbl_WaterRefillSold1.Width) \ 2, (Panel20.Height - Lbl_WaterRefillSold1.Height) \ 2)

            Else
                Lbl_WaterRefillSold.Text = "0"
                Lbl_WaterRefillSold1.Text = "0"
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadWaterRefillGallons3()
        Dim query As String = "SELECT RegWaterGallon FROM GrossRevenue "
        Dim cmd As New SqlCommand(query, conn)

        Try
            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim totalGallons As Integer = 0

            While reader.Read()
                ' Kada row na binabasa, idadagdag ang laman ng column sa totalGallons.
                Dim gallon As Integer = 0
                If Integer.TryParse(reader("RegWaterGallon").ToString(), gallon) Then
                    totalGallons += gallon
                End If
            End While

            If totalGallons > 0 Then
                ' I-set ang resulta sa Text property ng Label.
                Lbl_WaterRefillIncome.Text = totalGallons.ToString()
                Lbl_WaterRefillIncome1.Text = totalGallons.ToString()

                ' I-set ang TextAlign property ng Label sa Center.
                Lbl_WaterRefillIncome.TextAlign = ContentAlignment.MiddleCenter
                Lbl_WaterRefillIncome1.TextAlign = ContentAlignment.MiddleCenter

                ' I-set ang AutoSize property ng Label sa True upang mag-adjust ito depende sa laman nito.
                Lbl_WaterRefillIncome.AutoSize = True
                Lbl_WaterRefillIncome1.AutoSize = True

                ' I-center ang Label sa loob ng Panel4 gamit ang Anchor property.
                Lbl_WaterRefillIncome.Anchor = AnchorStyles.None
                Lbl_WaterRefillIncome1.Anchor = AnchorStyles.None

                Lbl_WaterRefillIncome.Location = New Point((Panel6.Width - Lbl_WaterRefillIncome.Width) \ 2, (Panel6.Height - Lbl_WaterRefillIncome.Height) \ 2)
                Lbl_WaterRefillIncome1.Location = New Point((Panel18.Width - Lbl_WaterRefillIncome1.Width) \ 2, (Panel18.Height - Lbl_WaterRefillIncome1.Height) \ 2)

            Else
                Lbl_WaterRefillIncome.Text = "0"
                Lbl_WaterRefillIncome1.Text = "0"
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadWaterRefillGallons1()
        Dim query As String = "SELECT RegContainerwithWater FROM Sold"
        Dim cmd As New SqlCommand(query, conn)

        Try
            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim totalGallons As Integer = 0

            While reader.Read()
                ' Kada row na binabasa, idadagdag ang laman ng column sa totalGallons.
                Dim gallon As Integer = 0
                If Integer.TryParse(reader("RegContainerwithWater").ToString(), gallon) Then
                    totalGallons += gallon
                End If
            End While

            If totalGallons > 0 Then
                ' I-set ang resulta sa Text property ng Label.
                Lbl_ContainerWaterSold.Text = totalGallons.ToString()
                Lbl_ContainerWaterSold1.Text = totalGallons.ToString()

                ' I-set ang TextAlign property ng Label sa Center.
                Lbl_ContainerWaterSold.TextAlign = ContentAlignment.MiddleCenter
                Lbl_ContainerWaterSold1.TextAlign = ContentAlignment.MiddleCenter

                ' I-set ang AutoSize property ng Label sa True upang mag-adjust ito depende sa laman nito.
                Lbl_ContainerWaterSold.AutoSize = True
                Lbl_ContainerWaterSold1.AutoSize = True

                ' I-center ang Label sa loob ng Panel4 gamit ang Anchor property.
                Lbl_ContainerWaterSold.Anchor = AnchorStyles.None
                Lbl_ContainerWaterSold1.Anchor = AnchorStyles.None

                Lbl_ContainerWaterSold.Location = New Point((Panel5.Width - Lbl_ContainerWaterSold.Width) \ 2, (Panel5.Height - Lbl_ContainerWaterSold.Height) \ 2)
                Lbl_ContainerWaterSold1.Location = New Point((Panel19.Width - Lbl_ContainerWaterSold1.Width) \ 2, (Panel19.Height - Lbl_ContainerWaterSold1.Height) \ 2)
            Else
                Lbl_ContainerWaterSold.Text = "0"
                Lbl_ContainerWaterSold1.Text = "0"
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadWaterRefillGallons4()
        Dim query As String = "SELECT RegContainerwithWater FROM GrossRevenue"
        Dim cmd As New SqlCommand(query, conn)

        Try
            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim totalGallons As Integer = 0

            While reader.Read()
                ' Kada row na binabasa, idadagdag ang laman ng column sa totalGallons.
                Dim gallon As Integer = 0
                If Integer.TryParse(reader("RegContainerwithWater").ToString(), gallon) Then
                    totalGallons += gallon
                End If
            End While

            If totalGallons > 0 Then
                ' I-set ang resulta sa Text property ng Label.
                Lbl_ContainerWaterIncome.Text = totalGallons.ToString()
                Lbl_ContainerWaterIncome1.Text = totalGallons.ToString()

                ' I-set ang TextAlign property ng Label sa Center.
                Lbl_ContainerWaterIncome.TextAlign = ContentAlignment.MiddleCenter
                Lbl_ContainerWaterIncome1.TextAlign = ContentAlignment.MiddleCenter

                ' I-set ang AutoSize property ng Label sa True upang mag-adjust ito depende sa laman nito.
                Lbl_ContainerWaterIncome.AutoSize = True
                Lbl_ContainerWaterIncome1.AutoSize = True

                ' I-center ang Label sa loob ng Panel4 gamit ang Anchor property.
                Lbl_ContainerWaterIncome.Anchor = AnchorStyles.None
                Lbl_ContainerWaterIncome1.Anchor = AnchorStyles.None

                Lbl_ContainerWaterIncome.Location = New Point((Panel7.Width - Lbl_ContainerWaterIncome.Width) \ 2, (Panel7.Height - Lbl_ContainerWaterIncome.Height) \ 2)
                Lbl_ContainerWaterIncome1.Location = New Point((Panel17.Width - Lbl_ContainerWaterIncome1.Width) \ 2, (Panel17.Height - Lbl_ContainerWaterIncome1.Height) \ 2)
            Else
                Lbl_ContainerWaterIncome.Text = "0"
                Lbl_ContainerWaterIncome1.Text = "0"
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadWaterRefillGallons2()
        Dim query As String = "SELECT RegContainer FROM Sold"
        Dim cmd As New SqlCommand(query, conn)

        Try
            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim totalGallons As Integer = 0

            While reader.Read()
                ' Kada row na binabasa, idadagdag ang laman ng column sa totalGallons.
                Dim gallon As Integer = 0
                If Integer.TryParse(reader("RegContainer").ToString(), gallon) Then
                    totalGallons += gallon
                End If
            End While

            If totalGallons > 0 Then
                ' I-set ang resulta sa Text property ng Label.
                Lbl_ContainerSold.Text = totalGallons.ToString()
                Lbl_ContainerSold1.Text = totalGallons.ToString()

                ' I-set ang TextAlign property ng Label sa Center.
                Lbl_ContainerSold.TextAlign = ContentAlignment.MiddleCenter
                Lbl_ContainerSold1.TextAlign = ContentAlignment.MiddleCenter

                ' I-set ang AutoSize property ng Label sa True upang mag-adjust ito depende sa laman nito.
                Lbl_ContainerSold.AutoSize = True
                Lbl_ContainerSold1.AutoSize = True

                ' I-center ang Label sa loob ng Panel4 gamit ang Anchor property.
                Lbl_ContainerSold.Anchor = AnchorStyles.None
                Lbl_ContainerSold1.Anchor = AnchorStyles.None

                Lbl_ContainerSold.Location = New Point((Panel8.Width - Lbl_ContainerSold.Width) \ 2, (Panel8.Height - Lbl_ContainerSold.Height) \ 2)
                Lbl_ContainerSold1.Location = New Point((Panel16.Width - Lbl_ContainerSold1.Width) \ 2, (Panel16.Height - Lbl_ContainerSold1.Height) \ 2)
            Else
                Lbl_ContainerSold.Text = "0"
                Lbl_ContainerSold1.Text = "0"
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadWaterRefillGallons5()
        Dim query As String = "SELECT RegContainer FROM GrossRevenue"
        Dim cmd As New SqlCommand(query, conn)

        Try
            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim totalGallons As Integer = 0

            While reader.Read()
                ' Kada row na binabasa, idadagdag ang laman ng column sa totalGallons.
                Dim gallon As Integer = 0
                If Integer.TryParse(reader("RegContainer").ToString(), gallon) Then
                    totalGallons += gallon
                End If
            End While

            If totalGallons > 0 Then
                ' I-set ang resulta sa Text property ng Label.
                Lbl_ContainerIncome.Text = totalGallons.ToString()
                Lbl_ContainerIncome1.Text = totalGallons.ToString()

                ' I-set ang TextAlign property ng Label sa Center.
                Lbl_ContainerIncome.TextAlign = ContentAlignment.MiddleCenter
                Lbl_ContainerIncome1.TextAlign = ContentAlignment.MiddleCenter

                ' I-set ang AutoSize property ng Label sa True upang mag-adjust ito depende sa laman nito.
                Lbl_ContainerIncome.AutoSize = True
                Lbl_ContainerIncome1.AutoSize = True

                ' I-center ang Label sa loob ng Panel4 gamit ang Anchor property.
                Lbl_ContainerIncome.Anchor = AnchorStyles.None
                Lbl_ContainerIncome1.Anchor = AnchorStyles.None

                Lbl_ContainerIncome.Location = New Point((Panel9.Width - Lbl_ContainerIncome.Width) \ 2, (Panel9.Height - Lbl_ContainerIncome.Height) \ 2)
                Lbl_ContainerIncome1.Location = New Point((Panel15.Width - Lbl_ContainerIncome1.Width) \ 2, (Panel15.Height - Lbl_ContainerIncome1.Height) \ 2)
            Else
                Lbl_ContainerIncome.Text = "0"
                Lbl_ContainerIncome1.Text = "0"
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    'Small Gallons
    Private Sub LoadWaterRefillGallons6()
        Dim query As String = "SELECT SmallWaterGallon FROM Sold"
        Dim cmd As New SqlCommand(query, conn)

        Try
            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim totalGallons As Integer = 0

            While reader.Read()
                ' Kada row na binabasa, idadagdag ang laman ng column sa totalGallons.
                Dim gallon As Integer = 0
                If Integer.TryParse(reader("SmallWaterGallon").ToString(), gallon) Then
                    totalGallons += gallon
                End If
            End While

            If totalGallons > 0 Then
                ' I-set ang resulta sa Text property ng Label.
                Lbl_SmallRefillSold.Text = totalGallons.ToString()

                ' I-set ang TextAlign property ng Label sa Center.
                Lbl_SmallRefillSold.TextAlign = ContentAlignment.MiddleCenter

                ' I-set ang AutoSize property ng Label sa True upang mag-adjust ito depende sa laman nito.
                Lbl_SmallRefillSold.AutoSize = True

                ' I-center ang Label sa loob ng Panel4 gamit ang Anchor property.
                Lbl_SmallRefillSold.Anchor = AnchorStyles.None
                Lbl_SmallRefillSold.Location = New Point((Panel22.Width - Lbl_SmallRefillSold.Width) \ 2, (Panel22.Height - Lbl_SmallRefillSold.Height) \ 2)
            Else
                Lbl_SmallRefillSold.Text = "0"
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadWaterRefillGallons7()
        Dim query As String = "SELECT SmallWaterGallon FROM GrossRevenue "
        Dim cmd As New SqlCommand(query, conn)

        Try
            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim totalGallons As Integer = 0

            While reader.Read()
                ' Kada row na binabasa, idadagdag ang laman ng column sa totalGallons.
                Dim gallon As Integer = 0
                If Integer.TryParse(reader("SmallWaterGallon").ToString(), gallon) Then
                    totalGallons += gallon
                End If
            End While

            If totalGallons > 0 Then
                ' I-set ang resulta sa Text property ng Label.
                Lbl_SmallRefillIncome.Text = totalGallons.ToString()

                ' I-set ang TextAlign property ng Label sa Center.
                Lbl_SmallRefillIncome.TextAlign = ContentAlignment.MiddleCenter

                ' I-set ang AutoSize property ng Label sa True upang mag-adjust ito depende sa laman nito.
                Lbl_SmallRefillIncome.AutoSize = True

                ' I-center ang Label sa loob ng Panel4 gamit ang Anchor property.
                Lbl_SmallRefillIncome.Anchor = AnchorStyles.None
                Lbl_SmallRefillIncome.Location = New Point((Panel23.Width - Lbl_SmallRefillIncome.Width) \ 2, (Panel23.Height - Lbl_SmallRefillIncome.Height) \ 2)
            Else
                Lbl_SmallRefillIncome.Text = "0"
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadWaterRefillGallons8()
        Dim query As String = "SELECT SmallContainerwithWater FROM Sold"
        Dim cmd As New SqlCommand(query, conn)

        Try
            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim totalGallons As Integer = 0

            While reader.Read()
                ' Kada row na binabasa, idadagdag ang laman ng column sa totalGallons.
                Dim gallon As Integer = 0
                If Integer.TryParse(reader("SmallContainerwithWater").ToString(), gallon) Then
                    totalGallons += gallon
                End If
            End While

            If totalGallons > 0 Then
                ' I-set ang resulta sa Text property ng Label.
                Lbl_SmallContainerwithWaterSold.Text = totalGallons.ToString()

                ' I-set ang TextAlign property ng Label sa Center.
                Lbl_SmallContainerwithWaterSold.TextAlign = ContentAlignment.MiddleCenter

                ' I-set ang AutoSize property ng Label sa True upang mag-adjust ito depende sa laman nito.
                Lbl_SmallContainerwithWaterSold.AutoSize = True

                ' I-center ang Label sa loob ng Panel4 gamit ang Anchor property.
                Lbl_SmallContainerwithWaterSold.Anchor = AnchorStyles.None
                Lbl_SmallContainerwithWaterSold.Location = New Point((Panel25.Width - Lbl_SmallContainerwithWaterSold.Width) \ 2, (Panel25.Height - Lbl_SmallContainerwithWaterSold.Height) \ 2)
            Else
                Lbl_SmallContainerwithWaterSold.Text = "0"
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadWaterRefillGallons9()
        Dim query As String = "SELECT SmallContainerwithWater FROM GrossRevenue "
        Dim cmd As New SqlCommand(query, conn)

        Try
            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim totalGallons As Integer = 0

            While reader.Read()
                ' Kada row na binabasa, idadagdag ang laman ng column sa totalGallons.
                Dim gallon As Integer = 0
                If Integer.TryParse(reader("SmallContainerwithWater").ToString(), gallon) Then
                    totalGallons += gallon
                End If
            End While

            If totalGallons > 0 Then
                ' I-set ang resulta sa Text property ng Label.
                Lbl_SmallContainerwithWaterIncome.Text = totalGallons.ToString()

                ' I-set ang TextAlign property ng Label sa Center.
                Lbl_SmallContainerwithWaterIncome.TextAlign = ContentAlignment.MiddleCenter

                ' I-set ang AutoSize property ng Label sa True upang mag-adjust ito depende sa laman nito.
                Lbl_SmallContainerwithWaterIncome.AutoSize = True

                ' I-center ang Label sa loob ng Panel4 gamit ang Anchor property.
                Lbl_SmallContainerwithWaterIncome.Anchor = AnchorStyles.None
                Lbl_SmallContainerwithWaterIncome.Location = New Point((Panel26.Width - Lbl_SmallContainerwithWaterIncome.Width) \ 2, (Panel26.Height - Lbl_SmallContainerwithWaterIncome.Height) \ 2)
            Else
                Lbl_SmallContainerwithWaterIncome.Text = "0"
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadWaterRefillGallons10()
        Dim query As String = "SELECT SmallContainer FROM Sold"
        Dim cmd As New SqlCommand(query, conn)

        Try
            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim totalGallons As Integer = 0

            While reader.Read()
                ' Kada row na binabasa, idadagdag ang laman ng column sa totalGallons.
                Dim gallon As Integer = 0
                If Integer.TryParse(reader("SmallContainer").ToString(), gallon) Then
                    totalGallons += gallon
                End If
            End While

            If totalGallons > 0 Then
                ' I-set ang resulta sa Text property ng Label.
                Lbl_SmallContainerSold.Text = totalGallons.ToString()

                ' I-set ang TextAlign property ng Label sa Center.
                Lbl_SmallContainerSold.TextAlign = ContentAlignment.MiddleCenter

                ' I-set ang AutoSize property ng Label sa True upang mag-adjust ito depende sa laman nito.
                Lbl_SmallContainerSold.AutoSize = True

                ' I-center ang Label sa loob ng Panel4 gamit ang Anchor property.
                Lbl_SmallContainerSold.Anchor = AnchorStyles.None
                Lbl_SmallContainerSold.Location = New Point((Panel28.Width - Lbl_SmallContainerSold.Width) \ 2, (Panel28.Height - Lbl_SmallContainerSold.Height) \ 2)
            Else
                Lbl_SmallContainerSold.Text = "0"
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadWaterRefillGallons11()
        Dim query As String = "SELECT SmallContainer FROM GrossRevenue "
        Dim cmd As New SqlCommand(query, conn)

        Try
            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()
            Dim totalGallons As Integer = 0

            While reader.Read()
                ' Kada row na binabasa, idadagdag ang laman ng column sa totalGallons.
                Dim gallon As Integer = 0
                If Integer.TryParse(reader("SmallContainer").ToString(), gallon) Then
                    totalGallons += gallon
                End If
            End While

            If totalGallons > 0 Then
                ' I-set ang resulta sa Text property ng Label.
                Lbl_SmallContainerIncome.Text = totalGallons.ToString()

                ' I-set ang TextAlign property ng Label sa Center.
                Lbl_SmallContainerIncome.TextAlign = ContentAlignment.MiddleCenter

                ' I-set ang AutoSize property ng Label sa True upang mag-adjust ito depende sa laman nito.
                Lbl_SmallContainerIncome.AutoSize = True

                ' I-center ang Label sa loob ng Panel4 gamit ang Anchor property.
                Lbl_SmallContainerIncome.Anchor = AnchorStyles.None
                Lbl_SmallContainerIncome.Location = New Point((Panel29.Width - Lbl_SmallContainerIncome.Width) \ 2, (Panel29.Height - Lbl_SmallContainerIncome.Height) \ 2)
            Else
                Lbl_SmallContainerIncome.Text = "0"
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    'Regular Gallons
    Private Sub LoadPriceData()
        Dim query As String = "SELECT RegWaterGallon FROM Price"
        Dim adapter As New SqlDataAdapter(query, conn)
        Dim dt As New DataTable()

        Try
            conn.Open()
            adapter.Fill(dt)

            ' Siguraduhing may laman ang DataTable bago gamitin ang unang row.
            If dt.Rows.Count > 0 Then
                ' Kunin ang unang row at unang column na laman.
                Dim price As String = dt.Rows(0)(0).ToString()

                ' Ipakita ang resulta sa Txt_PriceGallon.Text.
                Txt_PriceGallon.Text = price
                Txt_PriceGallon1.Text = price
            Else
                Txt_PriceGallon.Text = "0"
                Txt_PriceGallon1.Text = "0"
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadPriceData1()
        Dim query As String = "SELECT RegContainerwithWater FROM Price"
        Dim adapter As New SqlDataAdapter(query, conn)
        Dim dt As New DataTable()

        Try
            conn.Open()
            adapter.Fill(dt)

            ' Siguraduhing may laman ang DataTable bago gamitin ang unang row.
            If dt.Rows.Count > 0 Then
                ' Kunin ang unang row at unang column na laman.
                Dim price As String = dt.Rows(0)(0).ToString()

                ' Ipakita ang resulta sa Txt_PriceGallon.Text.
                Txt_PriceContainerWater.Text = price
                Txt_PriceContainerWater1.Text = price
            Else
                Txt_PriceContainerWater.Text = "0"
                Txt_PriceContainerWater1.Text = "0"
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadPriceData2()
        Dim query As String = "SELECT RegContainer FROM Price"
        Dim adapter As New SqlDataAdapter(query, conn)
        Dim dt As New DataTable()

        Try
            conn.Open()
            adapter.Fill(dt)

            ' Siguraduhing may laman ang DataTable bago gamitin ang unang row.
            If dt.Rows.Count > 0 Then
                ' Kunin ang unang row at unang column na laman.
                Dim price As String = dt.Rows(0)(0).ToString()

                ' Ipakita ang resulta sa Txt_PriceGallon.Text.
                Txt_PriceContainer.Text = price
                Txt_PriceContainer1.Text = price
            Else
                Txt_PriceContainer.Text = "0"
                Txt_PriceContainer1.Text = "0"
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    'Small Gallons
    Private Sub LoadPriceData3()
        Dim query As String = "SELECT SmallWaterGallon FROM Price"
        Dim adapter As New SqlDataAdapter(query, conn)
        Dim dt As New DataTable()

        Try
            conn.Open()
            adapter.Fill(dt)

            ' Siguraduhing may laman ang DataTable bago gamitin ang unang row.
            If dt.Rows.Count > 0 Then
                ' Kunin ang unang row at unang column na laman.
                Dim price As String = dt.Rows(0)(0).ToString()

                ' Ipakita ang resulta sa Txt_PriceGallon.Text.
                Txt_PriceSmallGallon.Text = price
            Else
                Txt_PriceSmallGallon.Text = "0"
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadPriceData4()
        Dim query As String = "SELECT SmallContainerwithWater FROM Price"
        Dim adapter As New SqlDataAdapter(query, conn)
        Dim dt As New DataTable()

        Try
            conn.Open()
            adapter.Fill(dt)

            ' Siguraduhing may laman ang DataTable bago gamitin ang unang row.
            If dt.Rows.Count > 0 Then
                ' Kunin ang unang row at unang column na laman.
                Dim price As String = dt.Rows(0)(0).ToString()

                ' Ipakita ang resulta sa Txt_PriceGallon.Text.
                Txt_PriceSmallContainerWater.Text = price
            Else
                Txt_PriceSmallContainerWater.Text = "0"
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub LoadPriceData5()
        Dim query As String = "SELECT SmallContainer FROM Price"
        Dim adapter As New SqlDataAdapter(query, conn)
        Dim dt As New DataTable()

        Try
            conn.Open()
            adapter.Fill(dt)

            ' Siguraduhing may laman ang DataTable bago gamitin ang unang row.
            If dt.Rows.Count > 0 Then
                ' Kunin ang unang row at unang column na laman.
                Dim price As String = dt.Rows(0)(0).ToString()

                ' Ipakita ang resulta sa Txt_PriceGallon.Text.
                Txt_PriceSmallContainer.Text = price
            Else
                Txt_PriceSmallContainer.Text = "0"
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub Btn_Calculation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Calculation.Click
        Me.Hide()
        SalaryAndIncome.Show()
        SalaryAndIncome.TabControl1.SelectedIndex = 0

        Btn_Edit.Visible = True
        Btn_Save.Visible = False
        Btn_EditPrice.Visible = False
        Btn_AddGallon.Visible = False
    End Sub

    Private Sub Btn_Bills_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Bills.Click
        Me.Hide()
        WaterElectricBills.Show()

        Btn_Edit.Visible = True
        Btn_Save.Visible = False
        Btn_EditPrice.Visible = False
        Btn_AddGallon.Visible = False
    End Sub

    Private Sub Btn_EmployeeInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_EmployeeInfo.Click
        Me.Hide()
        EmployeeInfo.Show()

        Btn_Edit.Visible = True
        Btn_Save.Visible = False
        Btn_EditPrice.Visible = False
        Btn_AddGallon.Visible = False
    End Sub

    Private Sub Btn_Reports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Reports.Click
        Me.Hide()
        Reports.Show()
        Reports.TabControl1.SelectedIndex = 0

        Btn_Edit.Visible = True
        Btn_Save.Visible = False
        Btn_EditPrice.Visible = False
        Btn_AddGallon.Visible = False
    End Sub

    Private Sub Btn_Recycle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Recycle.Click
        Me.Hide()
        RecycleBin.Show()
        RecycleBin.TabControl1.SelectedIndex = 0

        Btn_Edit.Visible = True
        Btn_Save.Visible = False
        Btn_EditPrice.Visible = False
        Btn_AddGallon.Visible = False
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Txt_Time.Text = Date.Now.ToString("MMMM-dd-yyyy hh:mm:ss")
        AutoAdjustFont(Txt_Time) ' Dapat ipasa ang Label dito
    End Sub

    Private Sub AutoAdjustFont(ByVal label As Label)
        ' Create a Graphics object to measure the size of the text
        Dim g As Graphics = label.CreateGraphics()
        Dim text As String = label.Text
        Dim fontSize As Single = 20.0F ' Initial font size

        ' Loop to find the best font size
        Dim textSize As SizeF = g.MeasureString(text, New Font(label.Font.FontFamily, fontSize))
        While textSize.Width > label.Width OrElse textSize.Height > label.Height
            fontSize -= 0.5F
            textSize = g.MeasureString(text, New Font(label.Font.FontFamily, fontSize))
        End While

        ' Apply the new font size
        label.Font = New Font(label.Font.FontFamily, fontSize)

        ' Dispose the Graphics object to release resources
        g.Dispose()
    End Sub

    Private Sub Btn_UserInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_UserInfo.Click
        Me.Hide()
        UserProfile.Show()
    End Sub

    Private Sub Txt_PriceGallon_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_PriceGallon.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Txt_PriceContainerWater_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_PriceContainerWater.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Txt_PriceContainer_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_PriceContainer.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Btn_Logout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Logout.Click
        Dim _exit As DialogResult = MessageBox.Show("Are you sure you want to Logout", "Logout", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)
        If _exit = vbOK Then
            Login.Show()
            Me.Hide()
            Login.Txt_Username.Focus()
            Login.Txt_Password.UseSystemPasswordChar = True
        End If
    End Sub
    Private Sub Btn_AddGallon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_AddGallon.Click
        ' Display a confirmation message box
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to add a gallon?", _
                                                      "Confirmation", _
                                                      MessageBoxButtons.YesNo, _
                                                      MessageBoxIcon.Question)

        ' If the user selects Yes, proceed with the process
        If result = DialogResult.Yes Then
            Panel_Form1.Visible = False
            Panel_Form2.Visible = True

            SalaryAndIncome.Label26.Visible = True
            SalaryAndIncome.Label15.Visible = True
            SalaryAndIncome.Label16.Visible = True

            SalaryAndIncome.Txt_SmallWaterRefill.Clear()
            SalaryAndIncome.Txt_SmallContainerWater.Clear()
            SalaryAndIncome.Txt_SmallContainer.Clear()

            SalaryAndIncome.Txt_SmallWaterRefill.Visible = True
            SalaryAndIncome.Txt_SmallContainerWater.Visible = True
            SalaryAndIncome.Txt_SmallContainer.Visible = True

            ' Save the settings state
            My.Settings.ShowSalaryAndIncome = True
            My.Settings.Save()
        End If
    End Sub

    Private Sub Btn_Edit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Edit.Click
        Btn_Edit.Visible = False
        Btn_EditPrice.Visible = True
        Btn_AddGallon.Visible = True

        ' Alisin ang focus sa kahit anong control (hindi agad mafo-focus ang textbox)
        Me.ActiveControl = Nothing
    End Sub

    Private Sub Btn_EditPrice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_EditPrice.Click
        ' Disable the TextBox.
        Txt_PriceGallon.ReadOnly = False
        Txt_PriceGallon.Focus()

        Txt_PriceContainer.ReadOnly = False
        Txt_PriceContainerWater.ReadOnly = False


        Txt_PriceGallon.Cursor = Cursors.IBeam
        Txt_PriceContainer.Cursor = Cursors.IBeam
        Txt_PriceContainerWater.Cursor = Cursors.IBeam

        ' Hide the Btn_EditPrice button.
        Btn_EditPrice.Visible = False
        Btn_Save.Visible = True
        Btn_AddGallon.Visible = True


    End Sub

    Private Sub Btn_EditPrice1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_EditPrice1.Click
        ' Disable the TextBox.
        Txt_PriceGallon1.ReadOnly = False
        Txt_PriceGallon1.Focus()

        Txt_PriceContainer1.ReadOnly = False
        Txt_PriceContainerWater1.ReadOnly = False

        Txt_PriceSmallGallon.ReadOnly = False
        Txt_PriceSmallContainerWater.ReadOnly = False
        Txt_PriceSmallContainer.ReadOnly = False


        Txt_PriceGallon1.Cursor = Cursors.IBeam
        Txt_PriceContainer1.Cursor = Cursors.IBeam
        Txt_PriceContainerWater1.Cursor = Cursors.IBeam

        Txt_PriceSmallGallon.Cursor = Cursors.IBeam
        Txt_PriceSmallContainerWater.Cursor = Cursors.IBeam
        Txt_PriceSmallContainer.Cursor = Cursors.IBeam

        ' Hide the Btn_EditPrice button.
        Btn_EditPrice1.Visible = False
        Btn_Save1.Visible = True
        Btn_Change.Visible = False
    End Sub
    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        ' Check if any of the input fields are empty
        If String.IsNullOrEmpty(Txt_PriceGallon.Text) OrElse String.IsNullOrEmpty(Txt_PriceContainerWater.Text) OrElse String.IsNullOrEmpty(Txt_PriceContainer.Text) Then
            MessageBox.Show("Please input all price values.", "Incomplete fields", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return ' Exit the method if any input field is empty
        End If

        ' Convert input prices to decimals
        Dim priceGallon As Decimal = Decimal.Parse(Txt_PriceGallon.Text)
        Dim priceContainerWater As Decimal = Decimal.Parse(Txt_PriceContainerWater.Text)
        Dim priceContainer As Decimal = Decimal.Parse(Txt_PriceContainer.Text)

        ' Check if any of the prices are zero
        If priceGallon = 0 OrElse priceContainerWater = 0 OrElse priceContainer = 0 Then
            MessageBox.Show("Prices cannot be zero.", "Invalid prices", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return ' Exit the method if any price is zero
        End If

        Try
            conn.Open()

            ' Update the Water Refill Gallon price.
            Dim updateQueryGallon As String = "UPDATE Price SET RegWaterGallon = @RegWaterGallon"
            Dim cmdGallon As New SqlCommand(updateQueryGallon, conn)
            cmdGallon.Parameters.AddWithValue("@RegWaterGallon", priceGallon)
            cmdGallon.ExecuteNonQuery()

            ' Update the Container With Water price.
            Dim updateQueryContainerWater As String = "UPDATE Price SET RegContainerwithWater = @RegContainerwithWater"
            Dim cmdContainerWater As New SqlCommand(updateQueryContainerWater, conn)
            cmdContainerWater.Parameters.AddWithValue("@RegContainerwithWater", priceContainerWater)
            cmdContainerWater.ExecuteNonQuery()

            ' Update the Container price.
            Dim updateQueryContainer As String = "UPDATE Price SET RegContainer = @RegContainer"
            Dim cmdContainer As New SqlCommand(updateQueryContainer, conn)
            cmdContainer.Parameters.AddWithValue("@RegContainer", priceContainer)
            cmdContainer.ExecuteNonQuery()

            MessageBox.Show("Data updated successfully.", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Hide the Btn_EditPrice after the update.
            Btn_Edit.Visible = True
            Btn_Save.Visible = False
            Btn_AddGallon.Visible = False

            Txt_PriceGallon.Cursor = Cursors.Arrow
            Txt_PriceContainer.Cursor = Cursors.Arrow
            Txt_PriceContainerWater.Cursor = Cursors.Arrow

            Txt_PriceGallon.ReadOnly = True
            Txt_PriceContainerWater.ReadOnly = True
            Txt_PriceContainer.ReadOnly = True
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()

            'Prices of Regular Gallons
            LoadPriceData()
            LoadPriceData1()
            LoadPriceData2()

            'Prices of Small Gallons
            LoadPriceData3()
            LoadPriceData4()
            LoadPriceData5()
        End Try
    End Sub
    Private Sub Btn_Save1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save1.Click
        ' Tiyakin na walang textbox na walang laman - gamit ang tamang mga control
        If String.IsNullOrEmpty(Txt_PriceGallon1.Text) OrElse _
           String.IsNullOrEmpty(Txt_PriceContainerWater1.Text) OrElse _
           String.IsNullOrEmpty(Txt_PriceContainer1.Text) OrElse _
           String.IsNullOrEmpty(Txt_PriceSmallGallon.Text) OrElse _
           String.IsNullOrEmpty(Txt_PriceSmallContainerWater.Text) OrElse _
           String.IsNullOrEmpty(Txt_PriceSmallContainer.Text) Then

            MessageBox.Show("Please input all price values.", "Incomplete Fields", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return ' Exit kung may kulang
        End If

        ' I-convert ang input sa decimal gamit ang tamang mga textbox
        Dim priceGallon As Decimal = Decimal.Parse(Txt_PriceGallon1.Text)
        Dim priceContainerWater As Decimal = Decimal.Parse(Txt_PriceContainerWater1.Text)
        Dim priceContainer As Decimal = Decimal.Parse(Txt_PriceContainer1.Text)
        Dim priceSmallGallon As Decimal = Decimal.Parse(Txt_PriceSmallGallon.Text)
        Dim priceSmallContainerWater As Decimal = Decimal.Parse(Txt_PriceSmallContainerWater.Text)
        Dim priceSmallContainer As Decimal = Decimal.Parse(Txt_PriceSmallContainer.Text)

        ' Siguraduhing walang presyo na zero
        If priceGallon = 0 OrElse priceContainerWater = 0 OrElse priceContainer = 0 OrElse _
           priceSmallGallon = 0 OrElse priceSmallContainerWater = 0 OrElse priceSmallContainer = 0 Then
            MessageBox.Show("Prices cannot be zero.", "Invalid Prices", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Try
            conn.Open()

            ' Gamitin ang isang update query para i-update lahat ng fields
            Dim updateQuery As String = "UPDATE Price SET " & _
                "RegWaterGallon = @RegWaterGallon, " & _
                "RegContainerwithWater = @RegContainerwithWater, " & _
                "RegContainer = @RegContainer, " & _
                "SmallWaterGallon = @SmallWaterGallon, " & _
                "SmallContainerwithWater = @SmallContainerwithWater, " & _
                "SmallContainer = @SmallContainer"

            Dim cmd As New SqlCommand(updateQuery, conn)
            cmd.Parameters.AddWithValue("@RegWaterGallon", priceGallon)
            cmd.Parameters.AddWithValue("@RegContainerwithWater", priceContainerWater)
            cmd.Parameters.AddWithValue("@RegContainer", priceContainer)
            cmd.Parameters.AddWithValue("@SmallWaterGallon", priceSmallGallon)
            cmd.Parameters.AddWithValue("@SmallContainerwithWater", priceSmallContainerWater)
            cmd.Parameters.AddWithValue("@SmallContainer", priceSmallContainer)

            cmd.ExecuteNonQuery()

            MessageBox.Show("Data updated successfully.", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' I-update ang visibility ng mga button gaya ng dati
            Btn_EditPrice1.Visible = True
            Btn_Change.Visible = True
            Btn_Save1.Visible = False

            Txt_PriceGallon1.Cursor = Cursors.Arrow
            Txt_PriceContainer1.Cursor = Cursors.Arrow
            Txt_PriceContainerWater1.Cursor = Cursors.Arrow

            Txt_PriceSmallGallon.Cursor = Cursors.Arrow
            Txt_PriceSmallContainerWater.Cursor = Cursors.Arrow
            Txt_PriceSmallContainer.Cursor = Cursors.Arrow

            Txt_PriceGallon1.ReadOnly = True
            Txt_PriceContainerWater1.ReadOnly = True
            Txt_PriceContainer1.ReadOnly = True

            Txt_PriceSmallGallon.ReadOnly = True
            Txt_PriceSmallContainerWater.ReadOnly = True
            Txt_PriceSmallContainer.ReadOnly = True
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()

            'Prices of Regular Gallons
            LoadPriceData()
            LoadPriceData1()
            LoadPriceData2()

            'Prices of Small Gallons
            LoadPriceData3()
            LoadPriceData4()
            LoadPriceData5()
        End Try
    End Sub

    Private Sub Btn_Change_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Change.Click
        ' Display a confirmation message box
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to proceed with the changes?", _
                                                      "Confirmation", _
                                                      MessageBoxButtons.YesNo, _
                                                      MessageBoxIcon.Question)

        ' If the user chooses Yes, proceed with the process
        If result = DialogResult.Yes Then
            Panel_Form1.Visible = True
            Panel_Form2.Visible = False

            SalaryAndIncome.Label26.Visible = False
            SalaryAndIncome.Label15.Visible = False
            SalaryAndIncome.Label16.Visible = False

            SalaryAndIncome.Txt_SmallWaterRefill.Text = "0"
            SalaryAndIncome.Txt_SmallContainerWater.Text = "0"
            SalaryAndIncome.Txt_SmallContainer.Text = "0"

            SalaryAndIncome.Txt_SmallWaterRefill.Visible = False
            SalaryAndIncome.Txt_SmallContainerWater.Visible = False
            SalaryAndIncome.Txt_SmallContainer.Visible = False

            ' Save the settings state
            My.Settings.ShowSalaryAndIncome = False
            My.Settings.Save()
        End If
    End Sub

    Private Sub Txt_PriceGallon1_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_PriceGallon1.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub
    Private Sub Txt_PriceSmallGallon_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_PriceSmallGallon.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Txt_PriceContainerWater1_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_PriceContainerWater1.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Txt_PriceSmallContainerWater_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_PriceSmallContainerWater.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Txt_PriceContainer1_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_PriceContainer1.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Txt_PriceSmallContainer_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_PriceSmallContainer.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
        'Limit to 4 digits
        If Not Char.IsControl(e.KeyChar) AndAlso txt.TextLength >= 4 AndAlso txt.SelectionLength = 0 Then
            e.Handled = True
            Return
        End If
    End Sub

    Private Sub Txt_PriceGallon1_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PriceGallon1.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            Btn_Save1_Click(sender, e)
        End If
    End Sub
    Private Sub Txt_PriceSmallGallon_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PriceSmallGallon.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            Btn_Save1_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_PriceContainerWater1_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PriceContainerWater1.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            Btn_Save1_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_PriceSmallContainerWater_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PriceSmallContainerWater.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            Btn_Save1_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_PriceContainer1_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PriceContainer1.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            Btn_Save1_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_PriceSmallContainer_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PriceSmallContainer.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            Btn_Save1_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_PriceGallon_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PriceGallon.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            Btn_Save_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_PriceContainerWater_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PriceContainerWater.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            Btn_Save_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_PriceContainer_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PriceContainer.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True
            Btn_Save_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_PriceGallon_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Txt_PriceGallon.MouseDown
        If Txt_PriceGallon.ReadOnly Then
            ' Ibalik ang focus sa form (o sa ibang control) para hindi ma‑focus ang textbox
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub Txt_PriceContainerWater_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Txt_PriceContainerWater.MouseDown
        If Txt_PriceContainerWater.ReadOnly Then
            ' Ibalik ang focus sa form (o sa ibang control) para hindi ma‑focus ang textbox
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub Txt_PriceContainer_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Txt_PriceContainer.MouseDown
        If Txt_PriceContainer.ReadOnly Then
            ' Ibalik ang focus sa form (o sa ibang control) para hindi ma‑focus ang textbox
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub Txt_PriceGallon1_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Txt_PriceGallon1.MouseDown
        If Txt_PriceGallon1.ReadOnly Then
            ' Ibalik ang focus sa form (o sa ibang control) para hindi ma‑focus ang textbox
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub Txt_PriceSmallGallon_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Txt_PriceSmallGallon.MouseDown
        If Txt_PriceSmallGallon.ReadOnly Then
            ' Ibalik ang focus sa form (o sa ibang control) para hindi ma‑focus ang textbox
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub Txt_PriceContainerWater1_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Txt_PriceContainerWater1.MouseDown
        If Txt_PriceContainerWater1.ReadOnly Then
            ' Ibalik ang focus sa form (o sa ibang control) para hindi ma‑focus ang textbox
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub Txt_PriceSmallContainerWater_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Txt_PriceSmallContainerWater.MouseDown
        If Txt_PriceSmallContainerWater.ReadOnly Then
            ' Ibalik ang focus sa form (o sa ibang control) para hindi ma‑focus ang textbox
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub Txt_PriceContainer1_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Txt_PriceContainer1.MouseDown
        If Txt_PriceContainer1.ReadOnly Then
            ' Ibalik ang focus sa form (o sa ibang control) para hindi ma‑focus ang textbox
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub Txt_PriceSmallContainer_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Txt_PriceSmallContainer.MouseDown
        If Txt_PriceSmallContainer.ReadOnly Then
            ' Ibalik ang focus sa form (o sa ibang control) para hindi ma‑focus ang textbox
            Me.ActiveControl = Nothing
        End If
    End Sub
End Class