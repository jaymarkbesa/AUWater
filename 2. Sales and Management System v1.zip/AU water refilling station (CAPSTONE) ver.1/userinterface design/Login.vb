﻿Imports System.Data.SqlClient
Public Class Login
    Dim connectionString As String = "Data Source=LAPTOP-E6UDS97D\SQLEXPRESS;Initial Catalog=Au Water Refilling Station;Integrated Security=True"
    Dim conn As New SqlConnection(connectionString)

    Private Sub Btn_Login_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Login.Click
        Dim username As String = Txt_Username.Text
        Dim password As String = Txt_Password.Text

        ' Check if the username is empty
        If String.IsNullOrWhiteSpace(username) Then
            MessageBox.Show("Please enter a username.", "Incomplete Field", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return ' Exit the method if the username is empty
        End If
        If String.IsNullOrWhiteSpace(password) Then
            MessageBox.Show("Please enter a password.", "Incomplete Field", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return ' Exit the method if the username is empty
        End If
        ' Validate the username and password from the database
        If ValidateUser(username, password) Then
            MessageBox.Show("Login Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Hide()
            Dim dashboardForm As New Home()
            Home.Show()
            Txt_Password.Clear()
            Txt_Username.Clear()
            Txt_Username.Focus()
        Else
            ' If not valid, show an error message or take appropriate action
            MessageBox.Show("Invalid username or password", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Txt_Password.Clear()
            Txt_Username.Clear()
            Txt_Username.Focus()
        End If
    End Sub
    Private Function ValidateUser(ByVal username As String, ByVal password As String) As Boolean
        Try
            Using connection As New SqlConnection(connectionString)
                connection.Open()

                ' Gumamit ng parameterized query at i-enforce ang case sensitivity gamit ang COLLATE clause
                Dim query As String = "SELECT COUNT(*) FROM Login WHERE Username COLLATE Latin1_General_CS_AS = @Username AND Password COLLATE Latin1_General_CS_AS = @Password"
                Using command As New SqlCommand(query, connection)
                    command.Parameters.AddWithValue("@Username", username)
                    command.Parameters.AddWithValue("@Password", password)

                    ' ExecuteScalar returns the number of rows matching the criteria
                    Dim count As Integer = Convert.ToInt32(command.ExecuteScalar())

                    ' Kung count ay higit sa 0, valid ang user
                    Return count > 0
                End Using
            End Using
        Catch ex As Exception
            ' I-handle ang exceptions, hal. ipakita ang error message
            MessageBox.Show("An error occurred while validating user: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Sub Btn_ShowPass_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ShowPass.Click
        If Txt_Password.UseSystemPasswordChar = True Then
            Txt_Password.UseSystemPasswordChar = False

        Else
            Txt_Password.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub Btn_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Exit.Click
        Dim _exit As DialogResult = MessageBox.Show("Are you sure you want to Exit", "Exit", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)
        If _exit = vbOK Then
            Application.Exit()
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Dim forgetPassword As New ForgetPassword()

        ' Show the ForgetPasswordForm
        forgetPassword.Show()

        ' Optionally, you can hide the current form if needed
        Me.Hide()
        Txt_Password.Clear()
        Txt_Username.Clear()
    End Sub

    Private Sub Txt_Username_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Username.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True ' Suppress the Enter key press
            Txt_Password.Focus() ' Move focus to the next control (txtPass)
        End If
    End Sub

    Private Sub Txt_Password_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Password.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True ' Suppress the Enter key press
            Btn_Login_Click(sender, e) ' Trigger the login button click event
        End If
    End Sub

    Private Sub Login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
