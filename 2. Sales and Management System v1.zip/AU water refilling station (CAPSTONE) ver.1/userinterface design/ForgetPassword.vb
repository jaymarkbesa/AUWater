﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Net
Imports System.Net.Mail
Public Class ForgetPassword
    Dim Username As String = "mail.org.noreply@gmail.com"
    Dim Password As String = "lzen zabl fdpj kbku"
    Dim connectionString As String = "Data Source=LAPTOP-E6UDS97D\SQLEXPRESS;Initial Catalog=Au Water Refilling Station;Integrated Security=True"
    Dim conn As New SqlConnection(connectionString)
    Private Function IsValidEmail(ByVal email As String) As Boolean
        ' Regular expression pattern for validating email format
        Dim pattern As String = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        Return System.Text.RegularExpressions.Regex.IsMatch(email, pattern)
    End Function
    Private Sub Btn_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        Me.Hide()
        Login.Show()
    End Sub
    Private Sub Txt_Gmail_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Gmail.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True ' Suppress the Enter key press
            Btn_Confirm_Click(sender, e) ' Trigger the login button click event
        End If
    End Sub
   Private Sub Btn_Confirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Confirm.Click
        Try
            ' Check if the Gmail format is valid
            If Not IsValidEmail(Txt_Gmail.Text) Then
                MessageBox.Show("Please enter a valid email address.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Gmail.Clear()
                Txt_Gmail.Focus()
                Exit Sub
            End If

            ' Create a new connection using the class-level connectionString
            Dim conn As New SqlConnection(connectionString)

            Dim query As String = "SELECT UserInfo.Gmail, Login.Username, Login.Password " & _
                                  "FROM UserInfo INNER JOIN Login ON UserInfo.UserID = Login.ID " & _
                                  "WHERE UserInfo.Gmail = @Gmail"
            Dim cmd As New SqlCommand(query, conn)
            cmd.Parameters.Add("@Gmail", SqlDbType.NVarChar).Value = Txt_Gmail.Text

            Dim da As New SqlDataAdapter(cmd)
            Dim dt As New DataTable
            da.Fill(dt)

            ' Check if there is any data returned
            If dt.Rows.Count > 0 Then
                Txt_Username.Text = dt.Rows(0)(1).ToString()  ' Username column
                Txt_Password.Text = dt.Rows(0)(2).ToString()  ' Password column
            Else
                MessageBox.Show("The email address you entered is not registered in the user profile.", _
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Gmail.Clear()
                Txt_Gmail.Focus()
                Exit Sub
            End If

            ' Email sending logic
            Dim smtp As New SmtpClient
            smtp.UseDefaultCredentials = False
            Dim smtpUsername As String = "mail.org.noreply@gmail.com"
            Dim smtpPassword As String = "lzen zabl fdpj kbku"
            smtp.Credentials = New Net.NetworkCredential(smtpUsername, smtpPassword)
            smtp.Port = 587
            smtp.EnableSsl = True
            smtp.Host = "smtp.gmail.com"

            Dim mail As New MailMessage
            mail.From = New MailAddress("mail.org.noreply@gmail.com", "Au Water Refilling Station")
            mail.To.Add(Txt_Gmail.Text)
            mail.Subject = "Password Recovery"
            mail.Body = "Hi " & Txt_Username.Text & ",<br/><br/>" & _
                        "We sent you this email in response to your request, " & _
                        "your password for Au Water Refilling Station. <br/><br/>" & _
                        "Your Username is: " & Txt_Username.Text & "<br/><br/>" & _
                        "Your Password is: " & Txt_Password.Text & "<br/><br/>" & _
                        "THANK YOU!"
            mail.IsBodyHtml = True

            smtp.Send(mail)

            MessageBox.Show("Your request was successfully sent. Please check your email.", _
                            "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Txt_Gmail.Clear()
            Login.Show()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class