﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Configuration
Public Class RecycleBin
    Dim connectionString As String = ConfigurationManager.ConnectionStrings("MyDB").ConnectionString
    Dim conn As New SqlConnection(connectionString)
    Dim cmd As SqlCommand
    Dim adapter As SqlDataAdapter
    Dim dt As DataTable
    Private Sub RecycleBin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Tab 2
        LoadMonths()
        LoadYears()

        RefreshDataGridView2SoldBackup()
        DataGridView2.ClearSelection()

        'Tab 3
        LoadMonths1()
        LoadYears1()

        RefreshDataGridView3()
        DataGridView3.ClearSelection()

        'Tab 4
        LoadMonths2()
        LoadYears2()

        RefreshDataGridView4()
        DataGridView4.ClearSelection()

        'Tab 5
        LoadMonths3()
        LoadYears3()

        RefreshDataGridView5()
        DataGridView5.ClearSelection()

        'Tab 6
        LoadMonths4()
        LoadYears4()

        RefreshDataGridView6()
        DataGridView6.ClearSelection()
    End Sub
    Private Sub Btn_Home_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Home.Click
        Me.Hide()
        Home.Show()
        Txt_Search1.Clear()
        Txt_Search2.Clear()
        Txt_Search3.Clear()
        Txt_Search4.Clear()
        Txt_Search5.Clear()
    End Sub

    Private Sub Btn_Bills_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Bills.Click
        Me.Hide()
        WaterElectricBills.Show()
        WaterElectricBills.DataGridView1.ClearSelection()
        Txt_Search1.Clear()
        Txt_Search2.Clear()
        Txt_Search3.Clear()
        Txt_Search4.Clear()
        Txt_Search5.Clear()
    End Sub

    Private Sub Btn_EmployeeInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_EmployeeInfo.Click
        Me.Hide()
        EmployeeInfo.Show()
        EmployeeInfo.DataGridView1.ClearSelection()
        Txt_Search1.Clear()
        Txt_Search2.Clear()
        Txt_Search3.Clear()
        Txt_Search4.Clear()
        Txt_Search5.Clear()
    End Sub

    Private Sub Btn_Reports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Reports.Click
        Me.Hide()
        Reports.Show()
        Reports.TabControl1.SelectedIndex = 0
        Txt_Search1.Clear()
        Txt_Search2.Clear()
        Txt_Search3.Clear()
        Txt_Search4.Clear()
        Txt_Search5.Clear()
    End Sub

    Private Sub Btn_Calculation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Calculation.Click
        Me.Hide()
        SalaryAndIncome.Show()
        SalaryAndIncome.TabControl1.SelectedIndex = 0
        SalaryAndIncome.DataGridView1.ClearSelection()
        Txt_Search1.Clear()
        Txt_Search2.Clear()
        Txt_Search3.Clear()
        Txt_Search4.Clear()
        Txt_Search5.Clear()
    End Sub
    'Tab 2
    Private Sub Btn_Refresh1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh1.Click
        Cb_Month1.SelectedIndex = 0
        Cb_Year1.SelectedIndex = 0
        Txt_Search1.Clear()
        RefreshDataGridView2SoldBackup()
        DataGridView2.ClearSelection()
    End Sub

    Private Sub Txt_Search1_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Search1.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        ' Limit the length of the text to 11 characters
        If Txt_Search1.TextLength >= 11 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    ' --------------------------
    ' Event Handlers para sa Tab2
    ' --------------------------
    Private Sub Cb_Month1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Month1.SelectedIndexChanged
        RefreshDataGridView2SoldBackup()
    End Sub

    Private Sub Cb_Year1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Year1.SelectedIndexChanged
        RefreshDataGridView2SoldBackup()
    End Sub

    Private Sub Txt_Search1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Search1.TextChanged
        RefreshDataGridView2SoldBackup()
    End Sub

    ' --------------------------
    ' Function para i-load ang listahan ng Months (January - December)
    ' --------------------------
    Private Sub LoadMonths()
        Cb_Month1.Items.Clear()
        Cb_Month1.Items.Add("All") ' Default option

        Dim monthNames() As String = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        }

        For Each month As String In monthNames
            Cb_Month1.Items.Add(month)
        Next

        Cb_Month1.SelectedIndex = 0 ' Default select "All"
    End Sub

    ' --------------------------
    ' Function para i-load ang listahan ng Years (Fixed mula 2024 hanggang 2050)
    ' --------------------------
    Private Sub LoadYears()
        Dim startYear As Integer = 2024 ' Fixed start year
        Dim endYear As Integer = 2050   ' Fixed end year

        Try
            Cb_Year1.Items.Clear()
            Cb_Year1.Items.Add("All") ' Default option

            For year As Integer = startYear To endYear
                Cb_Year1.Items.Add(year.ToString())
            Next

            Cb_Year1.SelectedIndex = 0 ' Default select "All"

        Catch ex As Exception
            MessageBox.Show("Error loading years: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' --------------------------
    ' Function para i-refresh ang DataGridView para sa SoldBackup (Tab2)
    ' --------------------------
    Private Sub RefreshDataGridView2SoldBackup()
        Try
            ' Simulang query na may WHERE clause para madaling maidagdag ang filters
            Dim query As String = "SELECT ID, RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                  "SmallWaterGallon, SmallContainerwithWater, SmallContainer, Date " & _
                                  "FROM SoldBackup WHERE 1=1"

            ' ✅ Search Filter gamit ang mga aktwal na columns ng SoldBackup
            Dim searchKeyword As String = Txt_Search1.Text.Trim()
            If Not String.IsNullOrEmpty(searchKeyword) Then
                query &= " AND (" & _
                         "CAST(ID AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegWaterGallon AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegContainerwithWater AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegContainer AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallWaterGallon AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallContainerwithWater AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallContainer AS NVARCHAR(50)) LIKE @Search" & _
                         ")"
            End If

            ' ✅ Month Filtering (convert month name to number)
            Dim selectedMonth As String = "All"
            Dim monthNumber As Integer = 0 ' Default value

            If Cb_Month1.SelectedItem IsNot Nothing Then
                selectedMonth = Cb_Month1.SelectedItem.ToString()
            End If

            If selectedMonth <> "All" Then
                monthNumber = Array.IndexOf(
                    New String() {"January", "February", "March", "April", "May", "June", _
                                  "July", "August", "September", "October", "November", "December"}, _
                    selectedMonth) + 1
                query &= " AND MONTH(Date) = @Month"
            End If

            ' ✅ Year Filtering
            Dim selectedYear As String = "All"
            If Cb_Year1.SelectedItem IsNot Nothing Then
                selectedYear = Cb_Year1.SelectedItem.ToString()
            End If

            If selectedYear <> "All" Then
                query &= " AND YEAR(Date) = @Year"
            End If

            ' ✅ Sorting by Date (ascending order)
            query &= " ORDER BY Date ASC"

            Dim dt As New DataTable()

            ' Gamitin ang Using block para sa tamang disposal ng connection
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    If Not String.IsNullOrEmpty(searchKeyword) Then
                        cmd.Parameters.AddWithValue("@Search", "%" & searchKeyword & "%")
                    End If

                    If selectedMonth <> "All" Then
                        cmd.Parameters.AddWithValue("@Month", monthNumber)
                    End If

                    If selectedYear <> "All" Then
                        cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(selectedYear))
                    End If

                    conn.Open()
                    Dim adapter As New SqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using

            ' I-bind ang nakuha na data sa DataGridView
            DataGridView2.DataSource = dt

            ' Ayusin ang Header Text para sa mga columns
            DataGridView2.Columns("RegWaterGallon").HeaderText = "Reg Water Gallon"
            DataGridView2.Columns("RegContainerwithWater").HeaderText = "Reg Container with Water"
            DataGridView2.Columns("RegContainer").HeaderText = "Reg Container"
            DataGridView2.Columns("SmallWaterGallon").HeaderText = "Small Water Gallon"
            DataGridView2.Columns("SmallContainerwithWater").HeaderText = "Small Container with Water"
            DataGridView2.Columns("SmallContainer").HeaderText = "Small Container"

            ' I-center ang laman ng bawat column at i-format ang Date column
            For Each col As DataGridViewColumn In DataGridView2.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                If col.Name = "Date" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next

            DataGridView2.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error refreshing data grid: " & ex.Message)
        End Try
    End Sub

   Private Sub Btn_Restore1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Restore1.Click
        ' Retrieve prices for both regular and small fields
        Dim waterRefillGallonPrice, containerWithWaterPrice, containerPrice As Integer
        Dim smallWaterGallonPrice, smallContainerWithWaterPrice, smallContainerPrice As Integer

        Using conn As New SqlConnection(connectionString)
            conn.Open()
            Dim priceQuery As String = "SELECT RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                       "SmallWaterGallon, SmallContainerwithWater, SmallContainer FROM Price"
            Using cmd As New SqlCommand(priceQuery, conn)
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    If reader.Read() Then
                        waterRefillGallonPrice = reader.GetInt32(0)
                        containerWithWaterPrice = reader.GetInt32(1)
                        containerPrice = reader.GetInt32(2)
                        smallWaterGallonPrice = reader.GetInt32(3)
                        smallContainerWithWaterPrice = reader.GetInt32(4)
                        smallContainerPrice = reader.GetInt32(5)
                    Else
                        MessageBox.Show("Prices not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return
                    End If
                End Using
            End Using
        End Using

        Try
            ' Check if at least one row is selected in DataGridView2
            If DataGridView2.SelectedRows.Count = 0 Then
                MessageBox.Show("Please select at least one row to restore.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            Using soldConn As New SqlConnection(connectionString)
                soldConn.Open()

                ' Begin transaction
                Using transaction As SqlTransaction = soldConn.BeginTransaction()
                    Try
                        Dim insertedRecordsCount As Integer = 0 ' Counter for inserted records

                        For Each selectedRow As DataGridViewRow In DataGridView2.SelectedRows
                            ' Retrieve backup data (regular and small fields)
                            Dim ID As Integer = Convert.ToInt32(selectedRow.Cells("ID").Value)
                            Dim waterRefillGallon As Integer = Convert.ToInt32(selectedRow.Cells("RegWaterGallon").Value)
                            Dim containerWithWater As Integer = Convert.ToInt32(selectedRow.Cells("RegContainerwithWater").Value)
                            Dim container As Integer = Convert.ToInt32(selectedRow.Cells("RegContainer").Value)
                            Dim smallWaterGallon As Integer = Convert.ToInt32(selectedRow.Cells("SmallWaterGallon").Value)
                            Dim smallContainerWithWater As Integer = Convert.ToInt32(selectedRow.Cells("SmallContainerwithWater").Value)
                            Dim smallContainer As Integer = Convert.ToInt32(selectedRow.Cells("SmallContainer").Value)
                            Dim [Date] As Date = Convert.ToDateTime(selectedRow.Cells("Date").Value)

                            ' Calculate totals using the prices retrieved above
                            Dim waterRefillGallonTotal As Decimal = waterRefillGallon * waterRefillGallonPrice
                            Dim containerWithWaterTotal As Decimal = containerWithWater * containerWithWaterPrice
                            Dim containerTotal As Decimal = container * containerPrice
                            Dim smallWaterGallonTotal As Decimal = smallWaterGallon * smallWaterGallonPrice
                            Dim smallContainerWithWaterTotal As Decimal = smallContainerWithWater * smallContainerWithWaterPrice
                            Dim smallContainerTotal As Decimal = smallContainer * smallContainerPrice

                            Dim total As Decimal = waterRefillGallonTotal + containerWithWaterTotal + containerTotal + _
                                                     smallWaterGallonTotal + smallContainerWithWaterTotal + smallContainerTotal

                            ' Check if the date already exists in the Sold table
                            Dim checkDateQuery As String = "SELECT COUNT(*) FROM Sold WHERE [Date] = @Date"
                            Using checkCmd As New SqlCommand(checkDateQuery, soldConn, transaction)
                                checkCmd.Parameters.AddWithValue("@Date", [Date])
                                Dim dateExists As Integer = Convert.ToInt32(checkCmd.ExecuteScalar())
                                If dateExists > 0 Then
                                    MessageBox.Show(String.Format("The date {0:yyyy-MM-dd} already exists. Skipping this record.", [Date]), "Duplicate Date", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                    Continue For
                                End If
                            End Using

                            ' Insert into Sold table (including small fields)
                            Dim soldQuery As String = "INSERT INTO Sold (RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                                      "SmallWaterGallon, SmallContainerwithWater, SmallContainer, Date) " & _
                                                      "VALUES (@RegWaterGallon, @RegContainerwithWater, @RegContainer, " & _
                                                      "@SmallWaterGallon, @SmallContainerwithWater, @SmallContainer, @Date); SELECT SCOPE_IDENTITY();"
                            Dim soldID As Integer
                            Using cmdSold As New SqlCommand(soldQuery, soldConn, transaction)
                                cmdSold.Parameters.AddWithValue("@RegWaterGallon", waterRefillGallon)
                                cmdSold.Parameters.AddWithValue("@RegContainerwithWater", containerWithWater)
                                cmdSold.Parameters.AddWithValue("@RegContainer", container)
                                cmdSold.Parameters.AddWithValue("@SmallWaterGallon", smallWaterGallon)
                                cmdSold.Parameters.AddWithValue("@SmallContainerwithWater", smallContainerWithWater)
                                cmdSold.Parameters.AddWithValue("@SmallContainer", smallContainer)
                                cmdSold.Parameters.AddWithValue("@Date", [Date])
                                soldID = Convert.ToInt32(cmdSold.ExecuteScalar())
                            End Using

                            ' Insert into Income table (including small fields)
                            Dim incomeQuery As String = "INSERT INTO GrossRevenue (RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                                         "SmallWaterGallon, SmallContainerwithWater, SmallContainer, GrossRevenue, [Date]) " & _
                                                         "VALUES (@RegWaterGallon, @RegContainerwithWater, @RegContainer, " & _
                                                         "@SmallWaterGallon, @SmallContainerwithWater, @SmallContainer, @GrossRevenue, @Date)"
                            Using cmdIncome As New SqlCommand(incomeQuery, soldConn, transaction)
                                cmdIncome.Parameters.AddWithValue("@RegWaterGallon", waterRefillGallonTotal)
                                cmdIncome.Parameters.AddWithValue("@RegContainerwithWater", containerWithWaterTotal)
                                cmdIncome.Parameters.AddWithValue("@RegContainer", containerTotal)
                                cmdIncome.Parameters.AddWithValue("@SmallWaterGallon", smallWaterGallonTotal)
                                cmdIncome.Parameters.AddWithValue("@SmallContainerwithWater", smallContainerWithWaterTotal)
                                cmdIncome.Parameters.AddWithValue("@SmallContainer", smallContainerTotal)
                                cmdIncome.Parameters.AddWithValue("@GrossRevenue", total)
                                cmdIncome.Parameters.AddWithValue("@Date", [Date])
                                cmdIncome.ExecuteNonQuery()
                            End Using

                            ' Delete the restored record from SoldBackup
                            Dim deleteSoldBackupQuery As String = "DELETE FROM SoldBackup WHERE ID = @ID"
                            Using deleteCmd As New SqlCommand(deleteSoldBackupQuery, soldConn, transaction)
                                deleteCmd.Parameters.AddWithValue("@ID", ID)
                                deleteCmd.ExecuteNonQuery()
                            End Using

                            ' Delete the corresponding record from Income Backup
                            Dim deleteIncomeBackupQuery As String = "DELETE FROM GrossRevenueBackup WHERE ID = @ID"
                            Using deleteIncomeCmd As New SqlCommand(deleteIncomeBackupQuery, soldConn, transaction)
                                deleteIncomeCmd.Parameters.AddWithValue("@ID", ID)
                                deleteIncomeCmd.ExecuteNonQuery()
                            End Using

                            ' Increment the counter for successfully inserted records
                            insertedRecordsCount += 1
                        Next

                        ' Commit transaction
                        transaction.Commit()

                        If insertedRecordsCount > 0 Then
                            MessageBox.Show("Selected data restored successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If

                    Catch ex As Exception
                        transaction.Rollback()
                        MessageBox.Show("Error during restore operation: " & ex.Message, "Transaction Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            End Using

            ' Refresh DataGridViews and clear selections
            RefreshDataGridView2SoldBackup()
            RefreshDataGridView1Sold()
            RefreshDataGridView3()
            DataGridView2.ClearSelection()
            DataGridView3.ClearSelection()

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub RefreshDataGridView1Sold()
        Try
            conn.Open()
            Dim query As String = "SELECT ID, RegWaterGallon, RegContainerwithWater, RegContainer, SmallWaterGallon, SmallContainerwithWater, SmallContainer, Date FROM Sold"

            cmd = New SqlCommand(query, conn)
            adapter = New SqlDataAdapter(cmd)
            dt = New DataTable()
            adapter.Fill(dt)

            SalaryAndIncome.DataGridView1.DataSource = dt
            SalaryAndIncome.DataGridView1.Columns("RegWaterGallon").HeaderText = "Reg Water gallon"
            SalaryAndIncome.DataGridView1.Columns("RegContainerwithWater").HeaderText = "Reg Container with Water"
            SalaryAndIncome.DataGridView1.Columns("RegContainer").HeaderText = "Reg Container"

            SalaryAndIncome.DataGridView1.Columns("SmallWaterGallon").HeaderText = "Small Water Gallon"
            SalaryAndIncome.DataGridView1.Columns("SmallContainerwithWater").HeaderText = "Small Container with Water"
            SalaryAndIncome.DataGridView1.Columns("SmallContainer").HeaderText = "Small Container"

            ' Set content alignment for each column
            For Each col As DataGridViewColumn In SalaryAndIncome.DataGridView1.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                ' Check if column is Date column, then format the date to display month name
                If col.Name = "Date" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next

            ' Set row header alignment
            SalaryAndIncome.DataGridView1.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub Btn_Delete1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete1.Click
        ' Ensure at least one row is selected
        If DataGridView2.SelectedRows.Count = 0 Then
            MessageBox.Show("Please select at least one row to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Ask for confirmation before deleting
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete the selected record(s)?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        ' If user clicks 'Yes', proceed with deletion
        If result = DialogResult.Yes Then
            Try
                Using soldConn As New SqlConnection(connectionString)
                    soldConn.Open()

                    ' Begin transaction
                    Using transaction As SqlTransaction = soldConn.BeginTransaction()
                        Try
                            Dim deletedRecordsCount As Integer = 0 ' Counter for deleted records

                            ' Loop through all selected rows and delete
                            For Each selectedRow As DataGridViewRow In DataGridView2.SelectedRows
                                Dim selectedID As Integer = Convert.ToInt32(selectedRow.Cells("ID").Value)

                                ' Delete from the Sold Backup table
                                Dim deleteSoldBackupQuery As String = "DELETE FROM SoldBackup WHERE ID = @ID"
                                Using deleteCmd As New SqlCommand(deleteSoldBackupQuery, soldConn, transaction)
                                    deleteCmd.Parameters.AddWithValue("@ID", selectedID)
                                    deleteCmd.ExecuteNonQuery()
                                End Using

                                ' Delete from the Income Backup table
                                Dim deleteIncomeBackupQuery As String = "DELETE FROM GrossRevenueBackup WHERE ID = @ID"
                                Using deleteIncomeCmd As New SqlCommand(deleteIncomeBackupQuery, soldConn, transaction)
                                    deleteIncomeCmd.Parameters.AddWithValue("@ID", selectedID)
                                    deleteIncomeCmd.ExecuteNonQuery()
                                End Using

                                ' Increment the counter for successfully deleted records
                                deletedRecordsCount += 1
                            Next

                            ' Commit the transaction if all deletions are successful
                            transaction.Commit()

                            ' Show success message if at least one record is deleted
                            If deletedRecordsCount > 0 Then
                                MessageBox.Show("Selected record(s) deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            End If

                            ' Refresh DataGridView and clear selections
                            RefreshDataGridView2SoldBackup()
                            DataGridView2.ClearSelection()

                        Catch ex As Exception
                            ' Rollback transaction if any error occurs
                            transaction.Rollback()
                            MessageBox.Show("Error during deletion: " & ex.Message, "Delete Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
    'Tab 3
    Private Sub Btn_Refresh2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh2.Click

        Cb_Month2.SelectedIndex = 0
        Cb_Year2.SelectedIndex = 0
        Txt_Search2.Clear()
        RefreshDataGridView3()
        DataGridView3.ClearSelection()

    End Sub
    Private Sub Txt_Search2_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Search2.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        ' Limit the length of the text to 11 characters
        If Txt_Search2.TextLength >= 11 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    ' --------------------------
    ' Event Handlers para sa Tab3
    ' --------------------------
    Private Sub Cb_Month2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Month2.SelectedIndexChanged
        RefreshDataGridView3()
    End Sub

    Private Sub Cb_Year2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Year2.SelectedIndexChanged
        RefreshDataGridView3()
    End Sub

    Private Sub Txt_Search2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Search2.TextChanged
        RefreshDataGridView3()
    End Sub

    ' --------------------------
    ' Function para i-load ang listahan ng Months (January - December) para sa Tab3
    ' --------------------------
    Private Sub LoadMonths1()
        Cb_Month2.Items.Clear()
        Cb_Month2.Items.Add("All") ' Default option

        Dim monthNames() As String = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        }

        For Each month As String In monthNames
            Cb_Month2.Items.Add(month)
        Next

        Cb_Month2.SelectedIndex = 0 ' Default select "All"
    End Sub

    ' --------------------------
    ' Function para i-load ang listahan ng Years (2024 - 2050) para sa Tab3
    ' --------------------------
    Private Sub LoadYears1()
        Dim startYear As Integer = 2024
        Dim endYear As Integer = 2050

        Try
            Cb_Year2.Items.Clear()
            Cb_Year2.Items.Add("All") ' Default option

            For year As Integer = startYear To endYear
                Cb_Year2.Items.Add(year.ToString())
            Next

            Cb_Year2.SelectedIndex = 0 ' Default select "All"

        Catch ex As Exception
            MessageBox.Show("Error loading years: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' --------------------------
    ' Function para i-refresh ang DataGridView para sa GrossRevenueBackup (Tab3)
    ' --------------------------
    Private Sub RefreshDataGridView3()
        Try
            ' Base query na may WHERE clause para madaling maidagdag ang filters
            Dim query As String = "SELECT ID, RegWaterGallon, RegContainerwithWater, RegContainer, " & _
                                  "SmallWaterGallon, SmallContainerwithWater, SmallContainer, GrossRevenue, Date " & _
                                  "FROM GrossRevenueBackup WHERE 1=1"

            ' ✅ Search Filter gamit ang mga aktwal na columns ng GrossRevenueBackup
            Dim searchKeyword As String = Txt_Search2.Text.Trim()
            If Not String.IsNullOrEmpty(searchKeyword) Then
                query &= " AND (" & _
                         "CAST(ID AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegWaterGallon AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegContainerwithWater AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegContainer AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallWaterGallon AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallContainerwithWater AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallContainer AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(GrossRevenue AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CONVERT(NVARCHAR(50), Date, 121) LIKE @Search" & _
                         ")"
            End If

            ' ✅ Month Filtering (Convert month name to number)
            Dim selectedMonth As String = "All"
            Dim monthNumber As Integer = 0 ' Default value

            If Cb_Month2.SelectedItem IsNot Nothing Then
                selectedMonth = Cb_Month2.SelectedItem.ToString()
            End If

            If selectedMonth <> "All" Then
                monthNumber = Array.IndexOf( _
                    New String() {"January", "February", "March", "April", "May", "June", _
                                  "July", "August", "September", "October", "November", "December"}, _
                    selectedMonth) + 1
                query &= " AND MONTH(Date) = @Month"
            End If

            ' ✅ Year Filtering
            Dim selectedYear As String = "All"
            If Cb_Year2.SelectedItem IsNot Nothing Then
                selectedYear = Cb_Year2.SelectedItem.ToString()
            End If

            If selectedYear <> "All" Then
                query &= " AND YEAR(Date) = @Year"
            End If

            ' ✅ Sorting by Date (ascending order)
            query &= " ORDER BY Date ASC"

            Dim dt As New DataTable()

            ' Gumamit ng Using block para masiguro ang tamang disposal ng connection
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    If Not String.IsNullOrEmpty(searchKeyword) Then
                        cmd.Parameters.AddWithValue("@Search", "%" & searchKeyword & "%")
                    End If

                    If selectedMonth <> "All" Then
                        cmd.Parameters.AddWithValue("@Month", monthNumber)
                    End If

                    If selectedYear <> "All" Then
                        cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(selectedYear))
                    End If

                    conn.Open()
                    Dim adapter As New SqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using

            ' I-bind ang data sa DataGridView3
            DataGridView3.DataSource = dt

            ' Ayusin ang Header Text para sa clarity
            DataGridView3.Columns("RegWaterGallon").HeaderText = "Reg Water Gallon"
            DataGridView3.Columns("RegContainerwithWater").HeaderText = "Reg Container with Water"
            DataGridView3.Columns("RegContainer").HeaderText = "Reg Container"
            DataGridView3.Columns("SmallWaterGallon").HeaderText = "Small Water Gallon"
            DataGridView3.Columns("SmallContainerwithWater").HeaderText = "Small Container with Water"
            DataGridView3.Columns("SmallContainer").HeaderText = "Small Container"
            DataGridView3.Columns("GrossRevenue").HeaderText = "Gross Revenue"

            ' I-center ang laman ng bawat column at i-format ang Date column
            For Each col As DataGridViewColumn In DataGridView3.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                If col.Name = "Date" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next

            DataGridView3.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error refreshing data grid: " & ex.Message)
        End Try
    End Sub

    ' Tab4
    Private Sub Btn_Refresh3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh3.Click

        Cb_Month3.SelectedIndex = 0
        Cb_Year3.SelectedIndex = 0
        Txt_Search3.Clear()

        RefreshDataGridView4()
        DataGridView4.ClearSelection()

    End Sub
    Private Sub Txt_Search3_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Search3.KeyPress
        ' Limit the length of the text to 11 characters
        If Txt_Search3.TextLength >= 50 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    ' --------------------------
    ' Event Handlers para sa Tab gamit ang Txt_Search3, Cb_Month3, at Cb_Year3
    ' --------------------------
    Private Sub Txt_Search3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Search3.TextChanged
        RefreshDataGridView4()
    End Sub

    Private Sub Cb_Month3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Month3.SelectedIndexChanged
        RefreshDataGridView4()
    End Sub

    Private Sub Cb_Year3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Year3.SelectedIndexChanged
        RefreshDataGridView4()
    End Sub

    ' --------------------------
    ' Function para i-load ang listahan ng Months (January - December) gamit ang Cb_Month3
    ' --------------------------
    Private Sub LoadMonths2()
        Cb_Month3.Items.Clear()
        Cb_Month3.Items.Add("All") ' Default option

        Dim monthNames() As String = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        }

        For Each month As String In monthNames
            Cb_Month3.Items.Add(month)
        Next

        Cb_Month3.SelectedIndex = 0 ' Default select "All"
    End Sub

    ' --------------------------
    ' Function para i-load ang listahan ng Years (2024 - 2050) gamit ang Cb_Year3
    ' --------------------------
    Private Sub LoadYears2()
        Dim startYear As Integer = 2024 ' Fixed start year
        Dim endYear As Integer = 2050   ' Fixed end year

        Try
            Cb_Year3.Items.Clear()
            Cb_Year3.Items.Add("All") ' Default option

            For year As Integer = startYear To endYear
                Cb_Year3.Items.Add(year.ToString())
            Next

            Cb_Year3.SelectedIndex = 0 ' Default select "All"

        Catch ex As Exception
            MessageBox.Show("Error loading years: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' --------------------------
    ' Function para i-refresh ang DataGridView para sa EmployeeSalaryBackup (Tab)
    ' --------------------------
    Private Sub RefreshDataGridView4()
        Try
            ' Base query na may WHERE clause para madaling maidagdag ang filters
            Dim query As String = "SELECT ID, EmployeeID, Fullname, Address, ContactNumber, Salary, Date " & _
                                  "FROM EmployeeSalaryBackup WHERE 1=1"

            ' ✅ Search Filter gamit ang Txt_Search3 at mga tamang columns
            Dim searchKeyword As String = Txt_Search3.Text.Trim()
            If Not String.IsNullOrEmpty(searchKeyword) Then
                query &= " AND (CAST(EmployeeID AS NVARCHAR(50)) LIKE @Search OR " & _
                         "Fullname LIKE @Search OR " & _
                         "Address LIKE @Search OR " & _
                         "ContactNumber LIKE @Search OR " & _
                         "CAST(Salary AS NVARCHAR(50)) LIKE @Search)"
            End If

            ' ✅ Month Filtering gamit ang Cb_Month3
            Dim selectedMonth As String = "All"
            Dim monthNumber As Integer = 0 ' Default value

            If Cb_Month3.SelectedItem IsNot Nothing Then
                selectedMonth = Cb_Month3.SelectedItem.ToString()
            End If

            If selectedMonth <> "All" Then
                monthNumber = Array.IndexOf( _
                    New String() {"January", "February", "March", "April", "May", "June", _
                                  "July", "August", "September", "October", "November", "December"}, _
                    selectedMonth) + 1
                query &= " AND MONTH(Date) = @Month"
            End If

            ' ✅ Year Filtering gamit ang Cb_Year3
            Dim selectedYear As String = "All"
            If Cb_Year3.SelectedItem IsNot Nothing Then
                selectedYear = Cb_Year3.SelectedItem.ToString()
            End If

            If selectedYear <> "All" Then
                query &= " AND YEAR(Date) = @Year"
            End If

            ' ✅ Sorting by Date (ascending order)
            query &= " ORDER BY Date ASC"

            Dim dt As New DataTable()

            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    If Not String.IsNullOrEmpty(searchKeyword) Then
                        cmd.Parameters.AddWithValue("@Search", "%" & searchKeyword & "%")
                    End If

                    If selectedMonth <> "All" Then
                        cmd.Parameters.AddWithValue("@Month", monthNumber)
                    End If

                    If selectedYear <> "All" Then
                        cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(selectedYear))
                    End If

                    conn.Open()
                    Dim adapter As New SqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using

            DataGridView4.DataSource = dt

            ' Ayusin ang header text ng ilang columns
            DataGridView4.Columns("ContactNumber").HeaderText = "Contact Number"

            ' I-center ang content ng bawat column at i-format ang Date column
            For Each col As DataGridViewColumn In DataGridView4.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                If col.Name = "Date" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next

            DataGridView4.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error refreshing data grid: " & ex.Message)
        End Try
    End Sub

    Private Sub DataGridView4_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles DataGridView4.SelectionChanged
        ' Check if there is any selected row
        If DataGridView4.SelectedRows.Count > 0 Then
            Dim selectedRow As DataGridViewRow = DataGridView4.SelectedRows(0)

            ' Display data from the selected row in input fields
            Cb_EmployeeID.Text = selectedRow.Cells("EmployeeID").Value.ToString()
            Cb_Fullname.Text = selectedRow.Cells("Fullname").Value.ToString()
            Txt_Address.Text = selectedRow.Cells("Address").Value.ToString()
            Txt_Contact.Text = selectedRow.Cells("ContactNumber").Value.ToString()

            ' Calculate the salary by dividing it by 7
            Dim salary As Double = CDbl(selectedRow.Cells("Salary").Value) ' Assuming the column name is "Salary"
            Txt_Quantity.Text = (salary / 7).ToString()

            DateTimePicker3.Value = CDate(selectedRow.Cells("Date").Value) ' Assuming the column name is "Date"
        End If
    End Sub
    Private Sub Btn_Restore3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Restore3.Click
        ' Check if there are selected rows
        If DataGridView4.SelectedCells.Count > 0 Then
            Dim insertedRecordsCount As Integer = 0 ' Counter for inserted records

            ' Open connection to the database
            Using conn As New SqlConnection(connectionString)
                conn.Open()

                ' Begin transaction for multiple insertions
                Using transaction As SqlTransaction = conn.BeginTransaction()
                    Try
                        ' Loop through each selected row in the DataGridView
                        For Each selectedRow As DataGridViewRow In DataGridView4.SelectedRows
                            ' Check if the row is selected
                            If selectedRow.Selected Then
                                ' Get values from the selected row
                                Dim id As Integer = Convert.ToInt32(selectedRow.Cells("ID").Value)  ' Use ID for deletion
                                Dim employeeID As String = selectedRow.Cells("EmployeeID").Value.ToString()
                                Dim salary As Double = CDbl(selectedRow.Cells("Salary").Value)
                                Dim dateOfEmployment As Date = CDate(selectedRow.Cells("Date").Value)

                                ' Check if the EmployeeID exists in EmployeeInfo
                                Dim checkEmployeeQuery As String = "SELECT COUNT(*) FROM EmployeeInfo WHERE EmployeeID = @EmployeeID"
                                Using cmdCheckEmployee As New SqlCommand(checkEmployeeQuery, conn, transaction)
                                    cmdCheckEmployee.Parameters.AddWithValue("@EmployeeID", employeeID)
                                    Dim employeeExists As Integer = CInt(cmdCheckEmployee.ExecuteScalar())

                                    If employeeExists = 0 Then
                                        MessageBox.Show(String.Format("EmployeeID '{0}' does not exist in EmployeeInfo. Skipping this record.", employeeID),
                                                        "Missing Employee", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                        Continue For ' Skip this row
                                    End If
                                End Using

                                ' Check if the record already exists in EmployeeSalary table
                                Dim checkQuery As String = "SELECT COUNT(*) FROM EmployeeSalary WHERE EmployeeID = @EmployeeID AND CONVERT(DATE, [Date]) = CONVERT(DATE, @Date)"
                                Using cmdCheck As New SqlCommand(checkQuery, conn, transaction)
                                    cmdCheck.Parameters.AddWithValue("@EmployeeID", employeeID)
                                    cmdCheck.Parameters.AddWithValue("@Date", dateOfEmployment)

                                    Dim existingRecords As Integer = CInt(cmdCheck.ExecuteScalar())

                                    If existingRecords > 0 Then
                                        MessageBox.Show(String.Format("The date {0:yyyy-MM-dd} for EmployeeID '{1}' already exists. Skipping this record.",
                                                                      dateOfEmployment.ToString("yyyy-MM-dd"), employeeID),
                                                        "Duplicate Record", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                        Continue For ' Skip this row
                                    End If
                                End Using

                                ' Insert data into Employee Salary table
                                Dim insertQuery As String = "INSERT INTO EmployeeSalary (EmployeeID, Salary, [Date]) VALUES (@EmployeeID, @Salary, @Date)"
                                Using cmdInsert As New SqlCommand(insertQuery, conn, transaction)
                                    cmdInsert.Parameters.AddWithValue("@EmployeeID", employeeID)
                                    cmdInsert.Parameters.AddWithValue("@Salary", salary)
                                    cmdInsert.Parameters.AddWithValue("@Date", dateOfEmployment)
                                    cmdInsert.ExecuteNonQuery()
                                End Using

                                ' Delete the record from Employee Salary Backup table
                                Dim deleteQuery As String = "DELETE FROM EmployeeSalaryBackup WHERE ID = @ID"
                                Using cmdDelete As New SqlCommand(deleteQuery, conn, transaction)
                                    cmdDelete.Parameters.AddWithValue("@ID", id)  ' Use ID for deletion
                                    cmdDelete.ExecuteNonQuery()
                                End Using

                                ' Increment the counter for successfully inserted records
                                insertedRecordsCount += 1
                            End If
                        Next

                        ' Commit the transaction
                        transaction.Commit()

                        ' Show success message only if at least one record was inserted
                        If insertedRecordsCount > 0 Then
                            MessageBox.Show("Record(s) restored and deleted from backup successfully!", "Restore", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If

                        ' Refresh the DataGridView to show the updated data
                        RefreshDataGridView4()
                        DataGridView4.ClearSelection()
                    Catch ex As Exception
                        ' Rollback transaction if any error occurs
                        transaction.Rollback()
                        MessageBox.Show("Error restoring record: " & ex.Message, "Restore Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            End Using
        Else
            MessageBox.Show("Please select a record to restore.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub Btn_Delete3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete3.Click
        ' Ensure at least one row is selected
        If DataGridView4.SelectedRows.Count = 0 Then
            MessageBox.Show("Please select at least one row to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Ask for confirmation before deleting
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete the selected record(s)?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        ' If user clicks 'Yes', proceed with deletion
        If result = DialogResult.Yes Then
            Try
                ' Open connection to the database
                Using conn As New SqlConnection(connectionString)
                    conn.Open()

                    ' Begin transaction for multiple deletes
                    Using transaction As SqlTransaction = conn.BeginTransaction()
                        Try
                            Dim deletedRecordsCount As Integer = 0 ' Counter for deleted records

                            ' Loop through each selected row and delete
                            For Each selectedRow As DataGridViewRow In DataGridView4.SelectedRows
                                ' Get ID of the selected record
                                Dim id As Integer = Convert.ToInt32(selectedRow.Cells("ID").Value)

                                ' Define the delete query to remove the record from Employee Salary Backup table
                                Dim deleteQuery As String = "DELETE FROM EmployeeSalaryBackup WHERE ID = @ID"

                                ' Delete the record from Employee Salary Backup table
                                Using cmdDelete As New SqlCommand(deleteQuery, conn, transaction)
                                    cmdDelete.Parameters.AddWithValue("@ID", id)  ' Use ID for deletion
                                    cmdDelete.ExecuteNonQuery()
                                End Using

                                ' Increment the counter for successfully deleted records
                                deletedRecordsCount += 1
                            Next

                            ' Commit the transaction if all deletions are successful
                            transaction.Commit()

                            ' Show success message if at least one record is deleted
                            If deletedRecordsCount > 0 Then
                                MessageBox.Show("Selected record(s) deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            End If

                            ' Optionally, refresh the DataGridView to show the updated data
                            RefreshDataGridView4()

                        Catch ex As Exception
                            ' Rollback transaction if any error occurs
                            transaction.Rollback()
                            MessageBox.Show("Error during deletion: " & ex.Message, "Delete Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
    'Tab 5
    Private Sub Btn_Refresh4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh4.Click

        Cb_Month4.SelectedIndex = 0
        Cb_Year4.SelectedIndex = 0
        Txt_Search4.Clear()

        RefreshDataGridView5()
        DataGridView5.ClearSelection()

    End Sub
    Private Sub Txt_Search4_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Search4.KeyPress
        ' Limit the length of the text to 11 characters
        If Txt_Search4.TextLength >= 50 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    '---------------------------
    ' Event Handlers para Tab 5
    '---------------------------
    Private Sub Cb_Month4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Month4.SelectedIndexChanged
        RefreshDataGridView5()
    End Sub

    Private Sub Cb_Year4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Year4.SelectedIndexChanged
        RefreshDataGridView5()
    End Sub

    Private Sub Txt_Search4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Search4.TextChanged
        RefreshDataGridView5()
    End Sub

    '---------------------------
    ' Function para i-load ang listahan ng Months (January - December) gamit ang Cb_Month4
    '---------------------------
    Private Sub LoadMonths3()
        Cb_Month4.Items.Clear()
        Cb_Month4.Items.Add("All") ' Default option

        Dim monthNames() As String = {"January", "February", "March", "April", "May", "June", _
                                      "July", "August", "September", "October", "November", "December"}

        For Each month As String In monthNames
            Cb_Month4.Items.Add(month)
        Next

        Cb_Month4.SelectedIndex = 0 ' Default select "All"
    End Sub

    '---------------------------
    ' Function para i-load ang listahan ng Years (2024 - 2050) gamit ang Cb_Year4
    '---------------------------
    Private Sub LoadYears3()
        Dim startYear As Integer = 2024 ' Fixed start year
        Dim endYear As Integer = 2050   ' Fixed end year

        Try
            Cb_Year4.Items.Clear()
            Cb_Year4.Items.Add("All") ' Default option

            For year As Integer = startYear To endYear
                Cb_Year4.Items.Add(year.ToString())
            Next

            Cb_Year4.SelectedIndex = 0 ' Default select "All"
        Catch ex As Exception
            MessageBox.Show("Error loading years: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    '---------------------------
    ' Function para i-refresh ang DataGridView para sa EmployeeInfoBackup (Tab 5)
    '---------------------------
    Private Sub RefreshDataGridView5()
        Try
            ' Base query – ginagamit ang WHERE 1=1 para madaling maidagdag ang filters
            Dim query As String = "SELECT ID, EmployeeID, Fullname, Address, ContactNumber, DateofEmployment " & _
                                  "FROM EmployeeInfoBackup WHERE 1=1"

            ' ✅ Search Filter gamit ang Txt_Search4
            Dim searchKeyword As String = Txt_Search4.Text.Trim()
            If Not String.IsNullOrEmpty(searchKeyword) Then
                query &= " AND (CAST(EmployeeID AS NVARCHAR(50)) LIKE @Search OR Fullname LIKE @Search OR Address LIKE @Search OR ContactNumber LIKE @Search)"
            End If

            ' ✅ Month Filtering gamit ang Cb_Month4
            Dim selectedMonth As String = "All"
            Dim monthNumber As Integer = 0
            If Cb_Month4.SelectedItem IsNot Nothing Then
                selectedMonth = Cb_Month4.SelectedItem.ToString()
            End If

            If selectedMonth <> "All" Then
                monthNumber = Array.IndexOf(New String() {"January", "February", "March", "April", "May", "June", _
                                                          "July", "August", "September", "October", "November", "December"}, selectedMonth) + 1
                query &= " AND MONTH(DateofEmployment) = @Month"
            End If

            ' ✅ Year Filtering gamit ang Cb_Year4
            Dim selectedYear As String = "All"
            If Cb_Year4.SelectedItem IsNot Nothing Then
                selectedYear = Cb_Year4.SelectedItem.ToString()
            End If

            If selectedYear <> "All" Then
                query &= " AND YEAR(DateofEmployment) = @Year"
            End If

            ' ✅ Sorting by DateofEmployment (ascending order)
            query &= " ORDER BY DateofEmployment ASC"

            Dim dt As New DataTable()

            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    ' Magdagdag ng parameters kung kinakailangan
                    If Not String.IsNullOrEmpty(searchKeyword) Then
                        cmd.Parameters.AddWithValue("@Search", "%" & searchKeyword & "%")
                    End If

                    If selectedMonth <> "All" Then
                        cmd.Parameters.AddWithValue("@Month", monthNumber)
                    End If

                    If selectedYear <> "All" Then
                        cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(selectedYear))
                    End If

                    conn.Open()
                    Dim adapter As New SqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using

            ' I-bind ang nakuha na data sa DataGridView5
            DataGridView5.DataSource = dt
            DataGridView5.Columns("ContactNumber").HeaderText = "Contact Number"
            DataGridView5.Columns("DateofEmployment").HeaderText = "Date of Employment"

            ' I-center ang laman ng bawat column at i-format ang DateofEmployment column
            For Each col As DataGridViewColumn In DataGridView5.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                If col.Name = "DateofEmployment" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next

            DataGridView5.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error refreshing data grid: " & ex.Message)
        End Try
    End Sub

    Private Sub DataGridView5_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles DataGridView5.SelectionChanged
        If DataGridView5.SelectedRows.Count > 0 Then
            Dim selectedRow As DataGridViewRow = DataGridView5.SelectedRows(0)
            Txt_EmployeeID.Text = selectedRow.Cells("EmployeeID").Value.ToString()
            Txt_Fullname.Text = selectedRow.Cells("Fullname").Value.ToString()
            Txt_Address1.Text = selectedRow.Cells("Address").Value.ToString()
            Txt_Contact1.Text = selectedRow.Cells("ContactNumber").Value.ToString()
            DateTimePicker4.Value = CType(selectedRow.Cells("DateofEmployment").Value, Date)
        End If
    End Sub
    Private Sub Btn_Restore4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Restore4.Click
        ' Ensure that a row is selected in the DataGridView
        If DataGridView5.SelectedRows.Count > 0 Then
            Dim insertedRecordsCount As Integer = 0 ' Counter for inserted records

            ' Open database connection
            Using conn As New SqlConnection(connectionString)
                conn.Open()

                ' Start a transaction to ensure both operations are executed together
                Using transaction As SqlTransaction = conn.BeginTransaction()
                    Try
                        ' Loop through each selected row in the DataGridView
                        For Each selectedRow As DataGridViewRow In DataGridView5.SelectedRows
                            ' Get the selected row's details
                            Dim employeeID As String = selectedRow.Cells("EmployeeID").Value.ToString()
                            Dim fullname As String = selectedRow.Cells("Fullname").Value.ToString()
                            Dim address As String = selectedRow.Cells("Address").Value.ToString()
                            Dim contactNumber As String = selectedRow.Cells("ContactNumber").Value.ToString()
                            Dim dateOfEmployment As Date = CType(selectedRow.Cells("DateofEmployment").Value, Date)

                            ' Check if the fullname already exists in the Employee Info table
                            Dim checkQuery As String = "SELECT COUNT(*) FROM EmployeeInfo WHERE Fullname = @Fullname"
                            Using cmdCheck As New SqlCommand(checkQuery, conn, transaction)
                                cmdCheck.Parameters.AddWithValue("@Fullname", fullname)

                                Dim existingRecords As Integer = CInt(cmdCheck.ExecuteScalar())

                                If existingRecords > 0 Then
                                    ' If the record exists, show a message and skip the record
                                    MessageBox.Show(String.Format("The employee with Fullname '{0}' already exists. Skipping this record.", fullname, employeeID), "Duplicate Fullname", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                    Continue For
                                End If
                            End Using

                            Using cmdEnableIdentity As New SqlCommand("SET IDENTITY_INSERT EmployeeInfo ON", conn, transaction)
                                cmdEnableIdentity.ExecuteNonQuery()
                            End Using

                            Dim insertQuery As String = "INSERT INTO EmployeeInfo ([EmployeeID], [Fullname], [Address], [ContactNumber], [DateofEmployment]) VALUES (@EmployeeID, @Fullname, @Address, @ContactNumber, @DateOfEmployment)"
                            Using cmdInsert As New SqlCommand(insertQuery, conn, transaction)
                                cmdInsert.Parameters.AddWithValue("@EmployeeID", employeeID)
                                cmdInsert.Parameters.AddWithValue("@Fullname", fullname)
                                cmdInsert.Parameters.AddWithValue("@Address", address)
                                cmdInsert.Parameters.AddWithValue("@ContactNumber", contactNumber)
                                cmdInsert.Parameters.AddWithValue("@DateOfEmployment", dateOfEmployment)
                                cmdInsert.ExecuteNonQuery()
                            End Using

                            Using cmdDisableIdentity As New SqlCommand("SET IDENTITY_INSERT EmployeeInfo OFF", conn, transaction)
                                cmdDisableIdentity.ExecuteNonQuery()
                            End Using

                            ' Delete the record from Employee Info Backup table
                            Dim deleteQuery As String = "DELETE FROM EmployeeInfoBackup WHERE ID = @ID"
                            Using cmdDelete As New SqlCommand(deleteQuery, conn, transaction)
                                cmdDelete.Parameters.AddWithValue("@ID", selectedRow.Cells("ID").Value)

                                ' Execute the delete query
                                cmdDelete.ExecuteNonQuery()
                            End Using

                            ' Increment the counter for successfully inserted records
                            insertedRecordsCount += 1
                        Next

                        ' Commit the transaction if at least one record was inserted
                        If insertedRecordsCount > 0 Then
                            transaction.Commit()
                            ' Show success message
                            MessageBox.Show("Employee information restored and backup record deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If

                        ' Refresh the DataGridView to show the updated data
                        RefreshDataGridView5()
                        RefreshDataGridView1EmployeeInfo()
                        PopulateEmployeeComboBoxes()
                        DataGridView5.ClearSelection()
                        EmployeeInfo.DataGridView1.ClearSelection()

                    Catch ex As Exception
                        ' If any error occurs, roll back the transaction
                        transaction.Rollback()
                        MessageBox.Show("Error during restore: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            End Using
        Else
            ' If no row is selected, prompt the user
            MessageBox.Show("Please select a record to restore.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub
    Private Sub PopulateEmployeeComboBoxes()
        Try
            conn.Open()
            Dim query As String = "SELECT EmployeeID, Fullname FROM EmployeeInfo"
            cmd = New SqlCommand(query, conn)
            adapter = New SqlDataAdapter(cmd)

            ' Kumuha ng data sa isang DataTable
            Dim dtEmployee As New DataTable()
            adapter.Fill(dtEmployee)

            SalaryAndIncome.Cb_EmployeeID.DataSource = dtEmployee.Copy()
            SalaryAndIncome.Cb_EmployeeID.DisplayMember = "EmployeeID"
            SalaryAndIncome.Cb_EmployeeID.ValueMember = "EmployeeID"

            SalaryAndIncome.Cb_Fullname.DataSource = dtEmployee.Copy()
            SalaryAndIncome.Cb_Fullname.DisplayMember = "Fullname"
            SalaryAndIncome.Cb_Fullname.ValueMember = "EmployeeID"

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub RefreshDataGridView1EmployeeInfo()
        Try
            conn.Open()
            Dim query As String = "SELECT EmployeeID, Fullname, Address, ContactNumber, DateofEmployment FROM EmployeeInfo"

            cmd = New SqlCommand(query, conn)
            adapter = New SqlDataAdapter(cmd)
            dt = New DataTable()
            adapter.Fill(dt)

            EmployeeInfo.DataGridView1.DataSource = dt
            EmployeeInfo.DataGridView1.Columns("ContactNumber").HeaderText = "Contact Number"
            EmployeeInfo.DataGridView1.Columns("DateofEmployment").HeaderText = "Date of Employment"

            ' Set content alignment for each column
            For Each col As DataGridViewColumn In EmployeeInfo.DataGridView1.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                ' Format the Date of Employment column
                If col.Name = "DateofEmployment" Then
                    col.DefaultCellStyle.Format = "MMMM dd, yyyy"
                End If
            Next

            ' Set row header alignment
            EmployeeInfo.DataGridView1.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub Btn_Delete4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete4.Click
        ' Ensure at least one row is selected
        If DataGridView5.SelectedRows.Count = 0 Then
            MessageBox.Show("Please select at least one row to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Ask for confirmation before deleting
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete the selected record(s)?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        ' If user clicks 'Yes', proceed with deletion
        If result = DialogResult.Yes Then
            Try
                ' Open connection to the database
                Using conn As New SqlConnection(connectionString)
                    conn.Open()

                    ' Begin transaction for multiple deletes
                    Using transaction As SqlTransaction = conn.BeginTransaction()
                        Try
                            Dim deletedRecordsCount As Integer = 0 ' Counter for deleted records

                            ' Loop through each selected row and delete
                            For Each selectedRow As DataGridViewRow In DataGridView5.SelectedRows
                                ' Get Selected ID of the selected record
                                Dim selectedID As String = selectedRow.Cells("ID").Value.ToString() ' Change to actual column name

                                ' Define the delete query to remove the record based on SelectedID
                                Dim deleteQuery As String = "DELETE FROM EmployeeInfoBackup WHERE ID = @ID"

                                ' Execute delete command
                                Using cmdDelete As New SqlCommand(deleteQuery, conn, transaction)
                                    cmdDelete.Parameters.AddWithValue("@ID", selectedID)  ' Use SelectedID for deletion
                                    cmdDelete.ExecuteNonQuery()
                                End Using

                                ' Increment the counter for successfully deleted records
                                deletedRecordsCount += 1
                            Next

                            ' Commit the transaction if all deletions are successful
                            transaction.Commit()

                            ' Show success message if at least one record is deleted
                            If deletedRecordsCount > 0 Then
                                MessageBox.Show("Selected record(s) deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            End If

                            ' Optionally, refresh the DataGridView to show the updated data
                            RefreshDataGridView5()

                        Catch ex As Exception
                            ' Rollback transaction if any error occurs
                            transaction.Rollback()
                            MessageBox.Show("Error during deletion: " & ex.Message, "Delete Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    ' Tab 6
    Private Sub Btn_Refresh5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh5.Click
        Cb_Month5.SelectedIndex = 0
        Cb_Year5.SelectedIndex = 0
        Txt_Search5.Clear()
        RefreshDataGridView6()
        DataGridView6.ClearSelection()
    End Sub
    Private Sub Txt_Search5_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Search5.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        ' Limit the length of the text to 11 characters
        If Txt_Search5.TextLength >= 11 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    '---------------------------
    ' Event Handlers para sa Tab 6
    '---------------------------
    Private Sub Txt_Search5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Search5.TextChanged
        RefreshDataGridView6()
    End Sub

    Private Sub Cb_Month5_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Month5.SelectedIndexChanged
        RefreshDataGridView6()
    End Sub

    Private Sub Cb_Year5_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Year5.SelectedIndexChanged
        RefreshDataGridView6()
    End Sub

    '---------------------------
    ' Function para i-load ang listahan ng Months (January - December) gamit ang Cb_Month5
    '---------------------------
    Private Sub LoadMonths4()
        Cb_Month5.Items.Clear()
        Cb_Month5.Items.Add("All") ' Default option

        Dim monthNames() As String = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        }

        For Each month As String In monthNames
            Cb_Month5.Items.Add(month)
        Next

        Cb_Month5.SelectedIndex = 0 ' Default select "All"
    End Sub

    '---------------------------
    ' Function para i-load ang listahan ng Years (Fixed from 2024 - 2050) gamit ang Cb_Year5
    '---------------------------
    Private Sub LoadYears4()
        Dim startYear As Integer = 2024 ' Fixed start year
        Dim endYear As Integer = 2050   ' Fixed end year

        Try
            Cb_Year5.Items.Clear()
            Cb_Year5.Items.Add("All") ' Default option

            For year As Integer = startYear To endYear
                Cb_Year5.Items.Add(year.ToString())
            Next

            Cb_Year5.SelectedIndex = 0 ' Default select "All"

        Catch ex As Exception
            MessageBox.Show("Error loading years: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    '---------------------------
    ' Function para i-refresh ang DataGridView para sa BillsBackup (Tab 6)
    '---------------------------
    Private Sub RefreshDataGridView6()
        Try
            ' Base query gamit ang WHERE 1=1 para madali ang pagdagdag ng filters
            Dim query As String = "SELECT ID, Electricity, Water, WaterFilter, Total, Date FROM BillsBackup WHERE 1=1"

            ' ✅ Search Filter gamit ang Txt_Search5
            Dim searchKeyword As String = Txt_Search5.Text.Trim()
            If Not String.IsNullOrEmpty(searchKeyword) Then
                query &= " AND (CAST(Electricity AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(Water AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(WaterFilter AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(Total AS NVARCHAR(50)) LIKE @Search)"
            End If

            ' ✅ Month Filtering gamit ang Cb_Month5
            Dim selectedMonth As String = "All"
            Dim monthNumber As Integer = 0
            If Cb_Month5.SelectedItem IsNot Nothing Then
                selectedMonth = Cb_Month5.SelectedItem.ToString()
            End If

            If selectedMonth <> "All" Then
                monthNumber = Array.IndexOf( _
                    New String() {"January", "February", "March", "April", "May", "June", _
                                  "July", "August", "September", "October", "November", "December"}, _
                    selectedMonth) + 1
                query &= " AND MONTH(Date) = @Month"
            End If

            ' ✅ Year Filtering gamit ang Cb_Year5
            Dim selectedYear As String = "All"
            If Cb_Year5.SelectedItem IsNot Nothing Then
                selectedYear = Cb_Year5.SelectedItem.ToString()
            End If

            If selectedYear <> "All" Then
                query &= " AND YEAR(Date) = @Year"
            End If

            ' ✅ Sorting by Date (ascending order)
            query &= " ORDER BY Date ASC"

            Dim dt As New DataTable()

            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    If Not String.IsNullOrEmpty(searchKeyword) Then
                        cmd.Parameters.AddWithValue("@Search", "%" & searchKeyword & "%")
                    End If

                    If selectedMonth <> "All" Then
                        cmd.Parameters.AddWithValue("@Month", monthNumber)
                    End If

                    If selectedYear <> "All" Then
                        cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(selectedYear))
                    End If

                    conn.Open()
                    Dim adapter As New SqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using

            ' I-bind ang nakuha na data sa DataGridView6
            DataGridView6.DataSource = dt

            ' Ayusin ang header ng WaterFilter column
            DataGridView6.Columns("WaterFilter").HeaderText = "Water Filter"

            ' I-center ang laman ng bawat column at i-format ang Date column
            For Each col As DataGridViewColumn In DataGridView6.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                If col.Name = "Date" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next

            DataGridView6.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error refreshing data grid: " & ex.Message)
        End Try
    End Sub

    Private Sub DataGridView6_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles DataGridView6.SelectionChanged
        ' Check if there is a selected row
        If DataGridView6.SelectedRows.Count > 0 Then
            ' Get the values from the selected row and display them in the input fields
            Dim selectedRow As DataGridViewRow = DataGridView6.SelectedRows(0)
            Txt_Electricity.Text = selectedRow.Cells("Electricity").Value.ToString()
            Txt_WaterBill.Text = selectedRow.Cells("Water").Value.ToString()
            Txt_WaterFilter.Text = selectedRow.Cells("WaterFilter").Value.ToString()
            DateTimePicker5.Value = Convert.ToDateTime(selectedRow.Cells("Date").Value)
        End If
    End Sub
    Private Sub Btn_Restore5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Restore5.Click
        ' Check if there is any selected row
        If DataGridView6.SelectedRows.Count > 0 Then
            ' Open connection to the database
            Using conn As New SqlConnection(connectionString)
                conn.Open()

                ' Start a transaction for multiple inserts
                Using transaction As SqlTransaction = conn.BeginTransaction()
                    Dim recordInserted As Boolean = False ' Track if any record is inserted

                    Try
                        ' Iterate over all selected rows
                        For Each selectedRow As DataGridViewRow In DataGridView6.SelectedRows
                            ' Get the values from the selected row
                            Dim electricity As String = selectedRow.Cells("Electricity").Value.ToString()
                            Dim water As String = selectedRow.Cells("Water").Value.ToString()
                            Dim waterFilter As String = selectedRow.Cells("WaterFilter").Value.ToString()
                            Dim total As String = selectedRow.Cells("Total").Value.ToString()
                            Dim dateOfExpense As Date = Convert.ToDateTime(selectedRow.Cells("Date").Value)

                            ' Check if the record with the same date already exists in the Expenses table
                            Dim checkQuery As String = "SELECT COUNT(*) FROM Bills WHERE CONVERT(DATE, [Date]) = CONVERT(DATE, @Date)"
                            Using cmdCheck As New SqlCommand(checkQuery, conn, transaction)
                                cmdCheck.Parameters.AddWithValue("@Date", dateOfExpense)

                                Dim existingRecords As Integer = CInt(cmdCheck.ExecuteScalar())

                                If existingRecords > 0 Then
                                    ' If a record with the same date exists, show a message and skip the current record
                                    MessageBox.Show(String.Format("The record for the date {0:yyyy-MM-dd} with ID {1} already exists. Skipping this record.", dateOfExpense.ToString("yyyy-MM-dd"), selectedRow.Cells("ID").Value.ToString()), "Duplicate Date", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                                    Continue For ' Skip this row and proceed to the next one
                                End If
                            End Using

                            ' Insert query to add data to the Expenses table
                            Dim insertQuery As String = "INSERT INTO Bills (Electricity, Water, WaterFilter, Total, Date) VALUES (@Electricity, @Water, @WaterFilter, @Total, @Date)"
                            Using cmdInsert As New SqlCommand(insertQuery, conn, transaction)
                                cmdInsert.Parameters.AddWithValue("@Electricity", electricity)
                                cmdInsert.Parameters.AddWithValue("@Water", water)
                                cmdInsert.Parameters.AddWithValue("@WaterFilter", waterFilter)
                                cmdInsert.Parameters.AddWithValue("@Total", total)
                                cmdInsert.Parameters.AddWithValue("@Date", dateOfExpense)

                                ' Execute the insert query
                                cmdInsert.ExecuteNonQuery()
                                recordInserted = True ' Mark that a record has been inserted
                            End Using

                            ' Delete query to remove the record from the Expenses Backup table
                            Dim deleteQuery As String = "DELETE FROM BillsBackup WHERE ID = @ID"
                            Using cmdDelete As New SqlCommand(deleteQuery, conn, transaction)
                                ' Assuming the "ID" column is the primary key and unique identifier for each row
                                cmdDelete.Parameters.AddWithValue("@ID", selectedRow.Cells("ID").Value)

                                ' Execute the delete query
                                cmdDelete.ExecuteNonQuery()
                            End Using
                        Next

                        ' Commit the transaction if all inserts are successful
                        transaction.Commit()

                        ' Show success message only if at least one record was inserted
                        If recordInserted Then
                            MessageBox.Show("Records restored and deleted from backup successfully!", "Restore", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If

                        ' Optionally, refresh the DataGridView to show the updated data
                        RefreshDataGridView6()
                        RefreshDataGridView1Bills()
                        DataGridView6.ClearSelection()
                    Catch ex As Exception
                        ' If any error occurs, roll back the transaction
                        transaction.Rollback()
                        MessageBox.Show("Error restoring records: " & ex.Message, "Restore Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End Using
            End Using
        Else
            MessageBox.Show("Please select records to restore.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub
    Private Sub RefreshDataGridView1Bills()
        Try
            conn.Open()
            Dim query As String = "SELECT ID, Electricity, Water, WaterFilter, Total, Date FROM Bills"

            cmd = New SqlCommand(query, conn)
            adapter = New SqlDataAdapter(cmd)
            dt = New DataTable()
            adapter.Fill(dt)

            WaterElectricBills.DataGridView1.DataSource = dt
            WaterElectricBills.DataGridView1.Columns("WaterFilter").HeaderText = "Water Filter"

            ' Set content alignment for each column
            For Each col As DataGridViewColumn In WaterElectricBills.DataGridView1.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                ' Check if column is Date column, then format the date to display month name
                If col.Name = "Date" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next

            ' Set row header alignment
            WaterElectricBills.DataGridView1.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub Btn_Delete5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete5.Click
        ' Ensure at least one row is selected
        If DataGridView6.SelectedRows.Count = 0 Then
            MessageBox.Show("Please select at least one row to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Ask for confirmation before deleting
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete the selected record(s)?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        ' If user clicks 'Yes', proceed with deletion
        If result = DialogResult.Yes Then
            Try
                ' Open connection to the database
                Using conn As New SqlConnection(connectionString)
                    conn.Open()

                    ' Start a transaction for multiple deletes
                    Using transaction As SqlTransaction = conn.BeginTransaction()
                        Try
                            Dim deletedRecordsCount As Integer = 0 ' Counter for deleted records

                            ' Loop through each selected row and delete
                            For Each selectedRow As DataGridViewRow In DataGridView6.SelectedRows
                                ' Get the ID of the selected record
                                Dim recordID As Integer = Convert.ToInt32(selectedRow.Cells("ID").Value)

                                ' Define the delete query to remove the record from Expenses Backup table
                                Dim deleteQuery As String = "DELETE FROM BillsBackup WHERE ID = @ID"

                                ' Delete the record from Expenses Backup table
                                Using cmdDelete As New SqlCommand(deleteQuery, conn, transaction)
                                    cmdDelete.Parameters.AddWithValue("@ID", recordID)  ' Use the ID for deletion
                                    cmdDelete.ExecuteNonQuery()
                                End Using

                                ' Increment the counter for successfully deleted records
                                deletedRecordsCount += 1
                            Next

                            ' Commit the transaction if all deletions are successful
                            transaction.Commit()

                            ' Show success message if at least one record is deleted
                            If deletedRecordsCount > 0 Then
                                MessageBox.Show("Selected record(s) deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            End If

                            ' Optionally, refresh the DataGridView to show the updated data
                            RefreshDataGridView6()

                        Catch ex As Exception
                            ' Rollback transaction if any error occurs
                            transaction.Rollback()
                            MessageBox.Show("Error during deletion: " & ex.Message, "Delete Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub Btn_UserInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_UserInfo.Click
        Me.Hide()
        UserProfile.Show()
    End Sub

    Private Sub Btn_Logout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Logout.Click
        Dim _exit As DialogResult = MessageBox.Show("Are you sure you want to Logout", "Logout", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)
        If _exit = vbOK Then
            Login.Show()
            Me.Hide()
            Login.Txt_Username.Focus()
            Login.Txt_Password.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub Tb_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabControl1.Click
        RefreshDataGridView2SoldBackup()
        DataGridView2.ClearSelection()

        RefreshDataGridView3()
        DataGridView3.ClearSelection()

        RefreshDataGridView4()
        DataGridView4.ClearSelection()

        RefreshDataGridView5()
        DataGridView5.ClearSelection()

        RefreshDataGridView6()
        DataGridView6.ClearSelection()
    End Sub
End Class