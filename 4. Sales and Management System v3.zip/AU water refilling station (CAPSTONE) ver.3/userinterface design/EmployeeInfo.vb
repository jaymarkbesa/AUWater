﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Configuration
Public Class EmployeeInfo
    Dim connectionString As String = ConfigurationManager.ConnectionStrings("MyDB").ConnectionString
    Dim conn As New SqlConnection(connectionString)
    Dim cmd As SqlCommand
    Dim adapter As SqlDataAdapter
    Dim dt As DataTable
    Private Sub Btn_Home_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Home.Click
        Me.Hide()
        Home.Show()
        ClearTextBoxes()
    End Sub
    Private Sub Btn_Calculation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Calculation.Click
        Me.Hide()
        SalaryAndIncome.Show()
        SalaryAndIncome.TabControl1.SelectedIndex = 0
        ClearTextBoxes()
    End Sub

    Private Sub Btn_Bills_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Bills.Click
        Me.Hide()
        WaterElectricBills.Show()
        ClearTextBoxes()
    End Sub

    Private Sub Btn_Reports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Reports.Click
        Me.Hide()
        Reports.Show()
        Reports.TabControl1.SelectedIndex = 0
        ClearTextBoxes()
    End Sub

    Private Sub Btn_Recycle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Recycle.Click
        Me.Hide()
        RecycleBin.Show()
        RecycleBin.TabControl1.SelectedIndex = 0
        ClearTextBoxes()
    End Sub
    Private Sub EmployeeInfo_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LoadMonths()
        LoadYears()

        ' Additional setup
        RefreshDataGridView1EmployeeInfo()
        ClearTextBoxes()
        DateTimePicker1.Value = DateTime.Now
        DataGridView1.ClearSelection()

        ' Generate a random ID when the form loads
        Dim generatedID As String = GenerateRandomID()
        Txt_EmployeeID.Text = generatedID
    End Sub

    Private Sub ClearTextBoxes()
        ' Generate a random ID when the form loads
        Dim generatedID As String = GenerateRandomID()

        ' Display generated ID in Txt_GeneratedID.Text
        Txt_EmployeeID.Text = generatedID

        Txt_Address.Clear()
        Txt_Contact.Clear()
        Txt_Fullname.Clear()
        Txt_Search.Clear()
    End Sub

    Private Sub Btn_Refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh.Click
        Cb_Month.SelectedIndex = 0
        Cb_Year.SelectedIndex = 0
        ClearTextBoxes()
        RefreshDataGridView1EmployeeInfo()
        DataGridView1.ClearSelection()
        DateTimePicker1.Value = DateTime.Now
    End Sub
    Private Sub Txt_Search_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Search.KeyPress
        ' Limit the length of the text to 11 characters
        If Txt_Search.TextLength >= 50 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    Private Sub Txt_Contact_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Contact.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        ' Limit the length of the text to 11 characters
        If Txt_Contact.TextLength >= 11 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    Private Function IsValidPhoneNumber(ByVal phoneNumber As String) As Boolean
        ' Regular expression pattern for validating phone number format (Philippines format)
        Dim pattern As String = "^(09|\+639)\d{9}$"
        Return System.Text.RegularExpressions.Regex.IsMatch(phoneNumber, pattern)
    End Function
    Private Function GenerateRandomID() As String
        Dim random As New Random()
        Const chars As String = "0123456789"
        Dim ID As New String(Enumerable.Repeat(chars, 8).Select(Function(s) s(random.Next(s.Length))).ToArray())
        Return ID
    End Function
    ' ✅ Function para i-load ang listahan ng Months (January - December)
    Private Sub LoadMonths()
        Cb_Month.Items.Clear()
        Cb_Month.Items.Add("All") ' Default option

        Dim monthNames() As String = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        }

        ' Add month names
        For Each month As String In monthNames
            Cb_Month.Items.Add(month)
        Next

        Cb_Month.SelectedIndex = 0 ' Default select "All"
    End Sub
    ' ✅ Function para i-load ang listahan ng Years (Fixed from 2024 - 2050)
    Private Sub LoadYears()
        Dim startYear As Integer = 2024 ' ✅ Fixed start year
        Dim endYear As Integer = 2050   ' ✅ Fixed end year

        Try
            Cb_Year.Items.Clear()
            Cb_Year.Items.Add("All") ' Default option

            ' ✅ Siguraduhin na lahat ng taon mula 2024 hanggang 2050 ay nandito
            For year As Integer = startYear To endYear
                Cb_Year.Items.Add(year.ToString())
            Next

            Cb_Year.SelectedIndex = 0 ' Default select "All"

        Catch ex As Exception
            MessageBox.Show("Error loading years: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub Cb_Month_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Month.SelectedIndexChanged
        RefreshDataGridView1EmployeeInfo()
    End Sub

    Private Sub Cb_Year_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Year.SelectedIndexChanged
        RefreshDataGridView1EmployeeInfo()
    End Sub
    Private Sub Txt_Search_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Search.TextChanged
        RefreshDataGridView1EmployeeInfo()
    End Sub
    Private Sub RefreshDataGridView1EmployeeInfo()
        Try

            Dim query As String = "SELECT EmployeeID, Fullname, Address, ContactNumber, DateofEmployment FROM EmployeeInfo WHERE 1=1"

            ' ✅ Search Filter (EmployeeID, Fullname, and Address)
            Dim searchKeyword As String = Txt_Search.Text.Trim()
            If Not String.IsNullOrEmpty(searchKeyword) Then
                query &= " AND (EmployeeID LIKE @Search OR Fullname LIKE @Search OR Address LIKE @Search)"
            End If

            ' ✅ Month Filtering (Convert month name to number)
            Dim selectedMonth As String = "All"
            Dim monthNumber As Integer = 0 ' Default value

            If Cb_Month.SelectedItem IsNot Nothing Then
                selectedMonth = Cb_Month.SelectedItem.ToString()
            End If

            If selectedMonth <> "All" Then
                monthNumber = Array.IndexOf(
                    New String() {"January", "February", "March", "April", "May", "June",
                                  "July", "August", "September", "October", "November", "December"}, selectedMonth) + 1
                query &= " AND MONTH(DateofEmployment) = @Month"
            End If

            ' ✅ Year Filtering - ginagamit ang DateofEmployment
            Dim selectedYear As String = "All"
            If Cb_Year.SelectedItem IsNot Nothing Then
                selectedYear = Cb_Year.SelectedItem.ToString()
            End If

            If selectedYear <> "All" Then
                query &= " AND YEAR(DateofEmployment) = @Year"
            End If

            ' ✅ Sorting by Date (Newest First)
            query &= " ORDER BY DateofEmployment ASC"

            Dim dt As New DataTable()

            ' Gamitin ang Using block para maayos na pamamahala ng connection
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    If Not String.IsNullOrEmpty(searchKeyword) Then
                        cmd.Parameters.AddWithValue("@Search", "%" & searchKeyword & "%")
                    End If

                    If selectedMonth <> "All" Then
                        cmd.Parameters.AddWithValue("@Month", monthNumber)
                    End If

                    If selectedYear <> "All" Then
                        cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(selectedYear))
                    End If

                    Dim adapter As New SqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using

            ' I-bind ang DataTable sa DataGridView
            DataGridView1.DataSource = dt

            ' I-update ang header texts ng columns
            DataGridView1.Columns("ContactNumber").HeaderText = "Contact Number"
            DataGridView1.Columns("DateofEmployment").HeaderText = "Date of Employment"

            ' I-set ang alignment para sa bawat column
            For Each col As DataGridViewColumn In DataGridView1.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                ' Format para sa Date of Employment column
                If col.Name = "DateofEmployment" Then
                    col.DefaultCellStyle.Format = "MMMM dd, yyyy"
                End If
            Next

            ' I-set ang alignment ng row headers
            DataGridView1.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub
    Private Sub DataGridView1_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles DataGridView1.SelectionChanged

        If DataGridView1.SelectedRows.Count > 1 Then
            Btn_Update.Enabled = False ' Disable the update button if more than one row is selected
            Btn_Submit.Enabled = False
        Else
            Btn_Update.Enabled = True ' Enable the update button if only one row is selected
            Btn_Submit.Enabled = True
        End If

        Try
            If DataGridView1.SelectedRows.Count > 0 Then
                ' Kunin ang napiling row
                Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)

                ' Ilipat ang data sa TextBoxes at DateTimePicker
                Txt_EmployeeID.Text = selectedRow.Cells("EmployeeID").Value.ToString()
                Txt_Fullname.Text = selectedRow.Cells("Fullname").Value.ToString()
                Txt_Address.Text = selectedRow.Cells("Address").Value.ToString()
                Txt_Contact.Text = selectedRow.Cells("ContactNumber").Value.ToString()

                ' DateTimePicker formatting at value assignment
                If Not IsDBNull(selectedRow.Cells("DateofEmployment").Value) Then
                    DateTimePicker1.Value = CType(selectedRow.Cells("DateofEmployment").Value, Date)
                Else
                    DateTimePicker1.Value = DateTime.Now ' Default value kung null
                End If
            Else
                ' I-clear ang TextBoxes at DateTimePicker kung walang napiling row
                Txt_EmployeeID.Text = GenerateRandomID()
                Txt_Fullname.Clear()
                Txt_Address.Clear()
                Txt_Contact.Clear()
                DateTimePicker1.Value = DateTime.Now
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Function FullnameExists(ByVal fullname As String) As Boolean
        ' Check if the fullname exists in the Employee Info table
        Dim query As String = "SELECT COUNT(*) FROM EmployeeInfo WHERE Fullname = @Fullname"
        Using conn As New SqlConnection(connectionString)
            conn.Open()
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@Fullname", fullname)
                Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                Return count > 0
            End Using
        End Using
    End Function

    Private Sub PopulateEmployeeComboBoxes()
        Try
            conn.Open()
            Dim query As String = "SELECT EmployeeID, Fullname FROM EmployeeInfo"
            cmd = New SqlCommand(query, conn)
            adapter = New SqlDataAdapter(cmd)
            dt = New DataTable()
            adapter.Fill(dt)

            ' Set ComboBox data sources
            SalaryAndIncome.Cb_EmployeeID.DataSource = dt
            SalaryAndIncome.Cb_EmployeeID.DisplayMember = "EmployeeID" ' Display full names
            SalaryAndIncome.Cb_EmployeeID.ValueMember = "EmployeeID" ' Use employee IDs as values

            SalaryAndIncome.Cb_Fullname.DataSource = dt
            SalaryAndIncome.Cb_Fullname.DisplayMember = "Fullname" ' Display full names
            SalaryAndIncome.Cb_Fullname.ValueMember = "EmployeeID" ' Use employee IDs as values

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub Btn_Submit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Submit.Click
        ' Validate required fields
        If String.IsNullOrWhiteSpace(Txt_Fullname.Text) OrElse String.IsNullOrWhiteSpace(Txt_Address.Text) OrElse String.IsNullOrWhiteSpace(Txt_Contact.Text) Then
            MessageBox.Show("Please fill in all required fields.", "Incomplete Field", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return ' Exit if any field is empty
        End If

        ' Validate phone number
        Dim contactNumber As String = Txt_Contact.Text.Trim()
        If Not IsValidPhoneNumber(contactNumber) Then
            MessageBox.Show("Please enter a valid phone number.", "Invalid Phone Number", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Txt_Contact.Clear()
            Txt_Contact.Focus()
            Return ' Exit if phone number is invalid
        End If

        ' Check for duplicate fullname
        If FullnameExists(Txt_Fullname.Text.Trim()) Then
            MessageBox.Show("An employee with the same fullname already exists.", "Duplicate Fullname", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Txt_Fullname.Clear()
            Txt_Fullname.Focus()
            Return ' Exit if fullname already exists
        End If

        ' Generate a unique employee ID
        Dim employeeID As String = GenerateRandomID()

        Try
            ' SQL query with IDENTITY_INSERT enabled
            Dim insertQuery As String = "SET IDENTITY_INSERT EmployeeInfo ON; " &
                                         "INSERT INTO EmployeeInfo (EmployeeID, Fullname, Address, ContactNumber, DateofEmployment) " &
                                         "VALUES (@EmployeeID, @Fullname, @Address, @ContactNumber, @DateOfEmployment); "

            Using conn As New SqlConnection(connectionString)
                conn.Open()
                Using cmd As New SqlCommand(insertQuery, conn)
                    ' Add parameters
                    cmd.Parameters.AddWithValue("@EmployeeID", employeeID)
                    cmd.Parameters.AddWithValue("@Fullname", Txt_Fullname.Text.Trim())
                    cmd.Parameters.AddWithValue("@Address", Txt_Address.Text.Trim())
                    cmd.Parameters.AddWithValue("@ContactNumber", contactNumber)
                    cmd.Parameters.AddWithValue("@DateOfEmployment", DateTimePicker1.Value)

                    ' Execute query
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            ' Display success message
            MessageBox.Show("Employee information submitted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Refresh the employee list and clear input fields
            RefreshDataGridView1EmployeeInfo()
            DataGridView1.ClearSelection()
            ClearTextBoxes()
        Catch ex As Exception
            ' Handle database errors
            MessageBox.Show("Error: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        ' Update combo boxes with new employee data
        PopulateEmployeeComboBoxes()
    End Sub
    Private Sub RefreshDataGridView3EmployeeSalary()
        Try
            Using conn As New SqlConnection(connectionString)
                conn.Open()

                Dim query As String = "SELECT s.ID, e.EmployeeID, e.FullName, e.Address, e.ContactNumber, s.Salary, s.Date " & _
                                      "FROM EmployeeInfo e " & _
                                      "JOIN EmployeeSalary s ON e.EmployeeID = s.EmployeeID"

                Using cmd As New SqlCommand(query, conn)
                    Using adapter As New SqlDataAdapter(cmd)
                        Dim dt As New DataTable()
                        adapter.Fill(dt)

                        ' I-assign ang DataTable sa DataGridView
                        SalaryAndIncome.DataGridView3.DataSource = dt

                        ' Siguraduhing mayroong column na "ContactNumber" bago i-set ang header text
                        If SalaryAndIncome.DataGridView3.Columns.Contains("ContactNumber") Then
                            SalaryAndIncome.DataGridView3.Columns("ContactNumber").HeaderText = "Contact Number"
                        End If

                        ' Set column alignment at formatting
                        For Each col As DataGridViewColumn In SalaryAndIncome.DataGridView3.Columns
                            col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                            If col.Name = "Date" Then
                                col.DefaultCellStyle.Format = "MMMM dd, yyyy"
                            End If
                        Next

                        ' I-align ang row headers
                        SalaryAndIncome.DataGridView3.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
   Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim employeeIDsToDelete As New List(Of Integer)
            Dim employeeInfoBackupValues As New List(Of String)
            Dim employeeNames As New Dictionary(Of Integer, String)

            ' Gather selected EmployeeIDs, Fullnames, and prepare EmployeeInfo backup values.
            For Each selectedRow As DataGridViewRow In DataGridView1.SelectedRows
                Dim employeeID As Integer = Convert.ToInt32(selectedRow.Cells("EmployeeID").Value)
                employeeIDsToDelete.Add(employeeID)

                Dim fullname As String = selectedRow.Cells("Fullname").Value.ToString()
                employeeNames(employeeID) = fullname  ' Save the fullname for later confirmation

                Dim address As String = selectedRow.Cells("Address").Value.ToString()
                Dim contact As String = selectedRow.Cells("ContactNumber").Value.ToString()
                Dim dateOfEmployment As String = selectedRow.Cells("DateofEmployment").Value.ToString()
                employeeInfoBackupValues.Add("(" & employeeID & ", '" & fullname.Replace("'", "''") & "', '" & address.Replace("'", "''") & "', '" & contact.Replace("'", "''") & "', '" & dateOfEmployment.Replace("'", "''") & "')")
            Next

            ' --- Step 1: Check for associated salary records for each EmployeeID ---
            Dim salaryCounts As New Dictionary(Of Integer, Integer)
            Try
                Using connCheck As New SqlConnection(connectionString)
                    connCheck.Open()
                    For Each id As Integer In employeeIDsToDelete
                        Dim countQuery As String = "SELECT COUNT(*) FROM EmployeeSalary WHERE EmployeeID = @EmployeeID"
                        Using cmdCount As New SqlCommand(countQuery, connCheck)
                            cmdCount.Parameters.AddWithValue("@EmployeeID", id)
                            Dim count As Integer = Convert.ToInt32(cmdCount.ExecuteScalar())
                            salaryCounts(id) = count
                        End Using
                    Next
                End Using
            Catch ex As Exception
                MessageBox.Show("Error while checking salary records: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try

            ' Determine if any selected employee has salary records.
            Dim hasSalaryRecords As Boolean = salaryCounts.Values.Any(Function(c) c > 0)

            ' --- Step 2: Build and show a confirmation message ---
            Dim confirmDetails As String = ""
            If hasSalaryRecords Then
                confirmDetails = "The following employees have associated salary records:" & Environment.NewLine & Environment.NewLine
                For Each id As Integer In employeeIDsToDelete
                    confirmDetails &= "EmployeeID: " & id.ToString() & ", Fullname: " & employeeNames(id) & ", Salary Record(s): " & salaryCounts(id).ToString() & Environment.NewLine
                Next
                confirmDetails &= Environment.NewLine & "Are you sure you want to delete these records (including the associated salary records)?"
            Else
                ' If no salary records exist, show a simple confirmation message.
                confirmDetails = "Are you sure you want to delete the following records?" & Environment.NewLine & Environment.NewLine
                For Each id As Integer In employeeIDsToDelete
                    confirmDetails &= "EmployeeID: " & id.ToString() & ", Fullname: " & employeeNames(id) & Environment.NewLine
                Next
            End If

            Dim confirmResult As DialogResult = MessageBox.Show(confirmDetails, "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If confirmResult <> DialogResult.Yes Then
                Exit Sub
            End If

            ' --- Step 3: Backup and deletion process ---
            Try
                Using conn As New SqlConnection(connectionString)
                    conn.Open()

                    ' Update the backup query: exclude the [ID] column.
                    Dim backupSalaryQuery As String = "INSERT INTO EmployeeSalaryBackup ([EmployeeID], [Fullname], [Address], [ContactNumber], [Salary], [Date]) " & _
                                                      "SELECT s.[EmployeeID], i.[Fullname], i.[Address], i.[ContactNumber], s.[Salary], s.[Date] " & _
                                                      "FROM EmployeeSalary s " & _
                                                      "INNER JOIN EmployeeInfo i ON s.EmployeeID = i.EmployeeID " & _
                                                      "WHERE s.EmployeeID = @EmployeeID"
                    Dim deleteSalaryQuery As String = "DELETE FROM EmployeeSalary WHERE EmployeeID = @EmployeeID"

                    For Each id As Integer In employeeIDsToDelete
                        ' Backup salary records (if any exist)
                        Using cmdBackupSalary As New SqlCommand(backupSalaryQuery, conn)
                            cmdBackupSalary.Parameters.AddWithValue("@EmployeeID", id)
                            cmdBackupSalary.ExecuteNonQuery()
                        End Using

                        ' Delete salary records for the employee
                        Using cmdDeleteSalary As New SqlCommand(deleteSalaryQuery, conn)
                            cmdDeleteSalary.Parameters.AddWithValue("@EmployeeID", id)
                            cmdDeleteSalary.ExecuteNonQuery()
                        End Using
                    Next

                    ' Backup EmployeeInfo records in bulk into EmployeeInfoBackup.
                    If employeeInfoBackupValues.Count > 0 Then
                        Dim insertEmployeeInfoBackupQuery As String = "INSERT INTO EmployeeInfoBackup (EmployeeID, Fullname, Address, ContactNumber, DateofEmployment) VALUES " & _
                                                                       String.Join(",", employeeInfoBackupValues)
                        Using cmdInsertEmployeeInfoBackup As New SqlCommand(insertEmployeeInfoBackupQuery, conn)
                            cmdInsertEmployeeInfoBackup.ExecuteNonQuery()
                        End Using
                    End If

                    ' Delete EmployeeInfo records now that the dependent salary records have been removed.
                    Dim deleteEmployeeInfoQuery As String = "DELETE FROM EmployeeInfo WHERE EmployeeID = @EmployeeID"
                    For Each id As Integer In employeeIDsToDelete
                        Using cmdDeleteEmployeeInfo As New SqlCommand(deleteEmployeeInfoQuery, conn)
                            cmdDeleteEmployeeInfo.Parameters.AddWithValue("@EmployeeID", id)
                            Dim rowsAffected As Integer = cmdDeleteEmployeeInfo.ExecuteNonQuery()
                            If rowsAffected = 0 Then
                                MessageBox.Show("Deletion failed for EmployeeID: " & id, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            End If
                        End Using
                    Next

                    MessageBox.Show("Records deleted and backed up successfully!", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    ' Refresh the DataGridView and clear inputs.
                    RefreshDataGridView1EmployeeInfo()
                    DataGridView1.ClearSelection()
                    ClearTextBoxes()
                    PopulateEmployeeComboBoxes()
                    RefreshDataGridView3EmployeeSalary()
                End Using
            Catch ex As Exception
                MessageBox.Show("Error during deletion: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

        Else
            MessageBox.Show("Please select records to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub Btn_Update_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Update.Click
        Try
            ' Get data from textboxes
            Dim employeeID As String = Txt_EmployeeID.Text
            Dim fullname As String = Txt_Fullname.Text
            Dim address As String = Txt_Address.Text
            Dim contactNumber As String = Txt_Contact.Text
            Dim dateOfEmployment As Date = DateTimePicker1.Value

            ' Check if any of the required fields are empty
            If fullname.Trim() = "" OrElse address.Trim() = "" OrElse contactNumber.Trim() = "" Then
                MessageBox.Show("Please select a single record to update.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return ' Exit the method if any field is empty
            End If

            ' Check if the phone number is in the correct format
            If Not IsValidPhoneNumber(contactNumber) Then
                MessageBox.Show("Please enter a valid phone number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Contact.Clear()
                Txt_Contact.Focus()
                Return ' Exit the method if the phone number is invalid
            End If

            ' SQL query to update data in the Employee Info table
            Dim updateQuery As String = "UPDATE EmployeeInfo SET Fullname = @Fullname, Address = @Address, ContactNumber = @ContactNumber, DateofEmployment = @DateOfEmployment WHERE EmployeeID = @EmployeeID"

            Using conn As New SqlConnection(connectionString)
                conn.Open()
                Using cmd As New SqlCommand(updateQuery, conn)
                    ' Add parameters to the command
                    cmd.Parameters.AddWithValue("@Fullname", fullname)
                    cmd.Parameters.AddWithValue("@Address", address)
                    cmd.Parameters.AddWithValue("@ContactNumber", contactNumber)
                    cmd.Parameters.AddWithValue("@DateOfEmployment", dateOfEmployment)
                    cmd.Parameters.AddWithValue("@EmployeeID", employeeID)

                    ' Execute the query
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            MessageBox.Show("Employee information updated successfully.", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Refresh the DataGridView1 to display the updated employee list
            RefreshDataGridView1EmployeeInfo()
            DataGridView1.ClearSelection()
            ClearTextBoxes()
            PopulateEmployeeComboBoxes()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_UserInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_UserInfo.Click
        Me.Hide()
        UserProfile.Show()
        ClearTextBoxes()
    End Sub

    Private Sub Btn_Logout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Logout.Click
        Dim _exit As DialogResult = MessageBox.Show("Are you sure you want to Logout", "Logout", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)
        If _exit = vbOK Then
            Login.Show()
            Me.Hide()
            Login.Txt_Username.Focus()
            Login.Txt_Password.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub Txt_Fullname_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Fullname.KeyPress
        ' Payagan ang control characters tulad ng Backspace, Enter, etc.
        If Char.IsControl(e.KeyChar) Then Exit Sub

        ' Papayagan lang ang mga letra, dot, at space
        If Not Char.IsLetter(e.KeyChar) AndAlso e.KeyChar <> "."c AndAlso e.KeyChar <> " "c Then
            e.Handled = True
            Exit Sub
        End If

        ' Kung key na pinindot ay letra, i-format ito base sa posisyon
        If Char.IsLetter(e.KeyChar) Then
            Dim pos As Integer = Txt_Fullname.SelectionStart
            ' Kung unang character ng textbox o pagkatapos ng space, gawing uppercase
            If pos = 0 OrElse (pos > 0 AndAlso Txt_Fullname.Text.Chars(pos - 1) = " "c) Then
                e.KeyChar = Char.ToUpper(e.KeyChar)
            Else
                ' Kung nasa gitna ng salita, gawing lowercase
                e.KeyChar = Char.ToLower(e.KeyChar)
            End If
        End If
    End Sub

End Class