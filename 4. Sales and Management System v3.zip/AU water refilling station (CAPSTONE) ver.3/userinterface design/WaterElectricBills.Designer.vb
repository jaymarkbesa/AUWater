﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WaterElectricBills
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(WaterElectricBills))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Btn_UserInfo = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Btn_Logout = New System.Windows.Forms.Button()
        Me.Btn_Recycle = New System.Windows.Forms.Button()
        Me.Btn_Reports = New System.Windows.Forms.Button()
        Me.Btn_EmployeeInfo = New System.Windows.Forms.Button()
        Me.Btn_Bills = New System.Windows.Forms.Button()
        Me.Btn_Calculation = New System.Windows.Forms.Button()
        Me.Btn_Home = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Cb_Year = New System.Windows.Forms.ComboBox()
        Me.Cb_Month = New System.Windows.Forms.ComboBox()
        Me.Btn_Refresh = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Txt_Search = New System.Windows.Forms.TextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Txt_WaterBill = New System.Windows.Forms.TextBox()
        Me.Txt_WaterFilter = New System.Windows.Forms.TextBox()
        Me.Txt_Electricity = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Btn_Update = New System.Windows.Forms.Button()
        Me.Btn_Delete = New System.Windows.Forms.Button()
        Me.Btn_Submit = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Btn_UserInfo)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Btn_Logout)
        Me.Panel1.Controls.Add(Me.Btn_Recycle)
        Me.Panel1.Controls.Add(Me.Btn_Reports)
        Me.Panel1.Controls.Add(Me.Btn_EmployeeInfo)
        Me.Panel1.Controls.Add(Me.Btn_Bills)
        Me.Panel1.Controls.Add(Me.Btn_Calculation)
        Me.Panel1.Controls.Add(Me.Btn_Home)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(284, 789)
        Me.Panel1.TabIndex = 77
        '
        'Btn_UserInfo
        '
        Me.Btn_UserInfo.BackColor = System.Drawing.Color.Transparent
        Me.Btn_UserInfo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_UserInfo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_UserInfo.FlatAppearance.BorderSize = 0
        Me.Btn_UserInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_UserInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_UserInfo.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_settings_32
        Me.Btn_UserInfo.Location = New System.Drawing.Point(164, 224)
        Me.Btn_UserInfo.Name = "Btn_UserInfo"
        Me.Btn_UserInfo.Size = New System.Drawing.Size(42, 38)
        Me.Btn_UserInfo.TabIndex = 76
        Me.Btn_UserInfo.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(70, 231)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 27)
        Me.Label1.TabIndex = 75
        Me.Label1.Text = "ADMIN"
        '
        'Btn_Logout
        '
        Me.Btn_Logout.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Logout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Logout.FlatAppearance.BorderSize = 0
        Me.Btn_Logout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Logout.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Logout.ForeColor = System.Drawing.Color.White
        Me.Btn_Logout.Location = New System.Drawing.Point(27, 719)
        Me.Btn_Logout.Name = "Btn_Logout"
        Me.Btn_Logout.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Logout.TabIndex = 72
        Me.Btn_Logout.Text = "LOGOUT"
        Me.Btn_Logout.UseVisualStyleBackColor = False
        '
        'Btn_Recycle
        '
        Me.Btn_Recycle.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Recycle.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Recycle.FlatAppearance.BorderSize = 0
        Me.Btn_Recycle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Recycle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Recycle.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Recycle.ForeColor = System.Drawing.Color.White
        Me.Btn_Recycle.Location = New System.Drawing.Point(27, 565)
        Me.Btn_Recycle.Name = "Btn_Recycle"
        Me.Btn_Recycle.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Recycle.TabIndex = 71
        Me.Btn_Recycle.Text = "RECYCLE BIN"
        Me.Btn_Recycle.UseVisualStyleBackColor = False
        '
        'Btn_Reports
        '
        Me.Btn_Reports.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Reports.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Reports.FlatAppearance.BorderSize = 0
        Me.Btn_Reports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Reports.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Reports.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Reports.ForeColor = System.Drawing.Color.White
        Me.Btn_Reports.Location = New System.Drawing.Point(27, 510)
        Me.Btn_Reports.Name = "Btn_Reports"
        Me.Btn_Reports.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Reports.TabIndex = 70
        Me.Btn_Reports.Text = "REPORTS"
        Me.Btn_Reports.UseVisualStyleBackColor = False
        '
        'Btn_EmployeeInfo
        '
        Me.Btn_EmployeeInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_EmployeeInfo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_EmployeeInfo.FlatAppearance.BorderSize = 0
        Me.Btn_EmployeeInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_EmployeeInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_EmployeeInfo.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_EmployeeInfo.ForeColor = System.Drawing.Color.White
        Me.Btn_EmployeeInfo.Location = New System.Drawing.Point(27, 345)
        Me.Btn_EmployeeInfo.Name = "Btn_EmployeeInfo"
        Me.Btn_EmployeeInfo.Size = New System.Drawing.Size(231, 49)
        Me.Btn_EmployeeInfo.TabIndex = 69
        Me.Btn_EmployeeInfo.Text = "EMPLOYEE INFORMATION"
        Me.Btn_EmployeeInfo.UseVisualStyleBackColor = False
        '
        'Btn_Bills
        '
        Me.Btn_Bills.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Bills.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Bills.FlatAppearance.BorderSize = 2
        Me.Btn_Bills.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Bills.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Bills.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Bills.ForeColor = System.Drawing.Color.White
        Me.Btn_Bills.Location = New System.Drawing.Point(27, 455)
        Me.Btn_Bills.Name = "Btn_Bills"
        Me.Btn_Bills.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Bills.TabIndex = 68
        Me.Btn_Bills.Text = "WATER BILLS AND ELECTRICITY"
        Me.Btn_Bills.UseVisualStyleBackColor = False
        '
        'Btn_Calculation
        '
        Me.Btn_Calculation.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Calculation.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Calculation.FlatAppearance.BorderSize = 0
        Me.Btn_Calculation.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Calculation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Calculation.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Calculation.ForeColor = System.Drawing.Color.White
        Me.Btn_Calculation.Location = New System.Drawing.Point(27, 400)
        Me.Btn_Calculation.Name = "Btn_Calculation"
        Me.Btn_Calculation.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Calculation.TabIndex = 67
        Me.Btn_Calculation.Text = "SALARY AND INCOME CALCULATION"
        Me.Btn_Calculation.UseVisualStyleBackColor = False
        '
        'Btn_Home
        '
        Me.Btn_Home.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Home.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Home.FlatAppearance.BorderSize = 0
        Me.Btn_Home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Home.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Home.ForeColor = System.Drawing.Color.White
        Me.Btn_Home.Location = New System.Drawing.Point(27, 290)
        Me.Btn_Home.Name = "Btn_Home"
        Me.Btn_Home.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Home.TabIndex = 65
        Me.Btn_Home.Text = "HOME"
        Me.Btn_Home.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = Global.WindowsApplication1.My.Resources.Resources._439432707_3811750089048465_8998649572546640568_n_removebg_preview1
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(284, 218)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 64
        Me.PictureBox1.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(1093, 177)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(78, 27)
        Me.Label4.TabIndex = 126
        Me.Label4.Text = "Year :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(922, 177)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(95, 27)
        Me.Label5.TabIndex = 125
        Me.Label5.Text = "Month :"
        '
        'Cb_Year
        '
        Me.Cb_Year.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Year.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Year.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Year.FormattingEnabled = True
        Me.Cb_Year.Location = New System.Drawing.Point(1098, 207)
        Me.Cb_Year.Name = "Cb_Year"
        Me.Cb_Year.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Year.TabIndex = 10
        '
        'Cb_Month
        '
        Me.Cb_Month.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Month.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Month.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Month.FormattingEnabled = True
        Me.Cb_Month.Location = New System.Drawing.Point(927, 207)
        Me.Cb_Month.Name = "Cb_Month"
        Me.Cb_Month.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Month.TabIndex = 9
        '
        'Btn_Refresh
        '
        Me.Btn_Refresh.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Refresh.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Refresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Btn_Refresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Refresh.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Refresh.ForeColor = System.Drawing.Color.White
        Me.Btn_Refresh.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_refresh_24
        Me.Btn_Refresh.Location = New System.Drawing.Point(653, 204)
        Me.Btn_Refresh.Name = "Btn_Refresh"
        Me.Btn_Refresh.Size = New System.Drawing.Size(44, 37)
        Me.Btn_Refresh.TabIndex = 8
        Me.Btn_Refresh.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView1.Cursor = System.Windows.Forms.Cursors.Hand
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.GridColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView1.Location = New System.Drawing.Point(303, 247)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(126, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(221, Byte), Integer))
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(968, 520)
        Me.DataGridView1.TabIndex = 122
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(304, 208)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(102, 27)
        Me.Label6.TabIndex = 121
        Me.Label6.Text = "Search :"
        '
        'Txt_Search
        '
        Me.Txt_Search.BackColor = System.Drawing.Color.White
        Me.Txt_Search.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Search.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Search.Location = New System.Drawing.Point(412, 208)
        Me.Txt_Search.Name = "Txt_Search"
        Me.Txt_Search.Size = New System.Drawing.Size(235, 27)
        Me.Txt_Search.TabIndex = 7
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(519, 143)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(299, 22)
        Me.DateTimePicker1.TabIndex = 3
        '
        'Txt_WaterBill
        '
        Me.Txt_WaterBill.BackColor = System.Drawing.Color.White
        Me.Txt_WaterBill.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_WaterBill.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_WaterBill.Location = New System.Drawing.Point(519, 66)
        Me.Txt_WaterBill.Name = "Txt_WaterBill"
        Me.Txt_WaterBill.Size = New System.Drawing.Size(299, 27)
        Me.Txt_WaterBill.TabIndex = 1
        '
        'Txt_WaterFilter
        '
        Me.Txt_WaterFilter.BackColor = System.Drawing.Color.White
        Me.Txt_WaterFilter.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_WaterFilter.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_WaterFilter.Location = New System.Drawing.Point(519, 105)
        Me.Txt_WaterFilter.Name = "Txt_WaterFilter"
        Me.Txt_WaterFilter.Size = New System.Drawing.Size(299, 27)
        Me.Txt_WaterFilter.TabIndex = 2
        '
        'Txt_Electricity
        '
        Me.Txt_Electricity.BackColor = System.Drawing.Color.White
        Me.Txt_Electricity.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Electricity.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Electricity.Location = New System.Drawing.Point(519, 31)
        Me.Txt_Electricity.Name = "Txt_Electricity"
        Me.Txt_Electricity.Size = New System.Drawing.Size(299, 27)
        Me.Txt_Electricity.TabIndex = 0
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(430, 140)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(77, 27)
        Me.Label18.TabIndex = 133
        Me.Label18.Text = "Date :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(366, 63)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(134, 27)
        Me.Label17.TabIndex = 132
        Me.Label17.Text = "Water Bill :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(343, 102)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(157, 27)
        Me.Label10.TabIndex = 131
        Me.Label10.Text = "Water Filter :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(316, 28)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(180, 27)
        Me.Label2.TabIndex = 130
        Me.Label2.Text = "Electricity Bill :"
        '
        'Btn_Update
        '
        Me.Btn_Update.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Update.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Update.FlatAppearance.BorderSize = 0
        Me.Btn_Update.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Update.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Update.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Update.ForeColor = System.Drawing.Color.White
        Me.Btn_Update.Location = New System.Drawing.Point(1019, 61)
        Me.Btn_Update.Name = "Btn_Update"
        Me.Btn_Update.Size = New System.Drawing.Size(123, 49)
        Me.Btn_Update.TabIndex = 5
        Me.Btn_Update.Text = "UPDATE"
        Me.Btn_Update.UseVisualStyleBackColor = False
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Delete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Delete.FlatAppearance.BorderSize = 0
        Me.Btn_Delete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Delete.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Delete.ForeColor = System.Drawing.Color.White
        Me.Btn_Delete.Location = New System.Drawing.Point(1148, 61)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(123, 49)
        Me.Btn_Delete.TabIndex = 6
        Me.Btn_Delete.Text = "DELETE"
        Me.Btn_Delete.UseVisualStyleBackColor = False
        '
        'Btn_Submit
        '
        Me.Btn_Submit.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Submit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Submit.FlatAppearance.BorderSize = 0
        Me.Btn_Submit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Submit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Submit.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Submit.ForeColor = System.Drawing.Color.White
        Me.Btn_Submit.Location = New System.Drawing.Point(890, 61)
        Me.Btn_Submit.Name = "Btn_Submit"
        Me.Btn_Submit.Size = New System.Drawing.Size(123, 49)
        Me.Btn_Submit.TabIndex = 4
        Me.Btn_Submit.Text = "SUBMIT"
        Me.Btn_Submit.UseVisualStyleBackColor = False
        '
        'WaterElectricBills
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1292, 789)
        Me.Controls.Add(Me.Btn_Update)
        Me.Controls.Add(Me.Btn_Delete)
        Me.Controls.Add(Me.Btn_Submit)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Txt_WaterBill)
        Me.Controls.Add(Me.Txt_WaterFilter)
        Me.Controls.Add(Me.Txt_Electricity)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Cb_Year)
        Me.Controls.Add(Me.Cb_Month)
        Me.Controls.Add(Me.Btn_Refresh)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Txt_Search)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "WaterElectricBills"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AU WATER REFILLING STATION"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Btn_UserInfo As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Btn_Logout As System.Windows.Forms.Button
    Friend WithEvents Btn_Recycle As System.Windows.Forms.Button
    Friend WithEvents Btn_Reports As System.Windows.Forms.Button
    Friend WithEvents Btn_EmployeeInfo As System.Windows.Forms.Button
    Friend WithEvents Btn_Bills As System.Windows.Forms.Button
    Friend WithEvents Btn_Calculation As System.Windows.Forms.Button
    Friend WithEvents Btn_Home As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Cb_Year As System.Windows.Forms.ComboBox
    Friend WithEvents Cb_Month As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_Refresh As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_Search As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Txt_WaterBill As System.Windows.Forms.TextBox
    Friend WithEvents Txt_WaterFilter As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Electricity As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Btn_Update As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Submit As System.Windows.Forms.Button
End Class
