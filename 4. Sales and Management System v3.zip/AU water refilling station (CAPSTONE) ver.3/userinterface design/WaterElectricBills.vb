﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Configuration
Public Class WaterElectricBills
    Dim connectionString As String = ConfigurationManager.ConnectionStrings("MyDB").ConnectionString
    Dim conn As New SqlConnection(connectionString)
    Dim cmd As SqlCommand
    Dim adapter As SqlDataAdapter
    Dim dt As DataTable
    Private Sub WaterElectricBills_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' For Tab1
        LoadMonths()
        LoadYears()

        RefreshDataGridView1Bills()
        DataGridView1.ClearSelection()

        ClearTextBoxes()
    End Sub
    Private Sub ClearTextBoxes()
        Txt_Electricity.Clear()
        Txt_WaterBill.Clear()
        Txt_WaterFilter.Clear()
        DateTimePicker1.Value = DateTime.Now
    End Sub
    Private Sub Btn_Home_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Home.Click
        Me.Hide()
        Home.Show()
        ClearTextBoxes()
        Txt_Search.Clear()
    End Sub

    Private Sub Btn_Calculation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Calculation.Click
        Me.Hide()
        SalaryAndIncome.Show()
        SalaryAndIncome.TabControl1.SelectedIndex = 0
        ClearTextBoxes()
        Txt_Search.Clear()
    End Sub

    Private Sub Btn_EmployeeInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_EmployeeInfo.Click
        Me.Hide()
        EmployeeInfo.Show()
        ClearTextBoxes()
        Txt_Search.Clear()
    End Sub

    Private Sub Btn_Reports_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Reports.Click
        Me.Hide()
        Reports.Show()
        Reports.TabControl1.SelectedIndex = 0
        ClearTextBoxes()
        Txt_Search.Clear()
    End Sub

    Private Sub Btn_Recycle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Recycle.Click
        Me.Hide()
        RecycleBin.Show()
        RecycleBin.TabControl1.SelectedIndex = 0
        ClearTextBoxes()
        Txt_Search.Clear()
    End Sub

    ' Event Handlers para sa search at filtering (trigger refresh)
    Private Sub Txt_Search_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Search.TextChanged
        RefreshDataGridView1Bills()
    End Sub

    Private Sub Cb_Month_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Month.SelectedIndexChanged
        RefreshDataGridView1Bills()
    End Sub

    Private Sub Cb_Year_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Year.SelectedIndexChanged
        RefreshDataGridView1Bills()
    End Sub

    ' Button Refresh: Nagre-refresh ng DataGridView at nire-reset ang mga filter
    Private Sub Btn_Refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh.Click

        Cb_Month.SelectedIndex = 0
        Cb_Year.SelectedItem = 0
        Txt_Search.Clear()
        RefreshDataGridView1Bills()
        DataGridView1.ClearSelection()

        ClearTextBoxes() ' Siguraduhing mayroon kang function na ito para i-clear ang input fields
    End Sub
    Private Sub Txt_Search_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Search.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        ' Limit the length of the text to 11 characters
        If Txt_Search.TextLength >= 11 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    ' Function para i-load ang listahan ng Months (January - December)
    Private Sub LoadMonths()
        Cb_Month.Items.Clear()
        Cb_Month.Items.Add("All") ' Default option

        Dim monthNames() As String = {"January", "February", "March", "April", "May", "June", _
                                      "July", "August", "September", "October", "November", "December"}
        For Each month As String In monthNames
            Cb_Month.Items.Add(month)
        Next

        Cb_Month.SelectedIndex = 0 ' Default select "All"
    End Sub

    ' Function para i-load ang listahan ng Years (Fixed from 2024 - 2050)
    Private Sub LoadYears()
        Dim startYear As Integer = 2024
        Dim endYear As Integer = 2050

        Try
            Cb_Year.Items.Clear()
            Cb_Year.Items.Add("All") ' Default option

            For year As Integer = startYear To endYear
                Cb_Year.Items.Add(year.ToString())
            Next

            Cb_Year.SelectedIndex = 0 ' Default select "All"
        Catch ex As Exception
            MessageBox.Show("Error loading years: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Main function para i-refresh ang DataGridView1 (Bills)
    Private Sub RefreshDataGridView1Bills()
        Try
            ' Base query: gumagamit ng WHERE 1=1 para madaling maidagdag ang filters
            Dim query As String = "SELECT ID, Electricity, Water, WaterFilter, Total, Date FROM Bills WHERE 1=1"

            ' ✅ Search Filter: Hinahanap ang search keyword sa mga numeric/text columns
            Dim searchKeyword As String = Txt_Search.Text.Trim()
            If Not String.IsNullOrEmpty(searchKeyword) Then
                query &= " AND (CAST(ID AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(Electricity AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(Water AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(WaterFilter AS VARCHAR(50)) LIKE @Search OR " & _
                         "CAST(Total AS VARCHAR(50)) LIKE @Search)"
            End If

            ' ✅ Month Filtering gamit ang Date column
            Dim selectedMonth As String = "All"
            Dim monthNumber As Integer = 0
            If Cb_Month.SelectedItem IsNot Nothing Then
                selectedMonth = Cb_Month.SelectedItem.ToString()
            End If
            If selectedMonth <> "All" Then
                monthNumber = Array.IndexOf(New String() {"January", "February", "March", "April", "May", "June", _
                                                          "July", "August", "September", "October", "November", "December"}, selectedMonth) + 1
                query &= " AND MONTH(Date) = @Month"
            End If

            ' ✅ Year Filtering gamit ang Date column
            Dim selectedYear As String = "All"
            If Cb_Year.SelectedItem IsNot Nothing Then
                selectedYear = Cb_Year.SelectedItem.ToString()
            End If
            If selectedYear <> "All" Then
                query &= " AND YEAR(Date) = @Year"
            End If

            ' ✅ Sorting by Date: Gamitin ang ASC para ang latest na insert ay nasa baba
            query &= " ORDER BY Date ASC"

            Dim dt As New DataTable()

            ' Using block para sa tamang pamamahala ng connection at parameters
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    If Not String.IsNullOrEmpty(searchKeyword) Then
                        cmd.Parameters.AddWithValue("@Search", "%" & searchKeyword & "%")
                    End If
                    If selectedMonth <> "All" Then
                        cmd.Parameters.AddWithValue("@Month", monthNumber)
                    End If
                    If selectedYear <> "All" Then
                        cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(selectedYear))
                    End If

                    conn.Open()
                    Dim adapter As New SqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using

            ' I-bind ang DataTable sa DataGridView1
            DataGridView1.DataSource = dt

            ' I-update ang header texts at i-set ang alignment
            DataGridView1.Columns("WaterFilter").HeaderText = "Water Filter"
            For Each col As DataGridViewColumn In DataGridView1.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                If col.Name = "Date" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next
            DataGridView1.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub Txt_Electricity_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Electricity.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If

    End Sub

    Private Sub Txt_WaterBill_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_WaterBill.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub Txt_WaterFilter_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_WaterFilter.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        Dim txt As TextBox = CType(sender, TextBox)
        If txt.Text = "0" AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    Private Sub DataGridView1_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles DataGridView1.SelectionChanged
        If DataGridView1.SelectedRows.Count > 1 Then
            Btn_Update.Enabled = False ' Disable the update button if more than one row is selected
            Btn_Submit.Enabled = False
        Else
            Btn_Update.Enabled = True ' Enable the update button if only one row is selected
            Btn_Submit.Enabled = True
        End If
        ' Check if there is a selected row
        If DataGridView1.SelectedRows.Count > 0 Then
            ' Get the values from the selected row and display them in the input fields
            Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)
            Txt_Electricity.Text = selectedRow.Cells("Electricity").Value.ToString()
            Txt_WaterBill.Text = selectedRow.Cells("Water").Value.ToString()
            Txt_WaterFilter.Text = selectedRow.Cells("WaterFilter").Value.ToString()
            DateTimePicker1.Value = Convert.ToDateTime(selectedRow.Cells("Date").Value)
        Else
            Txt_Electricity.Clear()
            Txt_WaterBill.Clear()
            Txt_WaterFilter.Clear()
            DateTimePicker1.Value = DateTime.Now
        End If
    End Sub

    Private Sub Btn_Submit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Submit.Click
        Try
            ' Check if any of the required fields are empty
            If Txt_Electricity.Text.Trim() = "" OrElse Txt_WaterBill.Text.Trim() = "" OrElse Txt_WaterFilter.Text.Trim() = "" Then
                MessageBox.Show("Please fill in all required fields.", "Incomplete field", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return ' Exit the method if any field is empty
            End If

            ' Calculate the total by adding values from Electricity, Water, and Water Filter columns
            Dim electricity As Decimal = Decimal.Parse(Txt_Electricity.Text)
            Dim water As Decimal = Decimal.Parse(Txt_WaterBill.Text)
            Dim waterFilter As Decimal = Decimal.Parse(Txt_WaterFilter.Text)
            Dim total As Decimal = electricity + water + waterFilter

            ' Open the connection and check if the date exists before inserting
            Using conn As New SqlConnection(connectionString)
                conn.Open()

                Dim checkQuery As String = "SELECT COUNT(*) FROM Bills WHERE [Date] = @Date"
                Using checkCmd As New SqlCommand(checkQuery, conn)
                    checkCmd.Parameters.AddWithValue("@Date", DateTimePicker1.Value.Date)

                    Dim dateExists As Integer = Convert.ToInt32(checkCmd.ExecuteScalar())
                    If dateExists > 0 Then
                        MessageBox.Show("The selected date already exists.", "Duplicate Date", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        Return ' Exit if the date already exists
                    End If
                End Using

                ' SQL query to insert data into the Expenses table
                Dim query As String = "INSERT INTO Bills (Electricity, Water, WaterFilter, Total, Date) VALUES (@Electricity, @Water, @WaterFilter, @Total, @Date)"
                Using cmd As New SqlCommand(query, conn)
                    ' Add parameter values
                    cmd.Parameters.AddWithValue("@Electricity", electricity)
                    cmd.Parameters.AddWithValue("@Water", water)
                    cmd.Parameters.AddWithValue("@WaterFilter", waterFilter)
                    cmd.Parameters.AddWithValue("@Total", total)
                    cmd.Parameters.AddWithValue("@Date", DateTimePicker1.Value.Date)

                    ' Execute the query
                    cmd.ExecuteNonQuery()

                    ' Show a success message
                    MessageBox.Show("Data submitted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    ' Refresh the DataGridView
                    RefreshDataGridView1Bills()
                    DataGridView1.ClearSelection()

                    ' Clear the textboxes
                    ClearTextBoxes()
                End Using
            End Using
        Catch ex As Exception
            ' Show error message if an exception occurs
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub
    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        ' Ensure at least one row is selected
        If DataGridView1.SelectedRows.Count > 0 Then
            ' Confirmation message before deleting the records
            Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete the selected record(s)?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If result = DialogResult.Yes Then
                Try
                    Using conn As New SqlConnection(connectionString)
                        conn.Open()

                        ' Loop through all selected rows
                        For Each selectedRow As DataGridViewRow In DataGridView1.SelectedRows
                            ' Get the ID and other necessary data of the selected row
                            Dim selectedID As Integer = Convert.ToInt32(selectedRow.Cells("ID").Value)
                            Dim electricity As Decimal = Convert.ToDecimal(selectedRow.Cells("Electricity").Value)
                            Dim water As Decimal = Convert.ToDecimal(selectedRow.Cells("Water").Value)
                            Dim waterFilter As Decimal = Convert.ToDecimal(selectedRow.Cells("WaterFilter").Value)
                            Dim total As Decimal = electricity + water + waterFilter
                            Dim dateValue As Date = Convert.ToDateTime(selectedRow.Cells("Date").Value)

                            ' Insert the data into Expenses Backup before deletion
                            Dim backupQuery As String = "INSERT INTO BillsBackup (Electricity, Water, WaterFilter, Total, Date) " & _
                                                        "VALUES (@Electricity, @Water, @WaterFilter, @Total, @Date)"

                            Using cmdBackup As New SqlCommand(backupQuery, conn)
                                ' Add parameters for the backup
                                cmdBackup.Parameters.AddWithValue("@Electricity", electricity)
                                cmdBackup.Parameters.AddWithValue("@Water", water)
                                cmdBackup.Parameters.AddWithValue("@WaterFilter", waterFilter)
                                cmdBackup.Parameters.AddWithValue("@Total", total)
                                cmdBackup.Parameters.AddWithValue("@Date", dateValue)

                                ' Execute the backup insert
                                cmdBackup.ExecuteNonQuery()
                            End Using

                            ' Now proceed to delete the record from Expenses table
                            Dim deleteQuery As String = "DELETE FROM Bills WHERE ID = @ID"

                            Using cmdDelete As New SqlCommand(deleteQuery, conn)
                                ' Add parameter for ID
                                cmdDelete.Parameters.AddWithValue("@ID", selectedID)

                                ' Execute the delete query
                                cmdDelete.ExecuteNonQuery()
                            End Using
                        Next

                        ' Display success message after both backup and delete
                        MessageBox.Show("Selected record(s) backed up and deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                        ' Refresh the DataGridView to reflect the changes
                        RefreshDataGridView1Bills()
                        DataGridView1.ClearSelection()

                        ' Clear the textboxes
                        ClearTextBoxes()
                    End Using
                Catch ex As Exception
                    ' Display error message if an exception occurs
                    MessageBox.Show("Error: " & ex.Message)
                End Try
            End If
        Else
            MessageBox.Show("Please select at least one row to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub Btn_Update_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Update.Click
        ' Ensure a row is selected
        If DataGridView1.SelectedRows.Count > 0 Then
            ' Get the ID of the selected row
            Dim selectedID As Integer = Convert.ToInt32(DataGridView1.SelectedRows(0).Cells("ID").Value)

            ' Retrieve the updated values from the input fields
            Dim electricity As Decimal
            Dim water As Decimal
            Dim waterFilter As Decimal
            If Decimal.TryParse(Txt_Electricity.Text.Trim(), electricity) AndAlso Decimal.TryParse(Txt_WaterBill.Text.Trim(), water) AndAlso Decimal.TryParse(Txt_WaterFilter.Text.Trim(), waterFilter) Then
                ' Calculate the total
                Dim total As Decimal = electricity + water + waterFilter

                ' Update query to update the record in the database
                Dim query As String = "UPDATE Bills SET Electricity = @Electricity, Water = @Water, WaterFilter = @WaterFilter, Total = @Total, Date = @Date WHERE ID = @ID"

                Try
                    Using conn As New SqlConnection(connectionString)
                        conn.Open()
                        Using cmd As New SqlCommand(query, conn)
                            ' Add parameters
                            cmd.Parameters.AddWithValue("@Electricity", electricity)
                            cmd.Parameters.AddWithValue("@Water", water)
                            cmd.Parameters.AddWithValue("@WaterFilter", waterFilter)
                            cmd.Parameters.AddWithValue("@Total", total)
                            cmd.Parameters.AddWithValue("@Date", DateTimePicker1.Value)
                            cmd.Parameters.AddWithValue("@ID", selectedID)

                            ' Execute the update query
                            Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                            ' Check if any rows were affected
                            If rowsAffected > 0 Then
                                MessageBox.Show("Data updated successfully.", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information)

                                '' Refresh the DataGridView
                                RefreshDataGridView1Bills()
                                DataGridView1.ClearSelection()

                                ' Clear the textboxes
                                ClearTextBoxes()
                            Else
                                MessageBox.Show("No record updated.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            End If
                        End Using
                    End Using
                Catch ex As Exception
                    MessageBox.Show("Error: " & ex.Message)
                End Try
            Else
                MessageBox.Show("Please enter valid numeric values for electricity, water, and water filter.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Else
            MessageBox.Show("Please select a row to update.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub
   
    Private Sub Btn_UserInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_UserInfo.Click
        Me.Hide()
        UserProfile.Show()
        ClearTextBoxes()
    End Sub

    Private Sub Btn_Logout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Logout.Click
        Dim _exit As DialogResult = MessageBox.Show("Are you sure you want to Logout", "Logout", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)
        If _exit = vbOK Then
            Login.Show()
            Me.Hide()
            Login.Txt_Username.Focus()
            Login.Txt_Password.UseSystemPasswordChar = True
        End If
    End Sub


End Class