﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SalaryAndIncome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SalaryAndIncome))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Txt_SmallContainerWater = New System.Windows.Forms.TextBox()
        Me.Txt_SmallContainer = New System.Windows.Forms.TextBox()
        Me.Txt_SmallWaterRefill = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Btn_IncomeReport = New System.Windows.Forms.Button()
        Me.Btn_Update = New System.Windows.Forms.Button()
        Me.Btn_Delete = New System.Windows.Forms.Button()
        Me.Btn_Submit = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Cb_Year = New System.Windows.Forms.ComboBox()
        Me.Cb_Month = New System.Windows.Forms.ComboBox()
        Me.Btn_Refresh = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Txt_Search = New System.Windows.Forms.TextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Txt_ContainerWater = New System.Windows.Forms.TextBox()
        Me.Txt_Container = New System.Windows.Forms.TextBox()
        Me.Txt_WaterRefill = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Txt_Search2 = New System.Windows.Forms.TextBox()
        Me.Btn_SalaryReport = New System.Windows.Forms.Button()
        Me.Cb_Fullname = New System.Windows.Forms.ComboBox()
        Me.Cb_EmployeeID = New System.Windows.Forms.ComboBox()
        Me.Txt_Address = New System.Windows.Forms.TextBox()
        Me.Txt_Contact = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Cb_Year2 = New System.Windows.Forms.ComboBox()
        Me.Cb_Month2 = New System.Windows.Forms.ComboBox()
        Me.Btn_Refresh2 = New System.Windows.Forms.Button()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Btn_Update1 = New System.Windows.Forms.Button()
        Me.Btn_Delete1 = New System.Windows.Forms.Button()
        Me.Btn_Submit1 = New System.Windows.Forms.Button()
        Me.Txt_Quantity = New System.Windows.Forms.TextBox()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Cb_Year1 = New System.Windows.Forms.ComboBox()
        Me.Cb_Month1 = New System.Windows.Forms.ComboBox()
        Me.Btn_Refresh1 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Txt_Search1 = New System.Windows.Forms.TextBox()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Btn_Refresh3 = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Cb_Year3 = New System.Windows.Forms.ComboBox()
        Me.Cb_Month3 = New System.Windows.Forms.ComboBox()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Btn_UserInfo = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Btn_Logout = New System.Windows.Forms.Button()
        Me.Btn_Recycle = New System.Windows.Forms.Button()
        Me.Btn_Reports = New System.Windows.Forms.Button()
        Me.Btn_EmployeeInfo = New System.Windows.Forms.Button()
        Me.Btn_Bills = New System.Windows.Forms.Button()
        Me.Btn_Calculation = New System.Windows.Forms.Button()
        Me.Btn_Home = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Btn_Edit = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TabControl1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(290, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.Padding = New System.Drawing.Point(20, 10)
        Me.TabControl1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.ShowToolTips = True
        Me.TabControl1.Size = New System.Drawing.Size(990, 765)
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight
        Me.TabControl1.TabIndex = 23
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage1.Controls.Add(Me.Txt_SmallContainerWater)
        Me.TabPage1.Controls.Add(Me.Txt_SmallContainer)
        Me.TabPage1.Controls.Add(Me.Txt_SmallWaterRefill)
        Me.TabPage1.Controls.Add(Me.Label15)
        Me.TabPage1.Controls.Add(Me.Label16)
        Me.TabPage1.Controls.Add(Me.Label26)
        Me.TabPage1.Controls.Add(Me.Btn_IncomeReport)
        Me.TabPage1.Controls.Add(Me.Btn_Update)
        Me.TabPage1.Controls.Add(Me.Btn_Delete)
        Me.TabPage1.Controls.Add(Me.Btn_Submit)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Cb_Year)
        Me.TabPage1.Controls.Add(Me.Cb_Month)
        Me.TabPage1.Controls.Add(Me.Btn_Refresh)
        Me.TabPage1.Controls.Add(Me.DataGridView1)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Txt_Search)
        Me.TabPage1.Controls.Add(Me.DateTimePicker1)
        Me.TabPage1.Controls.Add(Me.Txt_ContainerWater)
        Me.TabPage1.Controls.Add(Me.Txt_Container)
        Me.TabPage1.Controls.Add(Me.Txt_WaterRefill)
        Me.TabPage1.Controls.Add(Me.Label18)
        Me.TabPage1.Controls.Add(Me.Label17)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 43)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(982, 718)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Sold"
        '
        'Txt_SmallContainerWater
        '
        Me.Txt_SmallContainerWater.BackColor = System.Drawing.Color.White
        Me.Txt_SmallContainerWater.Font = New System.Drawing.Font("Times New Roman", 9.0!)
        Me.Txt_SmallContainerWater.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_SmallContainerWater.Location = New System.Drawing.Point(635, 48)
        Me.Txt_SmallContainerWater.Name = "Txt_SmallContainerWater"
        Me.Txt_SmallContainerWater.Size = New System.Drawing.Size(66, 25)
        Me.Txt_SmallContainerWater.TabIndex = 121
        Me.Txt_SmallContainerWater.Visible = False
        '
        'Txt_SmallContainer
        '
        Me.Txt_SmallContainer.BackColor = System.Drawing.Color.White
        Me.Txt_SmallContainer.Font = New System.Drawing.Font("Times New Roman", 9.0!)
        Me.Txt_SmallContainer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_SmallContainer.Location = New System.Drawing.Point(635, 79)
        Me.Txt_SmallContainer.Name = "Txt_SmallContainer"
        Me.Txt_SmallContainer.Size = New System.Drawing.Size(66, 25)
        Me.Txt_SmallContainer.TabIndex = 122
        Me.Txt_SmallContainer.Visible = False
        '
        'Txt_SmallWaterRefill
        '
        Me.Txt_SmallWaterRefill.BackColor = System.Drawing.Color.White
        Me.Txt_SmallWaterRefill.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_SmallWaterRefill.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_SmallWaterRefill.Location = New System.Drawing.Point(635, 16)
        Me.Txt_SmallWaterRefill.Name = "Txt_SmallWaterRefill"
        Me.Txt_SmallWaterRefill.Size = New System.Drawing.Size(66, 25)
        Me.Txt_SmallWaterRefill.TabIndex = 120
        Me.Txt_SmallWaterRefill.Visible = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Rockwell", 10.8!)
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(358, 48)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(260, 21)
        Me.Label15.TabIndex = 125
        Me.Label15.Text = "Small Container with water :"
        Me.Label15.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Rockwell", 10.8!)
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(359, 78)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(205, 21)
        Me.Label16.TabIndex = 124
        Me.Label16.Text = "Small Container sold :"
        Me.Label16.Visible = False
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.White
        Me.Label26.Location = New System.Drawing.Point(359, 16)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(192, 21)
        Me.Label26.TabIndex = 123
        Me.Label26.Text = "Small Water Gallon :"
        Me.Label26.Visible = False
        '
        'Btn_IncomeReport
        '
        Me.Btn_IncomeReport.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_IncomeReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_IncomeReport.FlatAppearance.BorderSize = 0
        Me.Btn_IncomeReport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_IncomeReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_IncomeReport.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_IncomeReport.ForeColor = System.Drawing.Color.White
        Me.Btn_IncomeReport.Location = New System.Drawing.Point(714, 78)
        Me.Btn_IncomeReport.Name = "Btn_IncomeReport"
        Me.Btn_IncomeReport.Size = New System.Drawing.Size(123, 49)
        Me.Btn_IncomeReport.TabIndex = 119
        Me.Btn_IncomeReport.Text = "GENERATE REPORT"
        Me.Btn_IncomeReport.UseVisualStyleBackColor = False
        '
        'Btn_Update
        '
        Me.Btn_Update.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Update.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Update.FlatAppearance.BorderSize = 0
        Me.Btn_Update.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Update.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Update.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Update.ForeColor = System.Drawing.Color.White
        Me.Btn_Update.Location = New System.Drawing.Point(843, 23)
        Me.Btn_Update.Name = "Btn_Update"
        Me.Btn_Update.Size = New System.Drawing.Size(123, 49)
        Me.Btn_Update.TabIndex = 4
        Me.Btn_Update.Text = "UPDATE"
        Me.Btn_Update.UseVisualStyleBackColor = False
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Delete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Delete.FlatAppearance.BorderSize = 0
        Me.Btn_Delete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Delete.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Delete.ForeColor = System.Drawing.Color.White
        Me.Btn_Delete.Location = New System.Drawing.Point(843, 78)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(123, 49)
        Me.Btn_Delete.TabIndex = 5
        Me.Btn_Delete.Text = "DELETE"
        Me.Btn_Delete.UseVisualStyleBackColor = False
        '
        'Btn_Submit
        '
        Me.Btn_Submit.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Submit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Submit.FlatAppearance.BorderSize = 0
        Me.Btn_Submit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Submit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Submit.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Submit.ForeColor = System.Drawing.Color.White
        Me.Btn_Submit.Location = New System.Drawing.Point(714, 23)
        Me.Btn_Submit.Name = "Btn_Submit"
        Me.Btn_Submit.Size = New System.Drawing.Size(123, 49)
        Me.Btn_Submit.TabIndex = 3
        Me.Btn_Submit.Text = "SUBMIT"
        Me.Btn_Submit.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(796, 161)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(78, 27)
        Me.Label4.TabIndex = 118
        Me.Label4.Text = "Year :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(625, 161)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(95, 27)
        Me.Label5.TabIndex = 117
        Me.Label5.Text = "Month :"
        '
        'Cb_Year
        '
        Me.Cb_Year.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Year.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Year.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Year.FormattingEnabled = True
        Me.Cb_Year.Location = New System.Drawing.Point(801, 191)
        Me.Cb_Year.Name = "Cb_Year"
        Me.Cb_Year.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Year.TabIndex = 116
        '
        'Cb_Month
        '
        Me.Cb_Month.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Month.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Month.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Month.FormattingEnabled = True
        Me.Cb_Month.Location = New System.Drawing.Point(630, 191)
        Me.Cb_Month.Name = "Cb_Month"
        Me.Cb_Month.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Month.TabIndex = 115
        '
        'Btn_Refresh
        '
        Me.Btn_Refresh.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Refresh.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Refresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Btn_Refresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Refresh.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Refresh.ForeColor = System.Drawing.Color.White
        Me.Btn_Refresh.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_refresh_24
        Me.Btn_Refresh.Location = New System.Drawing.Point(356, 188)
        Me.Btn_Refresh.Name = "Btn_Refresh"
        Me.Btn_Refresh.Size = New System.Drawing.Size(44, 37)
        Me.Btn_Refresh.TabIndex = 7
        Me.Btn_Refresh.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.GridColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView1.Location = New System.Drawing.Point(6, 234)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(126, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(221, Byte), Integer))
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(968, 454)
        Me.DataGridView1.TabIndex = 113
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(7, 192)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(102, 27)
        Me.Label3.TabIndex = 112
        Me.Label3.Text = "Search :"
        '
        'Txt_Search
        '
        Me.Txt_Search.BackColor = System.Drawing.Color.White
        Me.Txt_Search.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Search.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Search.Location = New System.Drawing.Point(115, 192)
        Me.Txt_Search.Name = "Txt_Search"
        Me.Txt_Search.Size = New System.Drawing.Size(235, 27)
        Me.Txt_Search.TabIndex = 6
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(76, 121)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(235, 25)
        Me.DateTimePicker1.TabIndex = 110
        '
        'Txt_ContainerWater
        '
        Me.Txt_ContainerWater.BackColor = System.Drawing.Color.White
        Me.Txt_ContainerWater.Font = New System.Drawing.Font("Times New Roman", 9.0!)
        Me.Txt_ContainerWater.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_ContainerWater.Location = New System.Drawing.Point(284, 48)
        Me.Txt_ContainerWater.Name = "Txt_ContainerWater"
        Me.Txt_ContainerWater.Size = New System.Drawing.Size(66, 25)
        Me.Txt_ContainerWater.TabIndex = 1
        '
        'Txt_Container
        '
        Me.Txt_Container.BackColor = System.Drawing.Color.White
        Me.Txt_Container.Font = New System.Drawing.Font("Times New Roman", 9.0!)
        Me.Txt_Container.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Container.Location = New System.Drawing.Point(284, 79)
        Me.Txt_Container.Name = "Txt_Container"
        Me.Txt_Container.Size = New System.Drawing.Size(66, 25)
        Me.Txt_Container.TabIndex = 2
        '
        'Txt_WaterRefill
        '
        Me.Txt_WaterRefill.BackColor = System.Drawing.Color.White
        Me.Txt_WaterRefill.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_WaterRefill.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_WaterRefill.Location = New System.Drawing.Point(284, 16)
        Me.Txt_WaterRefill.Name = "Txt_WaterRefill"
        Me.Txt_WaterRefill.Size = New System.Drawing.Size(66, 25)
        Me.Txt_WaterRefill.TabIndex = 0
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Rockwell", 10.8!)
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(8, 125)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(62, 21)
        Me.Label18.TabIndex = 67
        Me.Label18.Text = "Date :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Rockwell", 10.8!)
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(7, 48)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(252, 21)
        Me.Label17.TabIndex = 66
        Me.Label17.Text = "Reg. Container with water :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Rockwell", 10.8!)
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(8, 78)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(197, 21)
        Me.Label10.TabIndex = 65
        Me.Label10.Text = "Reg. Container sold :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(8, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(184, 21)
        Me.Label2.TabIndex = 64
        Me.Label2.Text = "Reg. Water Gallon :"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.Btn_Edit)
        Me.TabPage3.Controls.Add(Me.Label28)
        Me.TabPage3.Controls.Add(Me.Label27)
        Me.TabPage3.Controls.Add(Me.Label14)
        Me.TabPage3.Controls.Add(Me.Txt_Search2)
        Me.TabPage3.Controls.Add(Me.Btn_SalaryReport)
        Me.TabPage3.Controls.Add(Me.Cb_Fullname)
        Me.TabPage3.Controls.Add(Me.Cb_EmployeeID)
        Me.TabPage3.Controls.Add(Me.Txt_Address)
        Me.TabPage3.Controls.Add(Me.Txt_Contact)
        Me.TabPage3.Controls.Add(Me.Label25)
        Me.TabPage3.Controls.Add(Me.Label24)
        Me.TabPage3.Controls.Add(Me.Label23)
        Me.TabPage3.Controls.Add(Me.Label22)
        Me.TabPage3.Controls.Add(Me.Label21)
        Me.TabPage3.Controls.Add(Me.DateTimePicker2)
        Me.TabPage3.Controls.Add(Me.Label11)
        Me.TabPage3.Controls.Add(Me.Label9)
        Me.TabPage3.Controls.Add(Me.Label19)
        Me.TabPage3.Controls.Add(Me.Cb_Year2)
        Me.TabPage3.Controls.Add(Me.Cb_Month2)
        Me.TabPage3.Controls.Add(Me.Btn_Refresh2)
        Me.TabPage3.Controls.Add(Me.Label20)
        Me.TabPage3.Controls.Add(Me.Btn_Update1)
        Me.TabPage3.Controls.Add(Me.Btn_Delete1)
        Me.TabPage3.Controls.Add(Me.Btn_Submit1)
        Me.TabPage3.Controls.Add(Me.Txt_Quantity)
        Me.TabPage3.Controls.Add(Me.DataGridView3)
        Me.TabPage3.Location = New System.Drawing.Point(4, 43)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(982, 718)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Salary"
        '
        'Txt_Search2
        '
        Me.Txt_Search2.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Txt_Search2.Location = New System.Drawing.Point(113, 203)
        Me.Txt_Search2.Name = "Txt_Search2"
        Me.Txt_Search2.Size = New System.Drawing.Size(235, 27)
        Me.Txt_Search2.TabIndex = 136
        '
        'Btn_SalaryReport
        '
        Me.Btn_SalaryReport.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_SalaryReport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_SalaryReport.FlatAppearance.BorderSize = 0
        Me.Btn_SalaryReport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_SalaryReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_SalaryReport.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_SalaryReport.ForeColor = System.Drawing.Color.White
        Me.Btn_SalaryReport.Location = New System.Drawing.Point(855, 71)
        Me.Btn_SalaryReport.Name = "Btn_SalaryReport"
        Me.Btn_SalaryReport.Size = New System.Drawing.Size(113, 49)
        Me.Btn_SalaryReport.TabIndex = 135
        Me.Btn_SalaryReport.Text = "GENERATE REPORT"
        Me.Btn_SalaryReport.UseVisualStyleBackColor = False
        '
        'Cb_Fullname
        '
        Me.Cb_Fullname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Fullname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Fullname.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Fullname.FormattingEnabled = True
        Me.Cb_Fullname.Location = New System.Drawing.Point(232, 57)
        Me.Cb_Fullname.Name = "Cb_Fullname"
        Me.Cb_Fullname.Size = New System.Drawing.Size(235, 27)
        Me.Cb_Fullname.TabIndex = 1
        '
        'Cb_EmployeeID
        '
        Me.Cb_EmployeeID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_EmployeeID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_EmployeeID.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Cb_EmployeeID.Enabled = False
        Me.Cb_EmployeeID.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_EmployeeID.FormattingEnabled = True
        Me.Cb_EmployeeID.Location = New System.Drawing.Point(232, 19)
        Me.Cb_EmployeeID.Name = "Cb_EmployeeID"
        Me.Cb_EmployeeID.Size = New System.Drawing.Size(235, 27)
        Me.Cb_EmployeeID.TabIndex = 0
        '
        'Txt_Address
        '
        Me.Txt_Address.BackColor = System.Drawing.Color.White
        Me.Txt_Address.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_Address.Enabled = False
        Me.Txt_Address.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Address.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Address.Location = New System.Drawing.Point(232, 135)
        Me.Txt_Address.Name = "Txt_Address"
        Me.Txt_Address.ReadOnly = True
        Me.Txt_Address.Size = New System.Drawing.Size(235, 27)
        Me.Txt_Address.TabIndex = 3
        '
        'Txt_Contact
        '
        Me.Txt_Contact.BackColor = System.Drawing.Color.White
        Me.Txt_Contact.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_Contact.Enabled = False
        Me.Txt_Contact.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Contact.Location = New System.Drawing.Point(232, 96)
        Me.Txt_Contact.Name = "Txt_Contact"
        Me.Txt_Contact.ReadOnly = True
        Me.Txt_Contact.Size = New System.Drawing.Size(235, 27)
        Me.Txt_Contact.TabIndex = 2
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.White
        Me.Label25.Location = New System.Drawing.Point(472, 52)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(120, 27)
        Me.Label25.TabIndex = 134
        Me.Label25.Text = "Quantity :"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.White
        Me.Label24.Location = New System.Drawing.Point(98, 132)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(118, 27)
        Me.Label24.TabIndex = 133
        Me.Label24.Text = "Address :"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(3, 93)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(209, 27)
        Me.Label23.TabIndex = 132
        Me.Label23.Text = "Contact Number :"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.White
        Me.Label22.Location = New System.Drawing.Point(89, 57)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(128, 27)
        Me.Label22.TabIndex = 131
        Me.Label22.Text = "Fullname :"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.White
        Me.Label21.Location = New System.Drawing.Point(44, 21)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(170, 27)
        Me.Label21.TabIndex = 130
        Me.Label21.Text = "Employee ID :"
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(602, 19)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(235, 25)
        Me.DateTimePicker2.TabIndex = 4
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(517, 16)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(77, 27)
        Me.Label11.TabIndex = 128
        Me.Label11.Text = "Date :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(667, 174)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(78, 27)
        Me.Label9.TabIndex = 127
        Me.Label9.Text = "Year :"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(496, 174)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(95, 27)
        Me.Label19.TabIndex = 126
        Me.Label19.Text = "Month :"
        '
        'Cb_Year2
        '
        Me.Cb_Year2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Year2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Year2.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Year2.FormattingEnabled = True
        Me.Cb_Year2.Location = New System.Drawing.Point(672, 204)
        Me.Cb_Year2.Name = "Cb_Year2"
        Me.Cb_Year2.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Year2.TabIndex = 12
        '
        'Cb_Month2
        '
        Me.Cb_Month2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Month2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Month2.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Month2.FormattingEnabled = True
        Me.Cb_Month2.Location = New System.Drawing.Point(501, 204)
        Me.Cb_Month2.Name = "Cb_Month2"
        Me.Cb_Month2.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Month2.TabIndex = 11
        '
        'Btn_Refresh2
        '
        Me.Btn_Refresh2.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Refresh2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Refresh2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Btn_Refresh2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Refresh2.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Refresh2.ForeColor = System.Drawing.Color.White
        Me.Btn_Refresh2.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_refresh_24
        Me.Btn_Refresh2.Location = New System.Drawing.Point(354, 200)
        Me.Btn_Refresh2.Name = "Btn_Refresh2"
        Me.Btn_Refresh2.Size = New System.Drawing.Size(44, 37)
        Me.Btn_Refresh2.TabIndex = 10
        Me.Btn_Refresh2.UseVisualStyleBackColor = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.White
        Me.Label20.Location = New System.Drawing.Point(5, 204)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(102, 27)
        Me.Label20.TabIndex = 123
        Me.Label20.Text = "Search :"
        '
        'Btn_Update1
        '
        Me.Btn_Update1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Update1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Update1.FlatAppearance.BorderSize = 0
        Me.Btn_Update1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Update1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Update1.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Update1.ForeColor = System.Drawing.Color.White
        Me.Btn_Update1.Location = New System.Drawing.Point(855, 126)
        Me.Btn_Update1.Name = "Btn_Update1"
        Me.Btn_Update1.Size = New System.Drawing.Size(113, 49)
        Me.Btn_Update1.TabIndex = 8
        Me.Btn_Update1.Text = "UPDATE"
        Me.Btn_Update1.UseVisualStyleBackColor = False
        '
        'Btn_Delete1
        '
        Me.Btn_Delete1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Delete1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Delete1.FlatAppearance.BorderSize = 0
        Me.Btn_Delete1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Delete1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Delete1.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Delete1.ForeColor = System.Drawing.Color.White
        Me.Btn_Delete1.Location = New System.Drawing.Point(855, 181)
        Me.Btn_Delete1.Name = "Btn_Delete1"
        Me.Btn_Delete1.Size = New System.Drawing.Size(113, 49)
        Me.Btn_Delete1.TabIndex = 7
        Me.Btn_Delete1.Text = "DELETE"
        Me.Btn_Delete1.UseVisualStyleBackColor = False
        '
        'Btn_Submit1
        '
        Me.Btn_Submit1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Submit1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Submit1.FlatAppearance.BorderSize = 0
        Me.Btn_Submit1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Submit1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Submit1.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Submit1.ForeColor = System.Drawing.Color.White
        Me.Btn_Submit1.Location = New System.Drawing.Point(855, 16)
        Me.Btn_Submit1.Name = "Btn_Submit1"
        Me.Btn_Submit1.Size = New System.Drawing.Size(113, 49)
        Me.Btn_Submit1.TabIndex = 6
        Me.Btn_Submit1.Text = "SUBMIT"
        Me.Btn_Submit1.UseVisualStyleBackColor = False
        '
        'Txt_Quantity
        '
        Me.Txt_Quantity.BackColor = System.Drawing.Color.White
        Me.Txt_Quantity.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Quantity.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Quantity.Location = New System.Drawing.Point(602, 55)
        Me.Txt_Quantity.Name = "Txt_Quantity"
        Me.Txt_Quantity.Size = New System.Drawing.Size(235, 27)
        Me.Txt_Quantity.TabIndex = 5
        '
        'DataGridView3
        '
        Me.DataGridView3.AllowUserToAddRows = False
        Me.DataGridView3.AllowUserToResizeColumns = False
        Me.DataGridView3.AllowUserToResizeRows = False
        Me.DataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView3.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView3.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView3.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView3.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView3.DefaultCellStyle = DataGridViewCellStyle6
        Me.DataGridView3.GridColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView3.Location = New System.Drawing.Point(6, 248)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.ReadOnly = True
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(126, Byte), Integer))
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView3.RowHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.DataGridView3.RowHeadersVisible = False
        Me.DataGridView3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(221, Byte), Integer))
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black
        Me.DataGridView3.RowsDefaultCellStyle = DataGridViewCellStyle8
        Me.DataGridView3.RowTemplate.Height = 24
        Me.DataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView3.Size = New System.Drawing.Size(968, 441)
        Me.DataGridView3.TabIndex = 114
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.Cb_Year1)
        Me.TabPage2.Controls.Add(Me.Cb_Month1)
        Me.TabPage2.Controls.Add(Me.Btn_Refresh1)
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Controls.Add(Me.Txt_Search1)
        Me.TabPage2.Controls.Add(Me.DataGridView2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 43)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(982, 718)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Gross Revenue"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(783, 10)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 27)
        Me.Label6.TabIndex = 125
        Me.Label6.Text = "Year :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(612, 10)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(95, 27)
        Me.Label7.TabIndex = 124
        Me.Label7.Text = "Month :"
        '
        'Cb_Year1
        '
        Me.Cb_Year1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Year1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Year1.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Year1.FormattingEnabled = True
        Me.Cb_Year1.Location = New System.Drawing.Point(788, 40)
        Me.Cb_Year1.Name = "Cb_Year1"
        Me.Cb_Year1.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Year1.TabIndex = 3
        '
        'Cb_Month1
        '
        Me.Cb_Month1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Month1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Month1.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Month1.FormattingEnabled = True
        Me.Cb_Month1.Location = New System.Drawing.Point(617, 40)
        Me.Cb_Month1.Name = "Cb_Month1"
        Me.Cb_Month1.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Month1.TabIndex = 2
        '
        'Btn_Refresh1
        '
        Me.Btn_Refresh1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Refresh1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Refresh1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Btn_Refresh1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Refresh1.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Refresh1.ForeColor = System.Drawing.Color.White
        Me.Btn_Refresh1.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_refresh_24
        Me.Btn_Refresh1.Location = New System.Drawing.Point(355, 37)
        Me.Btn_Refresh1.Name = "Btn_Refresh1"
        Me.Btn_Refresh1.Size = New System.Drawing.Size(44, 37)
        Me.Btn_Refresh1.TabIndex = 1
        Me.Btn_Refresh1.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(6, 41)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(102, 27)
        Me.Label8.TabIndex = 121
        Me.Label8.Text = "Search :"
        '
        'Txt_Search1
        '
        Me.Txt_Search1.BackColor = System.Drawing.Color.White
        Me.Txt_Search1.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Search1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Search1.Location = New System.Drawing.Point(114, 41)
        Me.Txt_Search1.Name = "Txt_Search1"
        Me.Txt_Search1.Size = New System.Drawing.Size(235, 27)
        Me.Txt_Search1.TabIndex = 0
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToResizeColumns = False
        Me.DataGridView2.AllowUserToResizeRows = False
        Me.DataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView2.DefaultCellStyle = DataGridViewCellStyle10
        Me.DataGridView2.GridColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView2.Location = New System.Drawing.Point(6, 80)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.ReadOnly = True
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(126, Byte), Integer))
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView2.RowHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.DataGridView2.RowHeadersVisible = False
        Me.DataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.White
        Me.DataGridView2.RowsDefaultCellStyle = DataGridViewCellStyle12
        Me.DataGridView2.RowTemplate.Height = 24
        Me.DataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView2.Size = New System.Drawing.Size(968, 609)
        Me.DataGridView2.TabIndex = 114
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.Btn_Refresh3)
        Me.TabPage4.Controls.Add(Me.Label12)
        Me.TabPage4.Controls.Add(Me.Label13)
        Me.TabPage4.Controls.Add(Me.Cb_Year3)
        Me.TabPage4.Controls.Add(Me.Cb_Month3)
        Me.TabPage4.Controls.Add(Me.DataGridView4)
        Me.TabPage4.Location = New System.Drawing.Point(4, 43)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(982, 718)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Net Income"
        '
        'Btn_Refresh3
        '
        Me.Btn_Refresh3.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Refresh3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Refresh3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Btn_Refresh3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Refresh3.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Refresh3.ForeColor = System.Drawing.Color.White
        Me.Btn_Refresh3.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_refresh_24
        Me.Btn_Refresh3.Location = New System.Drawing.Point(356, 33)
        Me.Btn_Refresh3.Name = "Btn_Refresh3"
        Me.Btn_Refresh3.Size = New System.Drawing.Size(44, 37)
        Me.Btn_Refresh3.TabIndex = 133
        Me.Btn_Refresh3.UseVisualStyleBackColor = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(180, 13)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(78, 27)
        Me.Label12.TabIndex = 132
        Me.Label12.Text = "Year :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(9, 13)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(95, 27)
        Me.Label13.TabIndex = 131
        Me.Label13.Text = "Month :"
        '
        'Cb_Year3
        '
        Me.Cb_Year3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Year3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Year3.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Year3.FormattingEnabled = True
        Me.Cb_Year3.Location = New System.Drawing.Point(185, 43)
        Me.Cb_Year3.Name = "Cb_Year3"
        Me.Cb_Year3.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Year3.TabIndex = 129
        '
        'Cb_Month3
        '
        Me.Cb_Month3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cb_Month3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cb_Month3.Font = New System.Drawing.Font("Times New Roman", 10.2!)
        Me.Cb_Month3.FormattingEnabled = True
        Me.Cb_Month3.Location = New System.Drawing.Point(14, 43)
        Me.Cb_Month3.Name = "Cb_Month3"
        Me.Cb_Month3.Size = New System.Drawing.Size(165, 27)
        Me.Cb_Month3.TabIndex = 128
        '
        'DataGridView4
        '
        Me.DataGridView4.AllowUserToAddRows = False
        Me.DataGridView4.AllowUserToResizeColumns = False
        Me.DataGridView4.AllowUserToResizeRows = False
        Me.DataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView4.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView4.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView4.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView4.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView4.DefaultCellStyle = DataGridViewCellStyle14
        Me.DataGridView4.GridColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView4.Location = New System.Drawing.Point(6, 80)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.ReadOnly = True
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(126, Byte), Integer))
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView4.RowHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.DataGridView4.RowHeadersVisible = False
        Me.DataGridView4.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.White
        Me.DataGridView4.RowsDefaultCellStyle = DataGridViewCellStyle16
        Me.DataGridView4.RowTemplate.Height = 24
        Me.DataGridView4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView4.Size = New System.Drawing.Size(968, 612)
        Me.DataGridView4.TabIndex = 114
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Btn_UserInfo)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Btn_Logout)
        Me.Panel1.Controls.Add(Me.Btn_Recycle)
        Me.Panel1.Controls.Add(Me.Btn_Reports)
        Me.Panel1.Controls.Add(Me.Btn_EmployeeInfo)
        Me.Panel1.Controls.Add(Me.Btn_Bills)
        Me.Panel1.Controls.Add(Me.Btn_Calculation)
        Me.Panel1.Controls.Add(Me.Btn_Home)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(284, 789)
        Me.Panel1.TabIndex = 65
        '
        'Btn_UserInfo
        '
        Me.Btn_UserInfo.BackColor = System.Drawing.Color.Transparent
        Me.Btn_UserInfo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_UserInfo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_UserInfo.FlatAppearance.BorderSize = 0
        Me.Btn_UserInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_UserInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_UserInfo.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_settings_32
        Me.Btn_UserInfo.Location = New System.Drawing.Point(164, 224)
        Me.Btn_UserInfo.Name = "Btn_UserInfo"
        Me.Btn_UserInfo.Size = New System.Drawing.Size(42, 38)
        Me.Btn_UserInfo.TabIndex = 76
        Me.Btn_UserInfo.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(70, 231)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 27)
        Me.Label1.TabIndex = 75
        Me.Label1.Text = "ADMIN"
        '
        'Btn_Logout
        '
        Me.Btn_Logout.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Logout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Logout.FlatAppearance.BorderSize = 0
        Me.Btn_Logout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Logout.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Logout.ForeColor = System.Drawing.Color.White
        Me.Btn_Logout.Location = New System.Drawing.Point(27, 719)
        Me.Btn_Logout.Name = "Btn_Logout"
        Me.Btn_Logout.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Logout.TabIndex = 72
        Me.Btn_Logout.Text = "LOGOUT"
        Me.Btn_Logout.UseVisualStyleBackColor = False
        '
        'Btn_Recycle
        '
        Me.Btn_Recycle.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Recycle.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Recycle.FlatAppearance.BorderSize = 0
        Me.Btn_Recycle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Recycle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Recycle.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Recycle.ForeColor = System.Drawing.Color.White
        Me.Btn_Recycle.Location = New System.Drawing.Point(27, 565)
        Me.Btn_Recycle.Name = "Btn_Recycle"
        Me.Btn_Recycle.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Recycle.TabIndex = 71
        Me.Btn_Recycle.Text = "RECYCLE BIN"
        Me.Btn_Recycle.UseVisualStyleBackColor = False
        '
        'Btn_Reports
        '
        Me.Btn_Reports.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Reports.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Reports.FlatAppearance.BorderSize = 0
        Me.Btn_Reports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Reports.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Reports.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Reports.ForeColor = System.Drawing.Color.White
        Me.Btn_Reports.Location = New System.Drawing.Point(27, 510)
        Me.Btn_Reports.Name = "Btn_Reports"
        Me.Btn_Reports.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Reports.TabIndex = 70
        Me.Btn_Reports.Text = "REPORTS"
        Me.Btn_Reports.UseVisualStyleBackColor = False
        '
        'Btn_EmployeeInfo
        '
        Me.Btn_EmployeeInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_EmployeeInfo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_EmployeeInfo.FlatAppearance.BorderSize = 0
        Me.Btn_EmployeeInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_EmployeeInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_EmployeeInfo.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_EmployeeInfo.ForeColor = System.Drawing.Color.White
        Me.Btn_EmployeeInfo.Location = New System.Drawing.Point(27, 345)
        Me.Btn_EmployeeInfo.Name = "Btn_EmployeeInfo"
        Me.Btn_EmployeeInfo.Size = New System.Drawing.Size(231, 49)
        Me.Btn_EmployeeInfo.TabIndex = 69
        Me.Btn_EmployeeInfo.Text = "EMPLOYEE INFORMATION"
        Me.Btn_EmployeeInfo.UseVisualStyleBackColor = False
        '
        'Btn_Bills
        '
        Me.Btn_Bills.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Bills.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Bills.FlatAppearance.BorderSize = 0
        Me.Btn_Bills.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Bills.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Bills.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Bills.ForeColor = System.Drawing.Color.White
        Me.Btn_Bills.Location = New System.Drawing.Point(27, 455)
        Me.Btn_Bills.Name = "Btn_Bills"
        Me.Btn_Bills.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Bills.TabIndex = 68
        Me.Btn_Bills.Text = "WATER BILLS AND ELECTRICITY"
        Me.Btn_Bills.UseVisualStyleBackColor = False
        '
        'Btn_Calculation
        '
        Me.Btn_Calculation.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Calculation.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Calculation.FlatAppearance.BorderSize = 2
        Me.Btn_Calculation.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Calculation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Calculation.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Calculation.ForeColor = System.Drawing.Color.White
        Me.Btn_Calculation.Location = New System.Drawing.Point(27, 400)
        Me.Btn_Calculation.Name = "Btn_Calculation"
        Me.Btn_Calculation.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Calculation.TabIndex = 67
        Me.Btn_Calculation.Text = "SALARY AND INCOME CALCULATION"
        Me.Btn_Calculation.UseVisualStyleBackColor = False
        '
        'Btn_Home
        '
        Me.Btn_Home.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Home.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Home.FlatAppearance.BorderSize = 0
        Me.Btn_Home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Home.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Home.ForeColor = System.Drawing.Color.White
        Me.Btn_Home.Location = New System.Drawing.Point(27, 290)
        Me.Btn_Home.Name = "Btn_Home"
        Me.Btn_Home.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Home.TabIndex = 65
        Me.Btn_Home.Text = "HOME"
        Me.Btn_Home.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = Global.WindowsApplication1.My.Resources.Resources._439432707_3811750089048465_8998649572546640568_n_removebg_preview1
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(284, 218)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 64
        Me.PictureBox1.TabStop = False
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.White
        Me.Label27.Location = New System.Drawing.Point(486, 128)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(0, 27)
        Me.Label27.TabIndex = 139
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(477, 111)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(231, 27)
        Me.Label14.TabIndex = 137
        Me.Label14.Text = "Employee Percent :"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.White
        Me.Label28.Location = New System.Drawing.Point(714, 112)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(25, 27)
        Me.Label28.TabIndex = 140
        Me.Label28.Text = "0"
        '
        'Btn_Edit
        '
        Me.Btn_Edit.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Edit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Edit.FlatAppearance.BorderSize = 0
        Me.Btn_Edit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Edit.Font = New System.Drawing.Font("Rockwell", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Edit.ForeColor = System.Drawing.Color.White
        Me.Btn_Edit.Location = New System.Drawing.Point(758, 108)
        Me.Btn_Edit.Name = "Btn_Edit"
        Me.Btn_Edit.Size = New System.Drawing.Size(79, 36)
        Me.Btn_Edit.TabIndex = 141
        Me.Btn_Edit.Text = "EDIT"
        Me.Btn_Edit.UseVisualStyleBackColor = False
        '
        'SalaryAndIncome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1292, 789)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "SalaryAndIncome"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AU WATER REFILLING STATION"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Btn_UserInfo As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Btn_Logout As System.Windows.Forms.Button
    Friend WithEvents Btn_Recycle As System.Windows.Forms.Button
    Friend WithEvents Btn_Reports As System.Windows.Forms.Button
    Friend WithEvents Btn_EmployeeInfo As System.Windows.Forms.Button
    Friend WithEvents Btn_Bills As System.Windows.Forms.Button
    Friend WithEvents Btn_Calculation As System.Windows.Forms.Button
    Friend WithEvents Btn_Home As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_ContainerWater As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Container As System.Windows.Forms.TextBox
    Friend WithEvents Txt_WaterRefill As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Txt_Search As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Btn_Refresh As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Cb_Year As System.Windows.Forms.ComboBox
    Friend WithEvents Cb_Month As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_Update As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Submit As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Cb_Year1 As System.Windows.Forms.ComboBox
    Friend WithEvents Cb_Month1 As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_Refresh1 As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Txt_Search1 As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents Txt_Quantity As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Cb_Year2 As System.Windows.Forms.ComboBox
    Friend WithEvents Cb_Month2 As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_Refresh2 As System.Windows.Forms.Button
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Btn_Update1 As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete1 As System.Windows.Forms.Button
    Friend WithEvents Btn_Submit1 As System.Windows.Forms.Button
    Friend WithEvents Txt_Address As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Contact As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Cb_EmployeeID As System.Windows.Forms.ComboBox
    Friend WithEvents Cb_Fullname As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_IncomeReport As System.Windows.Forms.Button
    Friend WithEvents Btn_SalaryReport As System.Windows.Forms.Button
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView4 As System.Windows.Forms.DataGridView
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Cb_Year3 As System.Windows.Forms.ComboBox
    Friend WithEvents Cb_Month3 As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_SmallContainerWater As System.Windows.Forms.TextBox
    Friend WithEvents Txt_SmallContainer As System.Windows.Forms.TextBox
    Friend WithEvents Txt_SmallWaterRefill As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Txt_Search2 As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Refresh3 As System.Windows.Forms.Button
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Btn_Edit As System.Windows.Forms.Button
End Class
