﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports Microsoft.Office.Interop
Imports System.Configuration

Public Class Reports
    Dim connectionString As String = ConfigurationManager.ConnectionStrings("MyDB").ConnectionString
    Dim conn As New SqlConnection(connectionString)
    Dim cmd As SqlCommand
    Dim adapter As SqlDataAdapter
    Dim dt As DataTable

    Private Sub Reports_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Initialize Tab 1 (IncomeReport)
        LoadMonths()
        LoadYears()
        RefreshDataGridView1Report()
        DataGridView1.ClearSelection()

        ' Initialize Tab 2 (SalaryReport)
        LoadMonths1()
        LoadYears1()
        RefreshDataGridView2Report()
        DataGridView2.ClearSelection()
    End Sub

    '------------------------------------------------
    ' BUTTONS FOR NAVIGATION (Home, UserInfo, etc.)
    '------------------------------------------------
    Private Sub Btn_UserInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_UserInfo.Click
        Me.Hide()
        UserProfile.Show()
    End Sub

    Private Sub Btn_Home_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Home.Click
        Me.Hide()
        Home.Show()
        ClearTextBoxes()
        ClearTextBoxes1()
        Txt_Search.Clear()
        Txt_Search1.Clear()
    End Sub

    Private Sub Btn_Calculation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Calculation.Click
        Me.Hide()
        SalaryAndIncome.Show()
        SalaryAndIncome.TabControl1.SelectedIndex = 0
        ClearTextBoxes()
        ClearTextBoxes1()
        Txt_Search.Clear()
        Txt_Search1.Clear()
    End Sub

    Private Sub Btn_EmployeeInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_EmployeeInfo.Click
        Me.Hide()
        EmployeeInfo.Show()
        ClearTextBoxes()
        ClearTextBoxes1()
        Txt_Search.Clear()
        Txt_Search1.Clear()
    End Sub

    Private Sub Btn_Bills_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Bills.Click
        Me.Hide()
        WaterElectricBills.Show()
        ClearTextBoxes()
        ClearTextBoxes1()
        Txt_Search.Clear()
        Txt_Search1.Clear()
    End Sub

    Private Sub Btn_Recycle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Recycle.Click
        Me.Hide()
        RecycleBin.Show()
        RecycleBin.TabControl1.SelectedIndex = 0
        ClearTextBoxes()
        ClearTextBoxes1()
        Txt_Search.Clear()
        Txt_Search1.Clear()
    End Sub

    Private Sub Btn_Logout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Logout.Click
        Dim _exit As DialogResult = MessageBox.Show("Are you sure you want to Logout?", "Logout", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)
        If _exit = vbOK Then
            Login.Show()
            Me.Hide()
            Login.Txt_Username.Focus()
            Login.Txt_Password.UseSystemPasswordChar = True
        End If
    End Sub

    '====================================================================
    '                           TAB 1 (IncomeReport)
    '====================================================================

    Private Sub ClearTextBoxes()
        Cb_Month.SelectedIndex = 0
        Cb_Year.SelectedIndex = 0
    End Sub

    Private Sub Btn_Refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh.Click

        ClearTextBoxes()
        Txt_Search.Clear()
        RefreshDataGridView1Report()
        DataGridView1.ClearSelection()

    End Sub

    Private Sub Txt_Search_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Search.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        ' Limit the length of the text to 11 characters
        If Txt_Search.TextLength >= 11 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    '--- Filter Handlers (Tab 1)
    Private Sub Txt_Search_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Search.TextChanged
        RefreshDataGridView1Report()
    End Sub

    Private Sub Cb_Month_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Month.SelectedIndexChanged
        RefreshDataGridView1Report()
    End Sub

    Private Sub Cb_Year_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Year.SelectedIndexChanged
        RefreshDataGridView1Report()
    End Sub

    '--- Load months for Tab1 (IncomeReport)
    Private Sub LoadMonths()
        Cb_Month.Items.Clear()
        Cb_Month.Items.Add("All") ' Default option

        Dim monthNames() As String = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        }

        For Each month As String In monthNames
            Cb_Month.Items.Add(month)
        Next

        Cb_Month.SelectedIndex = 0 ' Default to "All"
    End Sub

    '--- Load years for Tab1 (IncomeReport)
    Private Sub LoadYears()
        Dim startYear As Integer = 2024
        Dim endYear As Integer = 2050

        Try
            Cb_Year.Items.Clear()
            Cb_Year.Items.Add("All") ' Default option

            For year As Integer = startYear To endYear
                Cb_Year.Items.Add(year.ToString())
            Next

            Cb_Year.SelectedIndex = 0
        Catch ex As Exception
            MessageBox.Show("Error loading years: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    '--- Refresh DataGridView1 (IncomeReport)
    Private Sub RefreshDataGridView1Report()
        Try
            Dim query As String = "SELECT ID, RegWaterGallon, RegContainerwithWater, RegContainer, " &
                                  "SmallWaterGallon, SmallContainerwithWater, SmallContainer, Total, Rows, StartDate, EndDate " &
                                  "FROM IncomeReport WHERE 1=1"

            ' Search filter
            Dim searchKeyword As String = Txt_Search.Text.Trim()
            If Not String.IsNullOrEmpty(searchKeyword) Then
                query &= " AND (" & _
                         "CAST(ID AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegWaterGallon AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegContainerwithWater AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(RegContainer AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallWaterGallon AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallContainerwithWater AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(SmallContainer AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(Total AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(Rows AS NVARCHAR(50)) LIKE @Search" & _
                         ")"
            End If

            ' Month filter
            Dim selectedMonth As String = "All"
            Dim monthNumber As Integer = 0
            If Cb_Month.SelectedItem IsNot Nothing Then
                selectedMonth = Cb_Month.SelectedItem.ToString()
            End If
            If selectedMonth <> "All" Then
                monthNumber = Array.IndexOf(
                    New String() {
                        "January", "February", "March", "April", "May", "June",
                        "July", "August", "September", "October", "November", "December"
                    }, selectedMonth) + 1
                query &= " AND MONTH(StartDate) = @Month"
            End If

            ' Year filter
            Dim selectedYear As String = "All"
            If Cb_Year.SelectedItem IsNot Nothing Then
                selectedYear = Cb_Year.SelectedItem.ToString()
            End If
            If selectedYear <> "All" Then
                query &= " AND YEAR(StartDate) = @Year"
            End If

            ' Sorting
            query &= " ORDER BY StartDate ASC"

            Dim dt As New DataTable()

            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    If Not String.IsNullOrEmpty(searchKeyword) Then
                        cmd.Parameters.AddWithValue("@Search", "%" & searchKeyword & "%")
                    End If
                    If selectedMonth <> "All" Then
                        cmd.Parameters.AddWithValue("@Month", monthNumber)
                    End If
                    If selectedYear <> "All" Then
                        cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(selectedYear))
                    End If

                    conn.Open()
                    Dim adapter As New SqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using

            DataGridView1.DataSource = dt

            ' Update headers
            DataGridView1.Columns("RegWaterGallon").HeaderText = "Reg Water Gallon"
            DataGridView1.Columns("RegContainerwithWater").HeaderText = "Reg Container with Water"
            DataGridView1.Columns("RegContainer").HeaderText = "Reg Container"
            DataGridView1.Columns("SmallWaterGallon").HeaderText = "Small Water Gallon"
            DataGridView1.Columns("SmallContainerwithWater").HeaderText = "Small Container with Water"
            DataGridView1.Columns("SmallContainer").HeaderText = "Small Container"
            DataGridView1.Columns("StartDate").HeaderText = "Start Date"
            DataGridView1.Columns("EndDate").HeaderText = "End Date"

            ' Center alignment + date format
            For Each col As DataGridViewColumn In DataGridView1.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                If col.Name = "StartDate" OrElse col.Name = "EndDate" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next

            DataGridView1.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub Btn_ExportGrossRevenue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ExportGrossRevenue.Click
        ' Check if at least 2 rows are selected
        If DataGridView1.SelectedRows.Count < 2 Then
            MessageBox.Show("You must select at least 2 rows to export!", "Export to Excel", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Retrieve the DataTable from DataGridView1
        Dim dtExport As DataTable = TryCast(DataGridView1.DataSource, DataTable)

        If dtExport Is Nothing OrElse dtExport.Rows.Count = 0 Then
            MessageBox.Show("No data to export (Gross Revenue Report)!", "Export to Excel", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Call the export function with the updated label
        ExportDataTableToExcel(dtExport, "Gross Revenue Report")
    End Sub

    '====================================================================
    '                           TAB 2 (SalaryReport)
    '====================================================================

    Private Sub ClearTextBoxes1()
        Cb_Month1.SelectedIndex = 0
        Cb_Year1.SelectedIndex = 0
    End Sub

    Private Sub Btn_Refresh1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh1.Click
        ClearTextBoxes1()
        Txt_Search1.Clear()
        RefreshDataGridView2Report()
        DataGridView2.ClearSelection()
    End Sub

    Private Sub Txt_Search1_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Search1.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        ' Limit the length of the text to 11 characters
        If Txt_Search1.TextLength >= 11 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    '--- Filter Handlers (Tab 2)
    Private Sub Txt_Search1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Search1.TextChanged
        RefreshDataGridView2Report()
    End Sub

    Private Sub Cb_Month1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Month1.SelectedIndexChanged
        RefreshDataGridView2Report()
    End Sub

    Private Sub Cb_Year1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_Year1.SelectedIndexChanged
        RefreshDataGridView2Report()
    End Sub

    '--- Load months for Tab2 (SalaryReport)
    Private Sub LoadMonths1()
        Cb_Month1.Items.Clear()
        Cb_Month1.Items.Add("All") ' Default option

        Dim monthNames() As String = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        }

        For Each month As String In monthNames
            Cb_Month1.Items.Add(month)
        Next

        Cb_Month1.SelectedIndex = 0
    End Sub

    '--- Load years for Tab2 (SalaryReport)
    Private Sub LoadYears1()
        Dim startYear As Integer = 2024
        Dim endYear As Integer = 2050

        Try
            Cb_Year1.Items.Clear()
            Cb_Year1.Items.Add("All") ' Default option

            For year As Integer = startYear To endYear
                Cb_Year1.Items.Add(year.ToString())
            Next

            Cb_Year1.SelectedIndex = 0
        Catch ex As Exception
            MessageBox.Show("Error loading years: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    '--- Refresh DataGridView2 (SalaryReport)
    Private Sub RefreshDataGridView2Report()
        Try
            Dim query As String = "SELECT ID, TotalSalary, Rows, StartDate, EndDate FROM SalaryReport WHERE 1=1"

            ' Search filter
            Dim searchKeyword As String = Txt_Search1.Text.Trim()
            If Not String.IsNullOrEmpty(searchKeyword) Then
                query &= " AND (" & _
                         "CAST(ID AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(TotalSalary AS NVARCHAR(50)) LIKE @Search OR " & _
                         "CAST(Rows AS NVARCHAR(50)) LIKE @Search)"
            End If

            ' Month filter
            Dim selectedMonth As String = "All"
            Dim monthNumber As Integer = 0
            If Cb_Month1.SelectedItem IsNot Nothing Then
                selectedMonth = Cb_Month1.SelectedItem.ToString()
            End If
            If selectedMonth <> "All" Then
                monthNumber = Array.IndexOf( _
                    New String() {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}, _
                    selectedMonth) + 1
                query &= " AND MONTH(StartDate) = @Month"
            End If

            ' Year filter
            Dim selectedYear As String = "All"
            If Cb_Year1.SelectedItem IsNot Nothing Then
                selectedYear = Cb_Year1.SelectedItem.ToString()
            End If
            If selectedYear <> "All" Then
                query &= " AND YEAR(StartDate) = @Year"
            End If

            ' Sorting
            query &= " ORDER BY StartDate ASC"

            Dim dt As New DataTable()

            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(query, conn)
                    If Not String.IsNullOrEmpty(searchKeyword) Then
                        cmd.Parameters.AddWithValue("@Search", "%" & searchKeyword & "%")
                    End If
                    If selectedMonth <> "All" Then
                        cmd.Parameters.AddWithValue("@Month", monthNumber)
                    End If
                    If selectedYear <> "All" Then
                        cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(selectedYear))
                    End If

                    conn.Open()
                    Dim adapter As New SqlDataAdapter(cmd)
                    adapter.Fill(dt)
                End Using
            End Using

            DataGridView2.DataSource = dt
            DataGridView2.Columns("TotalSalary").HeaderText = "Total Salary"
            DataGridView2.Columns("StartDate").HeaderText = "Start Date"
            DataGridView2.Columns("EndDate").HeaderText = "End Date"

            For Each col As DataGridViewColumn In DataGridView2.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                If col.Name = "StartDate" OrElse col.Name = "EndDate" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next

            DataGridView2.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub Btn_ExportSalary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ExportSalary.Click
        ' Check if at least 2 rows are selected
        If DataGridView2.SelectedRows.Count < 2 Then
            MessageBox.Show("You must select at least 2 rows to export!", "Export to Excel", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Retrieve the DataTable from DataGridView2
        Dim dtExport As DataTable = TryCast(DataGridView2.DataSource, DataTable)

        If dtExport Is Nothing OrElse dtExport.Rows.Count = 0 Then
            MessageBox.Show("No data to export (Salary Report)!", "Export to Excel", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Call the export function
        ExportDataTableToExcel(dtExport, "Salary Report")
    End Sub
    Private Sub ExportDataTableToExcel(ByVal dt As DataTable, ByVal tableName As String)
        Try
            ' 1. Create an Excel application
            Dim xlApp As New Excel.Application()

            ' 2. Create a new Workbook and get the first Worksheet
            Dim xlWorkBook As Excel.Workbook = xlApp.Workbooks.Add()
            Dim xlWorkSheet As Excel.Worksheet = CType(xlWorkBook.Sheets(1), Excel.Worksheet)

            ' --- Row definitions ---
            Dim titleStartRow As Integer = 1     ' Start of merged title (Row 1)
            Dim titleEndRow As Integer = 3       ' End of merged title (Row 3)
            Dim dateInfoRow1 As Integer = 4      ' Start/End Date row
            Dim dateInfoRow2 As Integer = 5      ' Exported Date row
            Dim headerRow As Integer = 6         ' Column headers row
            Dim dataStartRow As Integer = 7      ' Data begins here

            ' Get total number of columns
            Dim lastColumn As Integer = dt.Columns.Count

            ' ========== [1] MERGED TITLE (Rows 1 to 3) ==========
            Dim titleRange As Excel.Range = xlWorkSheet.Range( _
                xlWorkSheet.Cells(titleStartRow, 1), _
                xlWorkSheet.Cells(titleEndRow, lastColumn) _
            )
            titleRange.Merge()
            xlWorkSheet.Cells(titleStartRow, 1).Value = tableName
            xlWorkSheet.Cells(titleStartRow, 1).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
            xlWorkSheet.Cells(titleStartRow, 1).VerticalAlignment = Excel.XlVAlign.xlVAlignCenter
            xlWorkSheet.Cells(titleStartRow, 1).Font.Bold = True
            xlWorkSheet.Cells(titleStartRow, 1).Font.Size = 18
            titleRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Gray)

            ' ========== [2] GET EARLIEST & LATEST DATES ==========
            Dim earliestDate As DateTime = dt.AsEnumerable().Min(Function(r) r.Field(Of DateTime)("StartDate"))
            Dim latestDate As DateTime = dt.AsEnumerable().Max(Function(r) r.Field(Of DateTime)("EndDate"))
            Dim exportedDate As String = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss tt")

            ' ========== [3] DATE INFO (Row 4 & 5) ==========
            xlWorkSheet.Range(xlWorkSheet.Cells(dateInfoRow1, 1), _
                              xlWorkSheet.Cells(dateInfoRow1, lastColumn)).Merge()
            xlWorkSheet.Cells(dateInfoRow1, 1).Value = _
                "Start Date: " & earliestDate.ToString("MMMM-dd-yyyy") & _
                "   End Date: " & latestDate.ToString("MMMM-dd-yyyy")
            xlWorkSheet.Cells(dateInfoRow1, 1).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
            xlWorkSheet.Cells(dateInfoRow1, 1).Font.Bold = True

            xlWorkSheet.Range(xlWorkSheet.Cells(dateInfoRow2, 1), _
                              xlWorkSheet.Cells(dateInfoRow2, lastColumn)).Merge()
            xlWorkSheet.Cells(dateInfoRow2, 1).Value = "Exported: " & exportedDate
            xlWorkSheet.Cells(dateInfoRow2, 1).HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
            xlWorkSheet.Cells(dateInfoRow2, 1).Font.Bold = True

            Dim dateRange As Excel.Range = xlWorkSheet.Range( _
                xlWorkSheet.Cells(dateInfoRow1, 1), _
                xlWorkSheet.Cells(dateInfoRow2, lastColumn) _
            )
            dateRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Orange)

            ' ========== [4] COLUMN HEADERS (Row 6) ==========
            For i As Integer = 1 To dt.Columns.Count
                xlWorkSheet.Cells(headerRow, i) = dt.Columns(i - 1).ColumnName
            Next

            Dim headerRange As Excel.Range = xlWorkSheet.Range( _
                xlWorkSheet.Cells(headerRow, 1), _
                xlWorkSheet.Cells(headerRow, lastColumn) _
            )
            headerRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightBlue)

            ' ========== [5] INSERT DATA (Starting Row 7) ==========
            For r As Integer = 0 To dt.Rows.Count - 1
                For c As Integer = 0 To dt.Columns.Count - 1
                    xlWorkSheet.Cells(dataStartRow + r, c + 1) = dt.Rows(r)(c).ToString()
                Next
            Next

            ' ========== [6] FORMAT DATE COLUMNS ==========
            ' Loop through each column and format if the column is "StartDate" or "EndDate"
            For c As Integer = 0 To dt.Columns.Count - 1
                Dim colName As String = dt.Columns(c).ColumnName
                If colName = "StartDate" OrElse colName = "EndDate" Then
                    Dim dateColumnRange As Excel.Range = xlWorkSheet.Range( _
                        xlWorkSheet.Cells(dataStartRow, c + 1), _
                        xlWorkSheet.Cells(dataStartRow + dt.Rows.Count - 1, c + 1) _
                    )
                    dateColumnRange.NumberFormat = "MMMM-dd-yyyy"
                End If
            Next

            Dim usedRange As Excel.Range = xlWorkSheet.UsedRange
            usedRange.Columns.AutoFit()

            ' ========== [7] SAVE FILE ==========
            Dim filePath As String = "C:\YourPath\" & tableName & "_" & DateTime.Now.ToString("yyyyMMdd_HHmmss") & ".xlsx"
            Dim sfd As New SaveFileDialog()
            sfd.Filter = "Excel Files|*.xlsx"
            sfd.FileName = tableName & "_" & DateTime.Now.ToString("yyyyMMdd_HHmmss") & ".xlsx"
            Dim result As DialogResult = sfd.ShowDialog()

            If result = DialogResult.OK Then
                filePath = sfd.FileName
            Else
                MessageBox.Show("Cancelled", "Export Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information)
                ' Clean up COM objects before exiting
                xlWorkBook.Close(False)
                xlApp.Quit()
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkSheet)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkBook)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp)
                Exit Sub
            End If

            xlWorkBook.SaveAs(filePath)

            ' ========== [8] CLOSE & RELEASE COM OBJECTS ==========
            xlWorkBook.Close()
            xlApp.Quit()
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkSheet)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkBook)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp)

            MessageBox.Show("Data exported to Excel successfully!" & vbCrLf & _
                            "File path: " & filePath, _
                            "Export Success", _
                            MessageBoxButtons.OK, _
                            MessageBoxIcon.Information)

            DataGridView1.ClearSelection()
            DataGridView2.ClearSelection()

        Catch ex As Exception
            MessageBox.Show("Error exporting to Excel: " & ex.Message, _
                            "Export Error", _
                            MessageBoxButtons.OK, _
                            MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub TabControl1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabControl1.Click
        DataGridView1.ClearSelection()
        DataGridView2.ClearSelection()
    End Sub
End Class
