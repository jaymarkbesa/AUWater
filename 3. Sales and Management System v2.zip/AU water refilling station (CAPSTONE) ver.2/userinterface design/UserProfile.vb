﻿Imports System.Data.SqlClient
Imports System.Configuration
Public Class UserProfile
    Dim connectionString As String = ConfigurationManager.ConnectionStrings("MyDB").ConnectionString
    Dim conn As New SqlConnection(connectionString)
    Dim cmd As SqlCommand
    Dim adapter As SqlDataAdapter
    Dim dt As DataTable
    Private Sub Txt_Contact_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Contact.KeyPress
        ' Allow only numeric characters and control characters
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True
        End If

        ' Limit the length of the text to 11 characters
        If Txt_Contact.TextLength >= 11 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub Btn_Back_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Back.Click
        Me.Hide()
        Home.Show()
        ClearTextBoxes()
        DataGridView1.ClearSelection()
    End Sub

    Private Sub Btn_ShowPass_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ShowPass.Click
        If Txt_NewPass.UseSystemPasswordChar = True Then
            Txt_NewPass.UseSystemPasswordChar = False

        Else
            Txt_NewPass.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub Btn_ShowPass1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ShowPass1.Click
        If Txt_ConfirmPass.UseSystemPasswordChar = True Then
            Txt_ConfirmPass.UseSystemPasswordChar = False

        Else
            Txt_ConfirmPass.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub Btn_ShowPass2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ShowPass2.Click
        If Txt_CurrentPass.UseSystemPasswordChar = True Then
            Txt_CurrentPass.UseSystemPasswordChar = False

        Else
            Txt_CurrentPass.UseSystemPasswordChar = True
        End If
    End Sub
    Private Sub Txt_Fullname_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Fullname.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True ' Suppress the Enter key press
            Txt_Gmail.Focus() ' Move focus to the next control (txtPass)
        End If
    End Sub

    Private Sub Txt_Gmail_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Gmail.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True ' Suppress the Enter key press
            Txt_Contact.Focus() ' Move focus to the next control (txtPass)
        End If
    End Sub

    Private Sub Txt_Contact_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Contact.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True ' Suppress the Enter key press
            Txt_Username.Focus()
        End If
    End Sub

    Private Sub Txt_PIN_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True ' Suppress the Enter key press
            Txt_Username.Focus() ' Move focus to the next control (txtPass)
        End If
    End Sub

    Private Sub Txt_Username_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Username.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True ' Suppress the Enter key press
            Txt_CurrentPass.Focus() ' Move focus to the next control (txtPass)
        End If
    End Sub

    Private Sub Txt_CurrentPass_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_CurrentPass.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True ' Suppress the Enter key press
            Txt_NewPass.Focus() ' Move focus to the next control (txtPass)
        End If
    End Sub
    Private Sub Txt_NewPass_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_NewPass.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True ' Suppress the Enter key press
            Txt_ConfirmPass.Focus() ' Move focus to the next control (txtPass)
        End If
    End Sub

    Private Sub Txt_ConfirmPass_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ConfirmPass.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.SuppressKeyPress = True ' Suppress the Enter key press
            Btn_Update_Click(sender, e) ' Trigger the login button click event
        End If
    End Sub
    Private Sub ClearTextBoxes()
        Txt_Fullname.Clear()
        Txt_Gmail.Clear()
        Txt_Contact.Clear()
        Txt_Username.Clear()
        Txt_CurrentPass.Clear()
        Txt_NewPass.Clear()
        Txt_ConfirmPass.Clear()
    End Sub
    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        ClearTextBoxes()
        DataGridView1.ClearSelection()
    End Sub
    Private Sub UserProfile_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        RefreshDataGridView1()
        DataGridView1.ClearSelection()
        ClearTextBoxes()
    End Sub
    Private Sub RefreshDataGridView1()
        Try
            ' Gumamit ng INNER JOIN para makuha lamang yung records na may katugmang entry sa Login table
            Dim query As String = "SELECT UserInfo.ID, UserInfo.Fullname, UserInfo.Gmail, UserInfo.PhoneNumber, UserInfo.Date, Login.Username " & _
                                  "FROM UserInfo INNER JOIN Login ON UserInfo.UserID = Login.ID;"

            dt = New DataTable()
            adapter = New SqlDataAdapter(query, conn)
            adapter.Fill(dt)

            ' I-bind ang DataTable sa DataGridView para ipakita ang mga resulta
            DataGridView1.DataSource = dt

            ' Palitan ang header text ng PhoneNumber column
            DataGridView1.Columns("PhoneNumber").HeaderText = "Phone Number"

            ' Itakda ang alignment ng content sa bawat column
            For Each col As DataGridViewColumn In DataGridView1.Columns
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

                ' I-format ang Date column para ipakita ang buwan, araw, at taon
                If col.Name = "Date" Then
                    col.DefaultCellStyle.Format = "MMMM-dd-yyyy"
                End If
            Next

            ' Itakda ang alignment ng row header
            DataGridView1.RowHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Function IsValidEmail(ByVal email As String) As Boolean
        ' Regular expression pattern for validating email format
        Dim pattern As String = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        Return System.Text.RegularExpressions.Regex.IsMatch(email, pattern)
    End Function
    Private Function IsValidPhoneNumber(ByVal phoneNumber As String) As Boolean
        ' Regular expression pattern for validating phone number format (Philippines format)
        Dim pattern As String = "^(09|\+639)\d{9}$"
        Return System.Text.RegularExpressions.Regex.IsMatch(phoneNumber, pattern)
    End Function
    Private Sub Btn_Update_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Update.Click
        ' Siguraduhing may napiling row sa DataGridView
        If DataGridView1.SelectedRows.Count = 0 Then
            MessageBox.Show("Please select a row to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        ' Siguraduhing lahat ng kinakailangang text boxes ay napunan
        If String.IsNullOrWhiteSpace(Txt_Fullname.Text) OrElse _
           String.IsNullOrWhiteSpace(Txt_Gmail.Text) OrElse _
           String.IsNullOrWhiteSpace(Txt_Contact.Text) OrElse _
           String.IsNullOrWhiteSpace(Txt_Username.Text) OrElse _
           String.IsNullOrWhiteSpace(Txt_CurrentPass.Text) OrElse _
           String.IsNullOrWhiteSpace(Txt_NewPass.Text) OrElse _
           String.IsNullOrWhiteSpace(Txt_ConfirmPass.Text) Then

            MessageBox.Show("Please fill in all required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        ' I-verify kung tama ang current password gamit ang Login table
        Dim currentPasswordCorrect As Boolean = False
        Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)
        ' Dito, ang ID ay ang primary key ng UserInfo row
        Dim userInfoID As Integer = Convert.ToInt32(selectedRow.Cells("ID").Value)

        Dim queryCheckPassword As String = "SELECT COUNT(*) FROM Login WHERE ID = (SELECT UserID FROM UserInfo WHERE ID = @UserInfoID) AND Password = @Password"
        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(queryCheckPassword, connection)
                command.Parameters.AddWithValue("@UserInfoID", userInfoID)
                command.Parameters.AddWithValue("@Password", Txt_CurrentPass.Text.Trim())

                connection.Open()
                currentPasswordCorrect = Convert.ToInt32(command.ExecuteScalar()) > 0
            End Using
        End Using

        If Not currentPasswordCorrect Then
            MessageBox.Show("Current password is incorrect.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Txt_CurrentPass.Clear()
            Txt_CurrentPass.Focus()
            Exit Sub
        End If

        ' I-validate ang email format
        If Not IsValidEmail(Txt_Gmail.Text.Trim()) Then
            MessageBox.Show("Please enter a valid email address.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Txt_Gmail.Clear()
            Txt_Gmail.Focus()
            Exit Sub
        End If

        ' I-validate ang phone number format
        If Not IsValidPhoneNumber(Txt_Contact.Text.Trim()) Then
            MessageBox.Show("Please enter a valid phone number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Txt_Contact.Clear()
            Txt_Contact.Focus()
            Exit Sub
        End If

        ' I-check kung tugma ang bagong password at confirmation password
        If Txt_NewPass.Text.Trim() <> Txt_ConfirmPass.Text.Trim() Then
            MessageBox.Show("The new password and confirmation password do not match.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Txt_NewPass.Clear()
            Txt_ConfirmPass.Clear()
            Txt_NewPass.Focus()
            Exit Sub
        End If

        ' I-check kung ang bagong password ay hindi kapareho ng current password
        If Txt_CurrentPass.Text.Trim() = Txt_NewPass.Text.Trim() Then
            MessageBox.Show("You cannot use your current password to change a new password, kindly use different password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Txt_NewPass.Clear()
            Txt_ConfirmPass.Clear()
            Txt_NewPass.Focus()
            Exit Sub
        End If

        ' Gamitin ang parehong connection para sa parehong update queries
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            ' Update sa UserInfo table gamit ang primary key (ID)
            Dim updateUserInfoQuery As String = "UPDATE UserInfo SET FullName = @FullName, Gmail = @Gmail, PhoneNumber = @PhoneNumber, [Date] = @Date WHERE ID = @UserInfoID"
            Using command As New SqlCommand(updateUserInfoQuery, connection)
                command.Parameters.AddWithValue("@FullName", Txt_Fullname.Text.Trim())
                command.Parameters.AddWithValue("@Gmail", Txt_Gmail.Text.Trim())
                command.Parameters.AddWithValue("@PhoneNumber", Txt_Contact.Text.Trim())
                command.Parameters.AddWithValue("@Date", DateTimePicker2.Value.ToString("yyyy-MM-dd"))
                command.Parameters.AddWithValue("@UserInfoID", userInfoID)

                Dim rowsAffected As Integer = command.ExecuteNonQuery()
                If rowsAffected > 0 Then
                    ' Update sa Login table gamit ang foreign key value.
                    ' Gamitin ang subquery para makuha ang UserID mula sa UserInfo table
                    Dim updateLoginQuery As String = "UPDATE Login SET Username = @Username, Password = @Password " & _
                                                     "WHERE ID = (SELECT UserID FROM UserInfo WHERE ID = @UserInfoID)"
                    Using commandLogin As New SqlCommand(updateLoginQuery, connection)
                        commandLogin.Parameters.AddWithValue("@Username", Txt_Username.Text.Trim())
                        commandLogin.Parameters.AddWithValue("@Password", Txt_NewPass.Text.Trim())
                        commandLogin.Parameters.AddWithValue("@UserInfoID", userInfoID)

                        rowsAffected = commandLogin.ExecuteNonQuery()
                        If rowsAffected > 0 Then
                            MessageBox.Show("User profile updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            ' I-refresh ang DataGridView pagkatapos ng update
                            RefreshDataGridView1()
                            ClearTextBoxes()
                            DataGridView1.ClearSelection()
                        Else
                            MessageBox.Show("Failed to update user profile.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End If
                    End Using
                Else
                    MessageBox.Show("Failed to update user profile.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End Using
        End Using
    End Sub
    Private Sub DataGridView1_SelectionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataGridView1.SelectionChanged
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)

            ' Retrieve information from each cell and place it in the appropriate TextBox
            Txt_Fullname.Text = selectedRow.Cells("FullName").Value.ToString()
            Txt_Gmail.Text = selectedRow.Cells("Gmail").Value.ToString()
            Txt_Contact.Text = selectedRow.Cells("PhoneNumber").Value.ToString()
            Txt_Username.Text = selectedRow.Cells("Username").Value.ToString()

            ' Convert the date value to a DateTime and set the DateTimePicker value
            Dim dateValue As Date = Convert.ToDateTime(selectedRow.Cells("Date").Value)
            DateTimePicker1.Value = dateValue

            Txt_Fullname.Enabled = True
            Txt_Gmail.Enabled = True
            Txt_Contact.Enabled = True
            Txt_Username.Enabled = True
            Txt_CurrentPass.Enabled = True
            Txt_NewPass.Enabled = True
            Txt_ConfirmPass.Enabled = True
        Else
            ' If no row is selected, clear the TextBoxes
            ClearTextBoxes()
            DataGridView1.ClearSelection()

            Txt_Fullname.Enabled = False
            Txt_Gmail.Enabled = False
            Txt_Contact.Enabled = False
            Txt_Username.Enabled = False
            Txt_CurrentPass.Enabled = False
            Txt_NewPass.Enabled = False
            Txt_ConfirmPass.Enabled = False
        End If
    End Sub

    Private Sub Txt_Fullname_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Fullname.KeyPress
        ' Payagan ang control characters tulad ng Backspace, Enter, etc.
        If Char.IsControl(e.KeyChar) Then Exit Sub

        ' Papayagan lang ang mga letra, dot, at space
        If Not Char.IsLetter(e.KeyChar) AndAlso e.KeyChar <> "."c AndAlso e.KeyChar <> " "c Then
            e.Handled = True
            Exit Sub
        End If

        ' Kung key na pinindot ay letra, i-format ito base sa posisyon
        If Char.IsLetter(e.KeyChar) Then
            Dim pos As Integer = Txt_Fullname.SelectionStart
            ' Kung unang character ng textbox o pagkatapos ng space, gawing uppercase
            If pos = 0 OrElse (pos > 0 AndAlso Txt_Fullname.Text.Chars(pos - 1) = " "c) Then
                e.KeyChar = Char.ToUpper(e.KeyChar)
            Else
                ' Kung nasa gitna ng salita, gawing lowercase
                e.KeyChar = Char.ToLower(e.KeyChar)
            End If
        End If
    End Sub
End Class
