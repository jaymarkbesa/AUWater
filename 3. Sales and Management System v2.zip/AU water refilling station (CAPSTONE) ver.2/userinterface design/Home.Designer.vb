﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Home))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Btn_UserInfo = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Btn_Logout = New System.Windows.Forms.Button()
        Me.Btn_Recycle = New System.Windows.Forms.Button()
        Me.Btn_Reports = New System.Windows.Forms.Button()
        Me.Btn_EmployeeInfo = New System.Windows.Forms.Button()
        Me.Btn_Bills = New System.Windows.Forms.Button()
        Me.Btn_Calculation = New System.Windows.Forms.Button()
        Me.Btn_Home = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Txt_Time = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Lbl_WaterRefillSold = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Lbl_ContainerWaterSold = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Lbl_WaterRefillIncome = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Lbl_ContainerWaterIncome = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Lbl_ContainerSold = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Lbl_ContainerIncome = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Txt_PriceGallon = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Txt_PriceContainerWater = New System.Windows.Forms.TextBox()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Txt_PriceContainer = New System.Windows.Forms.TextBox()
        Me.Btn_EditPrice = New System.Windows.Forms.Button()
        Me.Btn_Save = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel_Form1 = New System.Windows.Forms.Panel()
        Me.Btn_Edit = New System.Windows.Forms.Button()
        Me.Btn_AddGallon = New System.Windows.Forms.Button()
        Me.Panel_Form2 = New System.Windows.Forms.Panel()
        Me.Btn_Change = New System.Windows.Forms.Button()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Lbl_SmallContainerIncome = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Lbl_SmallContainerSold = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Txt_PriceSmallContainer = New System.Windows.Forms.TextBox()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Lbl_SmallContainerwithWaterIncome = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Lbl_SmallContainerwithWaterSold = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Txt_PriceSmallContainerWater = New System.Windows.Forms.TextBox()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Lbl_SmallRefillIncome = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Lbl_SmallRefillSold = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Txt_PriceSmallGallon = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Txt_PriceContainer1 = New System.Windows.Forms.TextBox()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Txt_PriceContainerWater1 = New System.Windows.Forms.TextBox()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Txt_PriceGallon1 = New System.Windows.Forms.TextBox()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Lbl_ContainerIncome1 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Lbl_ContainerSold1 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Lbl_ContainerWaterIncome1 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Lbl_WaterRefillIncome1 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Lbl_ContainerWaterSold1 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Lbl_WaterRefillSold1 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Btn_EditPrice1 = New System.Windows.Forms.Button()
        Me.Btn_Save1 = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel_Form1.SuspendLayout()
        Me.Panel_Form2.SuspendLayout()
        Me.Panel29.SuspendLayout()
        Me.Panel28.SuspendLayout()
        Me.Panel27.SuspendLayout()
        Me.Panel26.SuspendLayout()
        Me.Panel25.SuspendLayout()
        Me.Panel24.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Btn_UserInfo)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Btn_Logout)
        Me.Panel1.Controls.Add(Me.Btn_Recycle)
        Me.Panel1.Controls.Add(Me.Btn_Reports)
        Me.Panel1.Controls.Add(Me.Btn_EmployeeInfo)
        Me.Panel1.Controls.Add(Me.Btn_Bills)
        Me.Panel1.Controls.Add(Me.Btn_Calculation)
        Me.Panel1.Controls.Add(Me.Btn_Home)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(284, 789)
        Me.Panel1.TabIndex = 0
        '
        'Btn_UserInfo
        '
        Me.Btn_UserInfo.BackColor = System.Drawing.Color.Transparent
        Me.Btn_UserInfo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_UserInfo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_UserInfo.FlatAppearance.BorderSize = 0
        Me.Btn_UserInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_UserInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_UserInfo.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_settings_32
        Me.Btn_UserInfo.Location = New System.Drawing.Point(164, 224)
        Me.Btn_UserInfo.Name = "Btn_UserInfo"
        Me.Btn_UserInfo.Size = New System.Drawing.Size(42, 38)
        Me.Btn_UserInfo.TabIndex = 74
        Me.Btn_UserInfo.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Rockwell", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(70, 231)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 27)
        Me.Label1.TabIndex = 73
        Me.Label1.Text = "ADMIN"
        '
        'Btn_Logout
        '
        Me.Btn_Logout.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Logout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Logout.FlatAppearance.BorderSize = 0
        Me.Btn_Logout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Logout.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Logout.ForeColor = System.Drawing.Color.White
        Me.Btn_Logout.Location = New System.Drawing.Point(27, 719)
        Me.Btn_Logout.Name = "Btn_Logout"
        Me.Btn_Logout.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Logout.TabIndex = 72
        Me.Btn_Logout.Text = "LOGOUT"
        Me.Btn_Logout.UseVisualStyleBackColor = False
        '
        'Btn_Recycle
        '
        Me.Btn_Recycle.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Recycle.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Recycle.FlatAppearance.BorderSize = 0
        Me.Btn_Recycle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Recycle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Recycle.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Recycle.ForeColor = System.Drawing.Color.White
        Me.Btn_Recycle.Location = New System.Drawing.Point(27, 565)
        Me.Btn_Recycle.Name = "Btn_Recycle"
        Me.Btn_Recycle.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Recycle.TabIndex = 71
        Me.Btn_Recycle.Text = "RECYCLE BIN"
        Me.Btn_Recycle.UseVisualStyleBackColor = False
        '
        'Btn_Reports
        '
        Me.Btn_Reports.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Reports.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Reports.FlatAppearance.BorderSize = 0
        Me.Btn_Reports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Reports.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Reports.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Reports.ForeColor = System.Drawing.Color.White
        Me.Btn_Reports.Location = New System.Drawing.Point(27, 510)
        Me.Btn_Reports.Name = "Btn_Reports"
        Me.Btn_Reports.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Reports.TabIndex = 70
        Me.Btn_Reports.Text = "REPORTS"
        Me.Btn_Reports.UseVisualStyleBackColor = False
        '
        'Btn_EmployeeInfo
        '
        Me.Btn_EmployeeInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_EmployeeInfo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_EmployeeInfo.FlatAppearance.BorderSize = 0
        Me.Btn_EmployeeInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_EmployeeInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_EmployeeInfo.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_EmployeeInfo.ForeColor = System.Drawing.Color.White
        Me.Btn_EmployeeInfo.Location = New System.Drawing.Point(27, 345)
        Me.Btn_EmployeeInfo.Name = "Btn_EmployeeInfo"
        Me.Btn_EmployeeInfo.Size = New System.Drawing.Size(231, 49)
        Me.Btn_EmployeeInfo.TabIndex = 69
        Me.Btn_EmployeeInfo.Text = "EMPLOYEE INFORMATION"
        Me.Btn_EmployeeInfo.UseVisualStyleBackColor = False
        '
        'Btn_Bills
        '
        Me.Btn_Bills.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Bills.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Bills.FlatAppearance.BorderSize = 0
        Me.Btn_Bills.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Bills.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Bills.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Bills.ForeColor = System.Drawing.Color.White
        Me.Btn_Bills.Location = New System.Drawing.Point(27, 455)
        Me.Btn_Bills.Name = "Btn_Bills"
        Me.Btn_Bills.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Bills.TabIndex = 68
        Me.Btn_Bills.Text = "WATER BILLS AND ELECTRICITY"
        Me.Btn_Bills.UseVisualStyleBackColor = False
        '
        'Btn_Calculation
        '
        Me.Btn_Calculation.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Calculation.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Calculation.FlatAppearance.BorderSize = 0
        Me.Btn_Calculation.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Calculation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Calculation.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Calculation.ForeColor = System.Drawing.Color.White
        Me.Btn_Calculation.Location = New System.Drawing.Point(27, 400)
        Me.Btn_Calculation.Name = "Btn_Calculation"
        Me.Btn_Calculation.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Calculation.TabIndex = 67
        Me.Btn_Calculation.Text = "SALARY AND INCOME CALCULATION"
        Me.Btn_Calculation.UseVisualStyleBackColor = False
        '
        'Btn_Home
        '
        Me.Btn_Home.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Home.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Home.FlatAppearance.BorderSize = 2
        Me.Btn_Home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Home.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Home.ForeColor = System.Drawing.Color.White
        Me.Btn_Home.Location = New System.Drawing.Point(27, 290)
        Me.Btn_Home.Name = "Btn_Home"
        Me.Btn_Home.Size = New System.Drawing.Size(231, 49)
        Me.Btn_Home.TabIndex = 65
        Me.Btn_Home.Text = "HOME"
        Me.Btn_Home.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = Global.WindowsApplication1.My.Resources.Resources._439432707_3811750089048465_8998649572546640568_n_removebg_preview2
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(284, 218)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 64
        Me.PictureBox1.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Txt_Time)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(284, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1008, 133)
        Me.Panel3.TabIndex = 10
        '
        'Txt_Time
        '
        Me.Txt_Time.Font = New System.Drawing.Font("Rockwell", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Time.ForeColor = System.Drawing.Color.White
        Me.Txt_Time.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_time_501
        Me.Txt_Time.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Txt_Time.Location = New System.Drawing.Point(176, 9)
        Me.Txt_Time.Name = "Txt_Time"
        Me.Txt_Time.Size = New System.Drawing.Size(656, 113)
        Me.Txt_Time.TabIndex = 0
        Me.Txt_Time.Text = "DATE"
        Me.Txt_Time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel4.Controls.Add(Me.Lbl_WaterRefillSold)
        Me.Panel4.Controls.Add(Me.Label4)
        Me.Panel4.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel4.ForeColor = System.Drawing.Color.White
        Me.Panel4.Location = New System.Drawing.Point(56, 135)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(287, 298)
        Me.Panel4.TabIndex = 11
        '
        'Lbl_WaterRefillSold
        '
        Me.Lbl_WaterRefillSold.AutoSize = True
        Me.Lbl_WaterRefillSold.Font = New System.Drawing.Font("Rockwell", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_WaterRefillSold.Location = New System.Drawing.Point(96, 74)
        Me.Lbl_WaterRefillSold.Name = "Lbl_WaterRefillSold"
        Me.Lbl_WaterRefillSold.Size = New System.Drawing.Size(95, 68)
        Me.Lbl_WaterRefillSold.TabIndex = 1
        Me.Lbl_WaterRefillSold.Text = "10"
        Me.Lbl_WaterRefillSold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(20, 197)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(239, 22)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Water Refill Gallons Sold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel5.Controls.Add(Me.Lbl_ContainerWaterSold)
        Me.Panel5.Controls.Add(Me.Label5)
        Me.Panel5.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel5.ForeColor = System.Drawing.Color.White
        Me.Panel5.Location = New System.Drawing.Point(348, 135)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(287, 298)
        Me.Panel5.TabIndex = 12
        '
        'Lbl_ContainerWaterSold
        '
        Me.Lbl_ContainerWaterSold.AutoSize = True
        Me.Lbl_ContainerWaterSold.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_ContainerWaterSold.Location = New System.Drawing.Point(96, 74)
        Me.Lbl_ContainerWaterSold.Name = "Lbl_ContainerWaterSold"
        Me.Lbl_ContainerWaterSold.Size = New System.Drawing.Size(95, 68)
        Me.Lbl_ContainerWaterSold.TabIndex = 2
        Me.Lbl_ContainerWaterSold.Text = "10"
        Me.Lbl_ContainerWaterSold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(13, 197)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(239, 21)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Container with water sold"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel6.Controls.Add(Me.Lbl_WaterRefillIncome)
        Me.Panel6.Controls.Add(Me.Label8)
        Me.Panel6.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel6.ForeColor = System.Drawing.Color.White
        Me.Panel6.Location = New System.Drawing.Point(56, 439)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(287, 117)
        Me.Panel6.TabIndex = 13
        '
        'Lbl_WaterRefillIncome
        '
        Me.Lbl_WaterRefillIncome.AutoSize = True
        Me.Lbl_WaterRefillIncome.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_WaterRefillIncome.Location = New System.Drawing.Point(123, 27)
        Me.Lbl_WaterRefillIncome.Name = "Lbl_WaterRefillIncome"
        Me.Lbl_WaterRefillIncome.Size = New System.Drawing.Size(40, 21)
        Me.Lbl_WaterRefillIncome.TabIndex = 2
        Me.Lbl_WaterRefillIncome.Text = "850"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(40, 72)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(207, 21)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Water Gallons Income"
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel7.Controls.Add(Me.Lbl_ContainerWaterIncome)
        Me.Panel7.Controls.Add(Me.Label9)
        Me.Panel7.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel7.ForeColor = System.Drawing.Color.White
        Me.Panel7.Location = New System.Drawing.Point(348, 439)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(287, 117)
        Me.Panel7.TabIndex = 14
        '
        'Lbl_ContainerWaterIncome
        '
        Me.Lbl_ContainerWaterIncome.AutoSize = True
        Me.Lbl_ContainerWaterIncome.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_ContainerWaterIncome.Location = New System.Drawing.Point(121, 30)
        Me.Lbl_ContainerWaterIncome.Name = "Lbl_ContainerWaterIncome"
        Me.Lbl_ContainerWaterIncome.Size = New System.Drawing.Size(40, 21)
        Me.Lbl_ContainerWaterIncome.TabIndex = 3
        Me.Lbl_ContainerWaterIncome.Text = "720"
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(10, 61)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(266, 42)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "Container with water Income"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel8.Controls.Add(Me.Lbl_ContainerSold)
        Me.Panel8.Controls.Add(Me.Label13)
        Me.Panel8.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel8.ForeColor = System.Drawing.Color.White
        Me.Panel8.Location = New System.Drawing.Point(641, 135)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(287, 298)
        Me.Panel8.TabIndex = 13
        '
        'Lbl_ContainerSold
        '
        Me.Lbl_ContainerSold.AutoSize = True
        Me.Lbl_ContainerSold.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_ContainerSold.Location = New System.Drawing.Point(96, 74)
        Me.Lbl_ContainerSold.Name = "Lbl_ContainerSold"
        Me.Lbl_ContainerSold.Size = New System.Drawing.Size(95, 68)
        Me.Lbl_ContainerSold.TabIndex = 2
        Me.Lbl_ContainerSold.Text = "10"
        Me.Lbl_ContainerSold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(61, 197)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(141, 21)
        Me.Label13.TabIndex = 1
        Me.Label13.Text = "Container sold"
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel9.Controls.Add(Me.Lbl_ContainerIncome)
        Me.Panel9.Controls.Add(Me.Label11)
        Me.Panel9.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel9.ForeColor = System.Drawing.Color.White
        Me.Panel9.Location = New System.Drawing.Point(641, 439)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(287, 117)
        Me.Panel9.TabIndex = 15
        '
        'Lbl_ContainerIncome
        '
        Me.Lbl_ContainerIncome.AutoSize = True
        Me.Lbl_ContainerIncome.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_ContainerIncome.Location = New System.Drawing.Point(118, 30)
        Me.Lbl_ContainerIncome.Name = "Lbl_ContainerIncome"
        Me.Lbl_ContainerIncome.Size = New System.Drawing.Size(50, 21)
        Me.Lbl_ContainerIncome.TabIndex = 4
        Me.Lbl_ContainerIncome.Text = "1500"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(59, 72)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(168, 21)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "Container Income"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label16.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(53, 26)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(180, 22)
        Me.Label16.TabIndex = 17
        Me.Label16.Text = "Per Water Gallon's"
        '
        'Txt_PriceGallon
        '
        Me.Txt_PriceGallon.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceGallon.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceGallon.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceGallon.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceGallon.Location = New System.Drawing.Point(109, 64)
        Me.Txt_PriceGallon.Name = "Txt_PriceGallon"
        Me.Txt_PriceGallon.ReadOnly = True
        Me.Txt_PriceGallon.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceGallon.TabIndex = 0
        Me.Txt_PriceGallon.Text = "0"
        Me.Txt_PriceGallon.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.Txt_PriceGallon)
        Me.Panel2.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel2.ForeColor = System.Drawing.Color.White
        Me.Panel2.Location = New System.Drawing.Point(56, 13)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(287, 116)
        Me.Panel2.TabIndex = 26
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel10.Controls.Add(Me.Label2)
        Me.Panel10.Controls.Add(Me.Txt_PriceContainerWater)
        Me.Panel10.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel10.ForeColor = System.Drawing.Color.White
        Me.Panel10.Location = New System.Drawing.Point(348, 13)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(287, 116)
        Me.Panel10.TabIndex = 27
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label2.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(12, 17)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(262, 40)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Per Container with Water"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_PriceContainerWater
        '
        Me.Txt_PriceContainerWater.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceContainerWater.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceContainerWater.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceContainerWater.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceContainerWater.Location = New System.Drawing.Point(109, 64)
        Me.Txt_PriceContainerWater.Name = "Txt_PriceContainerWater"
        Me.Txt_PriceContainerWater.ReadOnly = True
        Me.Txt_PriceContainerWater.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceContainerWater.TabIndex = 1
        Me.Txt_PriceContainerWater.Text = "0"
        Me.Txt_PriceContainerWater.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel11.Controls.Add(Me.Label19)
        Me.Panel11.Controls.Add(Me.Txt_PriceContainer)
        Me.Panel11.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel11.ForeColor = System.Drawing.Color.White
        Me.Panel11.Location = New System.Drawing.Point(641, 13)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(287, 116)
        Me.Panel11.TabIndex = 28
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label19.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(76, 26)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(135, 22)
        Me.Label19.TabIndex = 17
        Me.Label19.Text = "Per Container"
        '
        'Txt_PriceContainer
        '
        Me.Txt_PriceContainer.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceContainer.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceContainer.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceContainer.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceContainer.Location = New System.Drawing.Point(109, 64)
        Me.Txt_PriceContainer.Name = "Txt_PriceContainer"
        Me.Txt_PriceContainer.ReadOnly = True
        Me.Txt_PriceContainer.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceContainer.TabIndex = 2
        Me.Txt_PriceContainer.Text = "0"
        Me.Txt_PriceContainer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Btn_EditPrice
        '
        Me.Btn_EditPrice.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_EditPrice.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_EditPrice.FlatAppearance.BorderSize = 0
        Me.Btn_EditPrice.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_EditPrice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_EditPrice.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_EditPrice.ForeColor = System.Drawing.Color.White
        Me.Btn_EditPrice.Location = New System.Drawing.Point(326, 573)
        Me.Btn_EditPrice.Name = "Btn_EditPrice"
        Me.Btn_EditPrice.Size = New System.Drawing.Size(165, 49)
        Me.Btn_EditPrice.TabIndex = 67
        Me.Btn_EditPrice.Text = "EDIT PRICE"
        Me.Btn_EditPrice.UseVisualStyleBackColor = False
        Me.Btn_EditPrice.Visible = False
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Save.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Save.FlatAppearance.BorderSize = 0
        Me.Btn_Save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Save.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(326, 573)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(165, 49)
        Me.Btn_Save.TabIndex = 68
        Me.Btn_Save.Text = "SAVE"
        Me.Btn_Save.UseVisualStyleBackColor = False
        Me.Btn_Save.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'Panel_Form1
        '
        Me.Panel_Form1.Controls.Add(Me.Btn_Edit)
        Me.Panel_Form1.Controls.Add(Me.Btn_EditPrice)
        Me.Panel_Form1.Controls.Add(Me.Btn_AddGallon)
        Me.Panel_Form1.Controls.Add(Me.Panel11)
        Me.Panel_Form1.Controls.Add(Me.Panel10)
        Me.Panel_Form1.Controls.Add(Me.Panel2)
        Me.Panel_Form1.Controls.Add(Me.Panel9)
        Me.Panel_Form1.Controls.Add(Me.Panel8)
        Me.Panel_Form1.Controls.Add(Me.Panel7)
        Me.Panel_Form1.Controls.Add(Me.Panel6)
        Me.Panel_Form1.Controls.Add(Me.Panel5)
        Me.Panel_Form1.Controls.Add(Me.Panel4)
        Me.Panel_Form1.Controls.Add(Me.Btn_Save)
        Me.Panel_Form1.Location = New System.Drawing.Point(290, 139)
        Me.Panel_Form1.Name = "Panel_Form1"
        Me.Panel_Form1.Size = New System.Drawing.Size(990, 638)
        Me.Panel_Form1.TabIndex = 69
        '
        'Btn_Edit
        '
        Me.Btn_Edit.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Edit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Edit.FlatAppearance.BorderSize = 0
        Me.Btn_Edit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Edit.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Edit.ForeColor = System.Drawing.Color.White
        Me.Btn_Edit.Location = New System.Drawing.Point(412, 573)
        Me.Btn_Edit.Name = "Btn_Edit"
        Me.Btn_Edit.Size = New System.Drawing.Size(165, 49)
        Me.Btn_Edit.TabIndex = 3
        Me.Btn_Edit.Text = "EDIT"
        Me.Btn_Edit.UseVisualStyleBackColor = False
        '
        'Btn_AddGallon
        '
        Me.Btn_AddGallon.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_AddGallon.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_AddGallon.FlatAppearance.BorderSize = 0
        Me.Btn_AddGallon.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_AddGallon.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_AddGallon.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_AddGallon.ForeColor = System.Drawing.Color.White
        Me.Btn_AddGallon.Location = New System.Drawing.Point(499, 573)
        Me.Btn_AddGallon.Name = "Btn_AddGallon"
        Me.Btn_AddGallon.Size = New System.Drawing.Size(165, 49)
        Me.Btn_AddGallon.TabIndex = 69
        Me.Btn_AddGallon.Text = "ADD GALLON"
        Me.Btn_AddGallon.UseVisualStyleBackColor = False
        Me.Btn_AddGallon.Visible = False
        '
        'Panel_Form2
        '
        Me.Panel_Form2.Controls.Add(Me.Btn_Change)
        Me.Panel_Form2.Controls.Add(Me.Panel29)
        Me.Panel_Form2.Controls.Add(Me.Panel28)
        Me.Panel_Form2.Controls.Add(Me.Panel27)
        Me.Panel_Form2.Controls.Add(Me.Panel26)
        Me.Panel_Form2.Controls.Add(Me.Panel25)
        Me.Panel_Form2.Controls.Add(Me.Panel24)
        Me.Panel_Form2.Controls.Add(Me.Panel23)
        Me.Panel_Form2.Controls.Add(Me.Panel22)
        Me.Panel_Form2.Controls.Add(Me.Panel21)
        Me.Panel_Form2.Controls.Add(Me.Panel12)
        Me.Panel_Form2.Controls.Add(Me.Panel13)
        Me.Panel_Form2.Controls.Add(Me.Panel14)
        Me.Panel_Form2.Controls.Add(Me.Panel15)
        Me.Panel_Form2.Controls.Add(Me.Panel16)
        Me.Panel_Form2.Controls.Add(Me.Panel17)
        Me.Panel_Form2.Controls.Add(Me.Panel18)
        Me.Panel_Form2.Controls.Add(Me.Panel19)
        Me.Panel_Form2.Controls.Add(Me.Panel20)
        Me.Panel_Form2.Controls.Add(Me.Btn_EditPrice1)
        Me.Panel_Form2.Controls.Add(Me.Btn_Save1)
        Me.Panel_Form2.Location = New System.Drawing.Point(290, 139)
        Me.Panel_Form2.Name = "Panel_Form2"
        Me.Panel_Form2.Size = New System.Drawing.Size(990, 638)
        Me.Panel_Form2.TabIndex = 70
        '
        'Btn_Change
        '
        Me.Btn_Change.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Change.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Change.FlatAppearance.BorderSize = 0
        Me.Btn_Change.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Change.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Change.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Change.ForeColor = System.Drawing.Color.White
        Me.Btn_Change.Location = New System.Drawing.Point(499, 582)
        Me.Btn_Change.Name = "Btn_Change"
        Me.Btn_Change.Size = New System.Drawing.Size(165, 49)
        Me.Btn_Change.TabIndex = 8
        Me.Btn_Change.Text = "CHANGE"
        Me.Btn_Change.UseVisualStyleBackColor = False
        '
        'Panel29
        '
        Me.Panel29.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel29.Controls.Add(Me.Label55)
        Me.Panel29.Controls.Add(Me.Lbl_SmallContainerIncome)
        Me.Panel29.Controls.Add(Me.Label57)
        Me.Panel29.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel29.ForeColor = System.Drawing.Color.White
        Me.Panel29.Location = New System.Drawing.Point(825, 443)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(157, 130)
        Me.Panel29.TabIndex = 87
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(41, 94)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(0, 21)
        Me.Label55.TabIndex = 5
        '
        'Lbl_SmallContainerIncome
        '
        Me.Lbl_SmallContainerIncome.AutoSize = True
        Me.Lbl_SmallContainerIncome.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_SmallContainerIncome.Location = New System.Drawing.Point(53, 55)
        Me.Lbl_SmallContainerIncome.Name = "Lbl_SmallContainerIncome"
        Me.Lbl_SmallContainerIncome.Size = New System.Drawing.Size(50, 21)
        Me.Lbl_SmallContainerIncome.TabIndex = 4
        Me.Lbl_SmallContainerIncome.Text = "1500"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.Location = New System.Drawing.Point(11, 99)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(135, 20)
        Me.Label57.TabIndex = 4
        Me.Label57.Text = "Small Container"
        '
        'Panel28
        '
        Me.Panel28.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel28.Controls.Add(Me.Label53)
        Me.Panel28.Controls.Add(Me.Lbl_SmallContainerSold)
        Me.Panel28.Controls.Add(Me.Label52)
        Me.Panel28.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel28.ForeColor = System.Drawing.Color.White
        Me.Panel28.Location = New System.Drawing.Point(825, 151)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(157, 282)
        Me.Panel28.TabIndex = 86
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(8, 249)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(141, 21)
        Me.Label53.TabIndex = 3
        Me.Label53.Text = "Container sold"
        '
        'Lbl_SmallContainerSold
        '
        Me.Lbl_SmallContainerSold.AutoSize = True
        Me.Lbl_SmallContainerSold.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_SmallContainerSold.Location = New System.Drawing.Point(31, 115)
        Me.Lbl_SmallContainerSold.Name = "Lbl_SmallContainerSold"
        Me.Lbl_SmallContainerSold.Size = New System.Drawing.Size(95, 68)
        Me.Lbl_SmallContainerSold.TabIndex = 2
        Me.Lbl_SmallContainerSold.Text = "10"
        Me.Lbl_SmallContainerSold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(49, 219)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(58, 21)
        Me.Label52.TabIndex = 1
        Me.Label52.Text = "Small"
        '
        'Panel27
        '
        Me.Panel27.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel27.Controls.Add(Me.Label50)
        Me.Panel27.Controls.Add(Me.Txt_PriceSmallContainer)
        Me.Panel27.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel27.ForeColor = System.Drawing.Color.White
        Me.Panel27.Location = New System.Drawing.Point(825, 7)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(157, 122)
        Me.Panel27.TabIndex = 85
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label50.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.White
        Me.Label50.Location = New System.Drawing.Point(11, 32)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(135, 20)
        Me.Label50.TabIndex = 17
        Me.Label50.Text = "Small Container"
        '
        'Txt_PriceSmallContainer
        '
        Me.Txt_PriceSmallContainer.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceSmallContainer.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceSmallContainer.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceSmallContainer.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceSmallContainer.Location = New System.Drawing.Point(37, 83)
        Me.Txt_PriceSmallContainer.Name = "Txt_PriceSmallContainer"
        Me.Txt_PriceSmallContainer.ReadOnly = True
        Me.Txt_PriceSmallContainer.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceSmallContainer.TabIndex = 5
        Me.Txt_PriceSmallContainer.Text = "0"
        Me.Txt_PriceSmallContainer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel26
        '
        Me.Panel26.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel26.Controls.Add(Me.Label39)
        Me.Panel26.Controls.Add(Me.Lbl_SmallContainerwithWaterIncome)
        Me.Panel26.Controls.Add(Me.Label41)
        Me.Panel26.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel26.ForeColor = System.Drawing.Color.White
        Me.Panel26.Location = New System.Drawing.Point(499, 442)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(157, 130)
        Me.Panel26.TabIndex = 84
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(27, 104)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(103, 21)
        Me.Label39.TabIndex = 4
        Me.Label39.Text = "with water"
        '
        'Lbl_SmallContainerwithWaterIncome
        '
        Me.Lbl_SmallContainerwithWaterIncome.AutoSize = True
        Me.Lbl_SmallContainerwithWaterIncome.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_SmallContainerwithWaterIncome.Location = New System.Drawing.Point(58, 55)
        Me.Lbl_SmallContainerwithWaterIncome.Name = "Lbl_SmallContainerwithWaterIncome"
        Me.Lbl_SmallContainerwithWaterIncome.Size = New System.Drawing.Size(40, 21)
        Me.Lbl_SmallContainerwithWaterIncome.TabIndex = 3
        Me.Lbl_SmallContainerwithWaterIncome.Text = "720"
        '
        'Label41
        '
        Me.Label41.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(9, 81)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(138, 29)
        Me.Label41.TabIndex = 3
        Me.Label41.Text = "Small Container "
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel25
        '
        Me.Panel25.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel25.Controls.Add(Me.Label46)
        Me.Panel25.Controls.Add(Me.Lbl_SmallContainerwithWaterSold)
        Me.Panel25.Controls.Add(Me.Label48)
        Me.Panel25.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel25.ForeColor = System.Drawing.Color.White
        Me.Panel25.Location = New System.Drawing.Point(499, 151)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(157, 282)
        Me.Panel25.TabIndex = 83
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(5, 251)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(146, 21)
        Me.Label46.TabIndex = 3
        Me.Label46.Text = "with water sold"
        '
        'Lbl_SmallContainerwithWaterSold
        '
        Me.Lbl_SmallContainerwithWaterSold.AutoSize = True
        Me.Lbl_SmallContainerwithWaterSold.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_SmallContainerwithWaterSold.Location = New System.Drawing.Point(31, 115)
        Me.Lbl_SmallContainerwithWaterSold.Name = "Lbl_SmallContainerwithWaterSold"
        Me.Lbl_SmallContainerwithWaterSold.Size = New System.Drawing.Size(95, 68)
        Me.Lbl_SmallContainerwithWaterSold.TabIndex = 2
        Me.Lbl_SmallContainerwithWaterSold.Text = "10"
        Me.Lbl_SmallContainerwithWaterSold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(11, 223)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(135, 20)
        Me.Label48.TabIndex = 1
        Me.Label48.Text = "Small Container"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel24
        '
        Me.Panel24.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel24.Controls.Add(Me.Label36)
        Me.Panel24.Controls.Add(Me.Label43)
        Me.Panel24.Controls.Add(Me.Txt_PriceSmallContainerWater)
        Me.Panel24.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel24.ForeColor = System.Drawing.Color.White
        Me.Panel24.Location = New System.Drawing.Point(499, 7)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(157, 122)
        Me.Panel24.TabIndex = 82
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(25, 43)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(107, 21)
        Me.Label36.TabIndex = 18
        Me.Label36.Text = "with Water"
        '
        'Label43
        '
        Me.Label43.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label43.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.White
        Me.Label43.Location = New System.Drawing.Point(10, 11)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(136, 40)
        Me.Label43.TabIndex = 17
        Me.Label43.Text = "Small Container"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_PriceSmallContainerWater
        '
        Me.Txt_PriceSmallContainerWater.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceSmallContainerWater.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceSmallContainerWater.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceSmallContainerWater.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceSmallContainerWater.Location = New System.Drawing.Point(37, 83)
        Me.Txt_PriceSmallContainerWater.Name = "Txt_PriceSmallContainerWater"
        Me.Txt_PriceSmallContainerWater.ReadOnly = True
        Me.Txt_PriceSmallContainerWater.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceSmallContainerWater.TabIndex = 3
        Me.Txt_PriceSmallContainerWater.Text = "0"
        Me.Txt_PriceSmallContainerWater.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel23
        '
        Me.Panel23.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel23.Controls.Add(Me.Label34)
        Me.Panel23.Controls.Add(Me.Lbl_SmallRefillIncome)
        Me.Panel23.Controls.Add(Me.Label45)
        Me.Panel23.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel23.ForeColor = System.Drawing.Color.White
        Me.Panel23.Location = New System.Drawing.Point(171, 442)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(157, 131)
        Me.Panel23.TabIndex = 81
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(49, 80)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(58, 21)
        Me.Label34.TabIndex = 10
        Me.Label34.Text = "Small"
        '
        'Lbl_SmallRefillIncome
        '
        Me.Lbl_SmallRefillIncome.AutoSize = True
        Me.Lbl_SmallRefillIncome.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_SmallRefillIncome.Location = New System.Drawing.Point(58, 55)
        Me.Lbl_SmallRefillIncome.Name = "Lbl_SmallRefillIncome"
        Me.Lbl_SmallRefillIncome.Size = New System.Drawing.Size(40, 21)
        Me.Lbl_SmallRefillIncome.TabIndex = 2
        Me.Lbl_SmallRefillIncome.Text = "850"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(10, 101)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(137, 21)
        Me.Label45.TabIndex = 2
        Me.Label45.Text = "Water Gallons"
        '
        'Panel22
        '
        Me.Panel22.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel22.Controls.Add(Me.Label37)
        Me.Panel22.Controls.Add(Me.Lbl_SmallRefillSold)
        Me.Panel22.Controls.Add(Me.Label27)
        Me.Panel22.Controls.Add(Me.Label28)
        Me.Panel22.Location = New System.Drawing.Point(171, 151)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(157, 282)
        Me.Panel22.TabIndex = 80
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Rockwell", 10.8!)
        Me.Label37.ForeColor = System.Drawing.Color.White
        Me.Label37.Location = New System.Drawing.Point(52, 261)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(49, 21)
        Me.Label37.TabIndex = 10
        Me.Label37.Text = "Sold"
        '
        'Lbl_SmallRefillSold
        '
        Me.Lbl_SmallRefillSold.AutoSize = True
        Me.Lbl_SmallRefillSold.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_SmallRefillSold.ForeColor = System.Drawing.Color.White
        Me.Lbl_SmallRefillSold.Location = New System.Drawing.Point(31, 115)
        Me.Lbl_SmallRefillSold.Name = "Lbl_SmallRefillSold"
        Me.Lbl_SmallRefillSold.Size = New System.Drawing.Size(95, 68)
        Me.Lbl_SmallRefillSold.TabIndex = 9
        Me.Lbl_SmallRefillSold.Text = "10"
        Me.Lbl_SmallRefillSold.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Rockwell", 10.8!)
        Me.Label27.ForeColor = System.Drawing.Color.White
        Me.Label27.Location = New System.Drawing.Point(11, 237)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(131, 21)
        Me.Label27.TabIndex = 8
        Me.Label27.Text = "Gallons Small"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.White
        Me.Label28.Location = New System.Drawing.Point(16, 207)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(123, 22)
        Me.Label28.TabIndex = 7
        Me.Label28.Text = "Water Refill "
        '
        'Panel21
        '
        Me.Panel21.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel21.Controls.Add(Me.Label31)
        Me.Panel21.Controls.Add(Me.Txt_PriceSmallGallon)
        Me.Panel21.Controls.Add(Me.Label32)
        Me.Panel21.Location = New System.Drawing.Point(170, 7)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(157, 122)
        Me.Panel21.TabIndex = 79
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Rockwell", 10.8!)
        Me.Label31.ForeColor = System.Drawing.Color.White
        Me.Label31.Location = New System.Drawing.Point(11, 43)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(128, 21)
        Me.Label31.TabIndex = 21
        Me.Label31.Text = "Water Gallon"
        '
        'Txt_PriceSmallGallon
        '
        Me.Txt_PriceSmallGallon.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceSmallGallon.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceSmallGallon.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceSmallGallon.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceSmallGallon.Location = New System.Drawing.Point(37, 83)
        Me.Txt_PriceSmallGallon.Name = "Txt_PriceSmallGallon"
        Me.Txt_PriceSmallGallon.ReadOnly = True
        Me.Txt_PriceSmallGallon.Size = New System.Drawing.Size(82, 27)
        Me.Txt_PriceSmallGallon.TabIndex = 1
        Me.Txt_PriceSmallGallon.Text = "0"
        Me.Txt_PriceSmallGallon.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label32.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.White
        Me.Label32.Location = New System.Drawing.Point(45, 15)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(61, 22)
        Me.Label32.TabIndex = 20
        Me.Label32.Text = "Small"
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel12.Controls.Add(Me.Label3)
        Me.Panel12.Controls.Add(Me.Txt_PriceContainer1)
        Me.Panel12.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel12.ForeColor = System.Drawing.Color.White
        Me.Panel12.Location = New System.Drawing.Point(662, 7)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(157, 122)
        Me.Panel12.TabIndex = 78
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label3.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(27, 32)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 22)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Container"
        '
        'Txt_PriceContainer1
        '
        Me.Txt_PriceContainer1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceContainer1.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceContainer1.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceContainer1.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceContainer1.Location = New System.Drawing.Point(37, 83)
        Me.Txt_PriceContainer1.Name = "Txt_PriceContainer1"
        Me.Txt_PriceContainer1.ReadOnly = True
        Me.Txt_PriceContainer1.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceContainer1.TabIndex = 4
        Me.Txt_PriceContainer1.Text = "0"
        Me.Txt_PriceContainer1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel13.Controls.Add(Me.Label35)
        Me.Panel13.Controls.Add(Me.Label6)
        Me.Panel13.Controls.Add(Me.Txt_PriceContainerWater1)
        Me.Panel13.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel13.ForeColor = System.Drawing.Color.White
        Me.Panel13.Location = New System.Drawing.Point(334, 7)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(157, 122)
        Me.Panel13.TabIndex = 77
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(23, 45)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(107, 21)
        Me.Label35.TabIndex = 18
        Me.Label35.Text = "with Water"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label6.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(3, 10)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(151, 40)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "Container"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_PriceContainerWater1
        '
        Me.Txt_PriceContainerWater1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceContainerWater1.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceContainerWater1.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceContainerWater1.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceContainerWater1.Location = New System.Drawing.Point(37, 83)
        Me.Txt_PriceContainerWater1.Name = "Txt_PriceContainerWater1"
        Me.Txt_PriceContainerWater1.ReadOnly = True
        Me.Txt_PriceContainerWater1.Size = New System.Drawing.Size(69, 27)
        Me.Txt_PriceContainerWater1.TabIndex = 2
        Me.Txt_PriceContainerWater1.Text = "0"
        Me.Txt_PriceContainerWater1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel14
        '
        Me.Panel14.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel14.Controls.Add(Me.Label30)
        Me.Panel14.Controls.Add(Me.Label7)
        Me.Panel14.Controls.Add(Me.Txt_PriceGallon1)
        Me.Panel14.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel14.ForeColor = System.Drawing.Color.White
        Me.Panel14.Location = New System.Drawing.Point(5, 7)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(157, 122)
        Me.Panel14.TabIndex = 76
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(36, 45)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(81, 21)
        Me.Label30.TabIndex = 18
        Me.Label30.Text = "Gallon's"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Label7.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(45, 17)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(66, 22)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Water"
        '
        'Txt_PriceGallon1
        '
        Me.Txt_PriceGallon1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Txt_PriceGallon1.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Txt_PriceGallon1.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PriceGallon1.ForeColor = System.Drawing.Color.White
        Me.Txt_PriceGallon1.Location = New System.Drawing.Point(37, 83)
        Me.Txt_PriceGallon1.Name = "Txt_PriceGallon1"
        Me.Txt_PriceGallon1.ReadOnly = True
        Me.Txt_PriceGallon1.Size = New System.Drawing.Size(82, 27)
        Me.Txt_PriceGallon1.TabIndex = 0
        Me.Txt_PriceGallon1.Text = "0"
        Me.Txt_PriceGallon1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel15.Controls.Add(Me.Label54)
        Me.Panel15.Controls.Add(Me.Lbl_ContainerIncome1)
        Me.Panel15.Controls.Add(Me.Label12)
        Me.Panel15.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel15.ForeColor = System.Drawing.Color.White
        Me.Panel15.Location = New System.Drawing.Point(662, 442)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(157, 130)
        Me.Panel15.TabIndex = 75
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(41, 94)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(0, 21)
        Me.Label54.TabIndex = 5
        '
        'Lbl_ContainerIncome1
        '
        Me.Lbl_ContainerIncome1.AutoSize = True
        Me.Lbl_ContainerIncome1.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_ContainerIncome1.Location = New System.Drawing.Point(53, 55)
        Me.Lbl_ContainerIncome1.Name = "Lbl_ContainerIncome1"
        Me.Lbl_ContainerIncome1.Size = New System.Drawing.Size(50, 21)
        Me.Lbl_ContainerIncome1.TabIndex = 4
        Me.Lbl_ContainerIncome1.Text = "1500"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(29, 98)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(98, 21)
        Me.Label12.TabIndex = 4
        Me.Label12.Text = "Container"
        '
        'Panel16
        '
        Me.Panel16.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel16.Controls.Add(Me.Lbl_ContainerSold1)
        Me.Panel16.Controls.Add(Me.Label15)
        Me.Panel16.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel16.ForeColor = System.Drawing.Color.White
        Me.Panel16.Location = New System.Drawing.Point(662, 151)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(157, 282)
        Me.Panel16.TabIndex = 72
        '
        'Lbl_ContainerSold1
        '
        Me.Lbl_ContainerSold1.AutoSize = True
        Me.Lbl_ContainerSold1.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_ContainerSold1.Location = New System.Drawing.Point(31, 115)
        Me.Lbl_ContainerSold1.Name = "Lbl_ContainerSold1"
        Me.Lbl_ContainerSold1.Size = New System.Drawing.Size(95, 68)
        Me.Lbl_ContainerSold1.TabIndex = 2
        Me.Lbl_ContainerSold1.Text = "10"
        Me.Lbl_ContainerSold1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(8, 242)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(141, 21)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Container sold"
        '
        'Panel17
        '
        Me.Panel17.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel17.Controls.Add(Me.Label38)
        Me.Panel17.Controls.Add(Me.Lbl_ContainerWaterIncome1)
        Me.Panel17.Controls.Add(Me.Label18)
        Me.Panel17.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel17.ForeColor = System.Drawing.Color.White
        Me.Panel17.Location = New System.Drawing.Point(334, 442)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(157, 130)
        Me.Panel17.TabIndex = 74
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(48, 101)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(60, 21)
        Me.Label38.TabIndex = 4
        Me.Label38.Text = "water"
        '
        'Lbl_ContainerWaterIncome1
        '
        Me.Lbl_ContainerWaterIncome1.AutoSize = True
        Me.Lbl_ContainerWaterIncome1.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_ContainerWaterIncome1.Location = New System.Drawing.Point(58, 55)
        Me.Lbl_ContainerWaterIncome1.Name = "Lbl_ContainerWaterIncome1"
        Me.Lbl_ContainerWaterIncome1.Size = New System.Drawing.Size(40, 21)
        Me.Lbl_ContainerWaterIncome1.TabIndex = 3
        Me.Lbl_ContainerWaterIncome1.Text = "720"
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(10, 80)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(134, 29)
        Me.Label18.TabIndex = 3
        Me.Label18.Text = "Container with"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel18
        '
        Me.Panel18.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel18.Controls.Add(Me.Label33)
        Me.Panel18.Controls.Add(Me.Lbl_WaterRefillIncome1)
        Me.Panel18.Controls.Add(Me.Label21)
        Me.Panel18.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel18.ForeColor = System.Drawing.Color.White
        Me.Panel18.Location = New System.Drawing.Point(5, 441)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(157, 131)
        Me.Panel18.TabIndex = 73
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(41, 101)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(0, 21)
        Me.Label33.TabIndex = 3
        '
        'Lbl_WaterRefillIncome1
        '
        Me.Lbl_WaterRefillIncome1.AutoSize = True
        Me.Lbl_WaterRefillIncome1.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_WaterRefillIncome1.Location = New System.Drawing.Point(58, 55)
        Me.Lbl_WaterRefillIncome1.Name = "Lbl_WaterRefillIncome1"
        Me.Lbl_WaterRefillIncome1.Size = New System.Drawing.Size(40, 21)
        Me.Lbl_WaterRefillIncome1.TabIndex = 2
        Me.Lbl_WaterRefillIncome1.Text = "850"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(10, 96)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(137, 21)
        Me.Label21.TabIndex = 2
        Me.Label21.Text = "Water Gallons"
        '
        'Panel19
        '
        Me.Panel19.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel19.Controls.Add(Me.Label42)
        Me.Panel19.Controls.Add(Me.Lbl_ContainerWaterSold1)
        Me.Panel19.Controls.Add(Me.Label23)
        Me.Panel19.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel19.ForeColor = System.Drawing.Color.White
        Me.Panel19.Location = New System.Drawing.Point(334, 151)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(157, 282)
        Me.Panel19.TabIndex = 71
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(26, 250)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(103, 21)
        Me.Label42.TabIndex = 3
        Me.Label42.Text = "water sold"
        '
        'Lbl_ContainerWaterSold1
        '
        Me.Lbl_ContainerWaterSold1.AutoSize = True
        Me.Lbl_ContainerWaterSold1.Font = New System.Drawing.Font("Rockwell", 36.0!)
        Me.Lbl_ContainerWaterSold1.Location = New System.Drawing.Point(31, 115)
        Me.Lbl_ContainerWaterSold1.Name = "Lbl_ContainerWaterSold1"
        Me.Lbl_ContainerWaterSold1.Size = New System.Drawing.Size(95, 68)
        Me.Lbl_ContainerWaterSold1.TabIndex = 2
        Me.Lbl_ContainerWaterSold1.Text = "10"
        Me.Lbl_ContainerWaterSold1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(7, 222)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(141, 21)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "Container with"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel20
        '
        Me.Panel20.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Panel20.Controls.Add(Me.Label26)
        Me.Panel20.Controls.Add(Me.Lbl_WaterRefillSold1)
        Me.Panel20.Controls.Add(Me.Label25)
        Me.Panel20.Font = New System.Drawing.Font("Rockwell", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel20.ForeColor = System.Drawing.Color.White
        Me.Panel20.Location = New System.Drawing.Point(5, 151)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(157, 282)
        Me.Panel20.TabIndex = 70
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(16, 248)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(122, 21)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Gallons Sold"
        '
        'Lbl_WaterRefillSold1
        '
        Me.Lbl_WaterRefillSold1.AutoSize = True
        Me.Lbl_WaterRefillSold1.Font = New System.Drawing.Font("Rockwell", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_WaterRefillSold1.Location = New System.Drawing.Point(31, 115)
        Me.Lbl_WaterRefillSold1.Name = "Lbl_WaterRefillSold1"
        Me.Lbl_WaterRefillSold1.Size = New System.Drawing.Size(95, 68)
        Me.Lbl_WaterRefillSold1.TabIndex = 1
        Me.Lbl_WaterRefillSold1.Text = "10"
        Me.Lbl_WaterRefillSold1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(16, 216)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(123, 22)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "Water Refill "
        '
        'Btn_EditPrice1
        '
        Me.Btn_EditPrice1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_EditPrice1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_EditPrice1.FlatAppearance.BorderSize = 0
        Me.Btn_EditPrice1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_EditPrice1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_EditPrice1.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_EditPrice1.ForeColor = System.Drawing.Color.White
        Me.Btn_EditPrice1.Location = New System.Drawing.Point(326, 582)
        Me.Btn_EditPrice1.Name = "Btn_EditPrice1"
        Me.Btn_EditPrice1.Size = New System.Drawing.Size(165, 49)
        Me.Btn_EditPrice1.TabIndex = 7
        Me.Btn_EditPrice1.Text = "EDIT PRICE"
        Me.Btn_EditPrice1.UseVisualStyleBackColor = False
        '
        'Btn_Save1
        '
        Me.Btn_Save1.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Save1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Save1.FlatAppearance.BorderSize = 0
        Me.Btn_Save1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Save1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Save1.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Save1.ForeColor = System.Drawing.Color.White
        Me.Btn_Save1.Location = New System.Drawing.Point(415, 582)
        Me.Btn_Save1.Name = "Btn_Save1"
        Me.Btn_Save1.Size = New System.Drawing.Size(165, 49)
        Me.Btn_Save1.TabIndex = 6
        Me.Btn_Save1.Text = "SAVE"
        Me.Btn_Save1.UseVisualStyleBackColor = False
        Me.Btn_Save1.Visible = False
        '
        'Home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1292, 789)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel_Form1)
        Me.Controls.Add(Me.Panel_Form2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Home"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AU WATER REFILLING STATION"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.Panel_Form1.ResumeLayout(False)
        Me.Panel_Form2.ResumeLayout(False)
        Me.Panel29.ResumeLayout(False)
        Me.Panel29.PerformLayout()
        Me.Panel28.ResumeLayout(False)
        Me.Panel28.PerformLayout()
        Me.Panel27.ResumeLayout(False)
        Me.Panel27.PerformLayout()
        Me.Panel26.ResumeLayout(False)
        Me.Panel26.PerformLayout()
        Me.Panel25.ResumeLayout(False)
        Me.Panel25.PerformLayout()
        Me.Panel24.ResumeLayout(False)
        Me.Panel24.PerformLayout()
        Me.Panel23.ResumeLayout(False)
        Me.Panel23.PerformLayout()
        Me.Panel22.ResumeLayout(False)
        Me.Panel22.PerformLayout()
        Me.Panel21.ResumeLayout(False)
        Me.Panel21.PerformLayout()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.Panel14.ResumeLayout(False)
        Me.Panel14.PerformLayout()
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout()
        Me.Panel20.ResumeLayout(False)
        Me.Panel20.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Txt_Time As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_WaterRefillSold As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_ContainerWaterSold As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_WaterRefillIncome As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_ContainerSold As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Lbl_ContainerWaterIncome As System.Windows.Forms.Label
    Friend WithEvents Lbl_ContainerIncome As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Btn_Home As System.Windows.Forms.Button
    Friend WithEvents Btn_Bills As System.Windows.Forms.Button
    Friend WithEvents Btn_Calculation As System.Windows.Forms.Button
    Friend WithEvents Btn_Recycle As System.Windows.Forms.Button
    Friend WithEvents Btn_Reports As System.Windows.Forms.Button
    Friend WithEvents Btn_EmployeeInfo As System.Windows.Forms.Button
    Friend WithEvents Btn_Logout As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Btn_UserInfo As System.Windows.Forms.Button
    Friend WithEvents Txt_PriceGallon As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceContainerWater As System.Windows.Forms.TextBox
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceContainer As System.Windows.Forms.TextBox
    Friend WithEvents Btn_EditPrice As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Panel_Form1 As System.Windows.Forms.Panel
    Friend WithEvents Panel_Form2 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Save1 As System.Windows.Forms.Button
    Friend WithEvents Btn_EditPrice1 As System.Windows.Forms.Button
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceContainer1 As System.Windows.Forms.TextBox
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceContainerWater1 As System.Windows.Forms.TextBox
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceGallon1 As System.Windows.Forms.TextBox
    Friend WithEvents Panel15 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_ContainerIncome1 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_ContainerSold1 As System.Windows.Forms.Label
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_ContainerWaterIncome1 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Panel18 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_WaterRefillIncome1 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Panel19 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_ContainerWaterSold1 As System.Windows.Forms.Label
    Friend WithEvents Panel20 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_WaterRefillSold1 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Panel23 As System.Windows.Forms.Panel
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Lbl_SmallRefillIncome As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Panel22 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_SmallRefillSold As System.Windows.Forms.Label
    Friend WithEvents Panel21 As System.Windows.Forms.Panel
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceSmallGallon As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Panel24 As System.Windows.Forms.Panel
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceSmallContainerWater As System.Windows.Forms.TextBox
    Friend WithEvents Panel26 As System.Windows.Forms.Panel
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Lbl_SmallContainerwithWaterIncome As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Panel25 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_SmallContainerwithWaterSold As System.Windows.Forms.Label
    Friend WithEvents Panel29 As System.Windows.Forms.Panel
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Lbl_SmallContainerIncome As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Panel28 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_SmallContainerSold As System.Windows.Forms.Label
    Friend WithEvents Panel27 As System.Windows.Forms.Panel
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Txt_PriceSmallContainer As System.Windows.Forms.TextBox
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Btn_AddGallon As System.Windows.Forms.Button
    Friend WithEvents Btn_Edit As System.Windows.Forms.Button
    Friend WithEvents Btn_Change As System.Windows.Forms.Button
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
End Class
