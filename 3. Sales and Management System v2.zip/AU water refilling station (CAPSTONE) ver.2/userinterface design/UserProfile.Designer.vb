﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserProfile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UserProfile))
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Txt_Contact = New System.Windows.Forms.TextBox()
        Me.Txt_Gmail = New System.Windows.Forms.TextBox()
        Me.Txt_Fullname = New System.Windows.Forms.TextBox()
        Me.Txt_ConfirmPass = New System.Windows.Forms.TextBox()
        Me.Txt_NewPass = New System.Windows.Forms.TextBox()
        Me.Txt_Username = New System.Windows.Forms.TextBox()
        Me.Btn_Update = New System.Windows.Forms.Button()
        Me.Btn_Clear = New System.Windows.Forms.Button()
        Me.Btn_Back = New System.Windows.Forms.Button()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.Btn_ShowPass = New System.Windows.Forms.Button()
        Me.Btn_ShowPass1 = New System.Windows.Forms.Button()
        Me.Btn_ShowPass2 = New System.Windows.Forms.Button()
        Me.Txt_CurrentPass = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(262, 225)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(0, 17)
        Me.Label9.TabIndex = 59
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Rockwell", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(6, 30)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(246, 35)
        Me.Label2.TabIndex = 113
        Me.Label2.Text = "User Information"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(169, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.GridColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.DataGridView1.Location = New System.Drawing.Point(12, 323)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(8, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(54, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(102, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(126, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(65, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(119, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(221, Byte), Integer))
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(939, 61)
        Me.DataGridView1.TabIndex = 114
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(8, 95)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(82, 20)
        Me.Label10.TabIndex = 117
        Me.Label10.Text = "Fullname"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(8, 148)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 20)
        Me.Label1.TabIndex = 118
        Me.Label1.Text = "Gmail"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(8, 201)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(138, 20)
        Me.Label11.TabIndex = 119
        Me.Label11.Text = "Contact Number"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(373, 95)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(90, 20)
        Me.Label13.TabIndex = 121
        Me.Label13.Text = "Username"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(373, 202)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(123, 20)
        Me.Label14.TabIndex = 122
        Me.Label14.Text = "New Password"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(373, 255)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(153, 20)
        Me.Label15.TabIndex = 123
        Me.Label15.Text = "Confirm Password"
        '
        'Txt_Contact
        '
        Me.Txt_Contact.BackColor = System.Drawing.Color.White
        Me.Txt_Contact.Enabled = False
        Me.Txt_Contact.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Contact.Location = New System.Drawing.Point(12, 224)
        Me.Txt_Contact.Name = "Txt_Contact"
        Me.Txt_Contact.Size = New System.Drawing.Size(292, 27)
        Me.Txt_Contact.TabIndex = 2
        '
        'Txt_Gmail
        '
        Me.Txt_Gmail.BackColor = System.Drawing.Color.White
        Me.Txt_Gmail.Enabled = False
        Me.Txt_Gmail.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Gmail.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Gmail.Location = New System.Drawing.Point(12, 171)
        Me.Txt_Gmail.Name = "Txt_Gmail"
        Me.Txt_Gmail.Size = New System.Drawing.Size(292, 27)
        Me.Txt_Gmail.TabIndex = 1
        '
        'Txt_Fullname
        '
        Me.Txt_Fullname.BackColor = System.Drawing.Color.White
        Me.Txt_Fullname.Enabled = False
        Me.Txt_Fullname.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Fullname.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Fullname.Location = New System.Drawing.Point(12, 118)
        Me.Txt_Fullname.Name = "Txt_Fullname"
        Me.Txt_Fullname.Size = New System.Drawing.Size(292, 27)
        Me.Txt_Fullname.TabIndex = 0
        '
        'Txt_ConfirmPass
        '
        Me.Txt_ConfirmPass.BackColor = System.Drawing.Color.White
        Me.Txt_ConfirmPass.Enabled = False
        Me.Txt_ConfirmPass.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ConfirmPass.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_ConfirmPass.Location = New System.Drawing.Point(377, 278)
        Me.Txt_ConfirmPass.Name = "Txt_ConfirmPass"
        Me.Txt_ConfirmPass.Size = New System.Drawing.Size(292, 27)
        Me.Txt_ConfirmPass.TabIndex = 9
        Me.Txt_ConfirmPass.UseSystemPasswordChar = True
        '
        'Txt_NewPass
        '
        Me.Txt_NewPass.BackColor = System.Drawing.Color.White
        Me.Txt_NewPass.Enabled = False
        Me.Txt_NewPass.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_NewPass.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_NewPass.Location = New System.Drawing.Point(377, 225)
        Me.Txt_NewPass.Name = "Txt_NewPass"
        Me.Txt_NewPass.Size = New System.Drawing.Size(292, 27)
        Me.Txt_NewPass.TabIndex = 7
        Me.Txt_NewPass.UseSystemPasswordChar = True
        '
        'Txt_Username
        '
        Me.Txt_Username.BackColor = System.Drawing.Color.White
        Me.Txt_Username.Enabled = False
        Me.Txt_Username.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Username.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_Username.Location = New System.Drawing.Point(377, 118)
        Me.Txt_Username.Name = "Txt_Username"
        Me.Txt_Username.Size = New System.Drawing.Size(292, 27)
        Me.Txt_Username.TabIndex = 4
        '
        'Btn_Update
        '
        Me.Btn_Update.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Update.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Update.FlatAppearance.BorderSize = 0
        Me.Btn_Update.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Update.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Update.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Update.ForeColor = System.Drawing.Color.White
        Me.Btn_Update.Location = New System.Drawing.Point(750, 78)
        Me.Btn_Update.Name = "Btn_Update"
        Me.Btn_Update.Size = New System.Drawing.Size(170, 89)
        Me.Btn_Update.TabIndex = 11
        Me.Btn_Update.Text = "UPDATE"
        Me.Btn_Update.UseVisualStyleBackColor = False
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Clear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Clear.FlatAppearance.BorderSize = 0
        Me.Btn_Clear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Clear.Font = New System.Drawing.Font("Rockwell", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear.Location = New System.Drawing.Point(750, 191)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(170, 89)
        Me.Btn_Clear.TabIndex = 12
        Me.Btn_Clear.Text = "CLEAR"
        Me.Btn_Clear.UseVisualStyleBackColor = False
        '
        'Btn_Back
        '
        Me.Btn_Back.BackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(116, Byte), Integer))
        Me.Btn_Back.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_Back.FlatAppearance.BorderSize = 0
        Me.Btn_Back.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Btn_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Back.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Back.ForeColor = System.Drawing.Color.White
        Me.Btn_Back.Location = New System.Drawing.Point(844, 13)
        Me.Btn_Back.Name = "Btn_Back"
        Me.Btn_Back.Size = New System.Drawing.Size(107, 42)
        Me.Btn_Back.TabIndex = 13
        Me.Btn_Back.Text = "Back"
        Me.Btn_Back.UseVisualStyleBackColor = False
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(362, 12)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(235, 22)
        Me.DateTimePicker1.TabIndex = 135
        Me.DateTimePicker1.Visible = False
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(603, 13)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(235, 22)
        Me.DateTimePicker2.TabIndex = 136
        Me.DateTimePicker2.Visible = False
        '
        'Btn_ShowPass
        '
        Me.Btn_ShowPass.BackColor = System.Drawing.Color.White
        Me.Btn_ShowPass.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_ShowPass.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_ShowPass.FlatAppearance.BorderSize = 0
        Me.Btn_ShowPass.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_ShowPass.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_eye_24
        Me.Btn_ShowPass.Location = New System.Drawing.Point(627, 225)
        Me.Btn_ShowPass.Name = "Btn_ShowPass"
        Me.Btn_ShowPass.Size = New System.Drawing.Size(42, 27)
        Me.Btn_ShowPass.TabIndex = 8
        Me.Btn_ShowPass.UseVisualStyleBackColor = False
        '
        'Btn_ShowPass1
        '
        Me.Btn_ShowPass1.BackColor = System.Drawing.Color.White
        Me.Btn_ShowPass1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_ShowPass1.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_ShowPass1.FlatAppearance.BorderSize = 0
        Me.Btn_ShowPass1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_ShowPass1.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_eye_24
        Me.Btn_ShowPass1.Location = New System.Drawing.Point(627, 278)
        Me.Btn_ShowPass1.Name = "Btn_ShowPass1"
        Me.Btn_ShowPass1.Size = New System.Drawing.Size(42, 27)
        Me.Btn_ShowPass1.TabIndex = 10
        Me.Btn_ShowPass1.UseVisualStyleBackColor = False
        '
        'Btn_ShowPass2
        '
        Me.Btn_ShowPass2.BackColor = System.Drawing.Color.White
        Me.Btn_ShowPass2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_ShowPass2.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_ShowPass2.FlatAppearance.BorderSize = 0
        Me.Btn_ShowPass2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_ShowPass2.Image = Global.WindowsApplication1.My.Resources.Resources.icons8_eye_24
        Me.Btn_ShowPass2.Location = New System.Drawing.Point(627, 171)
        Me.Btn_ShowPass2.Name = "Btn_ShowPass2"
        Me.Btn_ShowPass2.Size = New System.Drawing.Size(42, 27)
        Me.Btn_ShowPass2.TabIndex = 6
        Me.Btn_ShowPass2.UseVisualStyleBackColor = False
        '
        'Txt_CurrentPass
        '
        Me.Txt_CurrentPass.BackColor = System.Drawing.Color.White
        Me.Txt_CurrentPass.Enabled = False
        Me.Txt_CurrentPass.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_CurrentPass.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txt_CurrentPass.Location = New System.Drawing.Point(377, 171)
        Me.Txt_CurrentPass.Name = "Txt_CurrentPass"
        Me.Txt_CurrentPass.Size = New System.Drawing.Size(292, 27)
        Me.Txt_CurrentPass.TabIndex = 5
        Me.Txt_CurrentPass.UseSystemPasswordChar = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Rockwell", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(373, 148)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(150, 20)
        Me.Label3.TabIndex = 140
        Me.Label3.Text = "Current Password"
        '
        'UserProfile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(963, 397)
        Me.Controls.Add(Me.Btn_ShowPass2)
        Me.Controls.Add(Me.Txt_CurrentPass)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Btn_ShowPass1)
        Me.Controls.Add(Me.Btn_ShowPass)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Btn_Back)
        Me.Controls.Add(Me.Btn_Update)
        Me.Controls.Add(Me.Btn_Clear)
        Me.Controls.Add(Me.Txt_Username)
        Me.Controls.Add(Me.Txt_NewPass)
        Me.Controls.Add(Me.Txt_ConfirmPass)
        Me.Controls.Add(Me.Txt_Fullname)
        Me.Controls.Add(Me.Txt_Gmail)
        Me.Controls.Add(Me.Txt_Contact)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label9)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "UserProfile"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AU WATER REFILLING STATION"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Txt_Contact As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Gmail As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Fullname As System.Windows.Forms.TextBox
    Friend WithEvents Txt_ConfirmPass As System.Windows.Forms.TextBox
    Friend WithEvents Txt_NewPass As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Username As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Update As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Back As System.Windows.Forms.Button
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Btn_ShowPass As System.Windows.Forms.Button
    Friend WithEvents Btn_ShowPass1 As System.Windows.Forms.Button
    Friend WithEvents Btn_ShowPass2 As System.Windows.Forms.Button
    Friend WithEvents Txt_CurrentPass As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
End Class
